// mongo-init.js
// ============================================================
// ⚠️ DEV/TEST ONLY — این اسکریپت فقط توسط docker-compose برای
// راه‌اندازی محیط توسعه اجرا می‌شود (mount در /docker-entrypoint-initdb.d).
//
// SECURITY: نام کاربری/رمز پیش‌فرض زیر را در production استفاده نکنید.
// در production: کاربر مونگو با رمز قوی بسازید (یا auth فعال بدون
// این فایل بالا بیایید) و اعتبارها را فقط از طریق متغیرهای محیطی
// امن (MONGODB_URI) تزریق کنید — هرگز در این فایل هاردکد نکنید.
// ============================================================
db.createUser({
    user: 'htland',
    pwd: 'htland_password',
    roles: [
      {
        role: 'readWrite',
        db: 'htland'
      }
    ]
  });

  db.createCollection('users');
  db.createCollection('wallets');
  db.createCollection('transactions');
