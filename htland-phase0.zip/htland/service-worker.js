/* HTLand Service Worker — minimal, SPA-safe
   - network-first for navigations (always fresh SPA shell when online)
   - stale-while-revalidate for brand images
   - never caches /api/* responses
*/
const VERSION = 'htland-v4'
const IMG_CACHE = `${VERSION}-images`

self.addEventListener('install', (event) => {
  self.skipWaiting()
  // no precache — avoid caching stale SPA assets
  event.waitUntil(Promise.resolve())
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys()
      await Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)))
      await self.clients.claim()
    })()
  )
})

self.addEventListener('fetch', (event) => {
  const { request } = event
  if (request.method !== 'GET') return

  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/uploads/')) return

  // navigations → network first, fallback to cache then offline shell
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          const fresh = await fetch(request)
          return fresh
        } catch (e) {
          const cache = await caches.open(VERSION)
          const cached = (await cache.match(request)) || (await cache.match('/'))
          return cached || new Response('آفلاین هستید', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } })
        }
      })()
    )
    return
  }

  // brand images → stale-while-revalidate
  if (url.pathname.startsWith('/images/') || url.pathname.startsWith('/fonts/')) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(IMG_CACHE)
        const cached = await cache.match(request)
        const network = fetch(request)
          .then((res) => {
            if (res.ok) cache.put(request, res.clone())
            return res
          })
          .catch(() => cached)
        return cached || network
      })()
    )
  }
})
