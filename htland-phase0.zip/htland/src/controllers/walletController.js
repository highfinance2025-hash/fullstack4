const walletService = require('../services/walletService'); // مسیر جدید داخل src
const Wallet = require('../models/Wallet.model');
const logger = require('../utils/logger');

class WalletController {
  // ایجاد کیف پول
  async createWallet(req, res) {
    try {
      const userId = req.user.id; // از middleware احراز هویت
      
      const wallet = await walletService.createWallet(userId);
      
      res.status(201).json({
        success: true,
        message: 'کیف پول با موفقیت ایجاد شد',
        data: {
          walletId: wallet._id,
          balance: wallet.balance,
          availableBalance: wallet.balance - wallet.lockedBalance,
          createdAt: wallet.createdAt
        }
      });
      
    } catch (error) {
      logger.error('Create wallet error:', {
        error: error.message,
        userId: req.user?.id
      });
      
      res.status(500).json({
        success: false,
        error: 'خطا در ایجاد کیف پول'
      });
    }
  }

  // دریافت اطلاعات کیف پول
  async getWallet(req, res) {
    try {
      const { walletId } = req.params;
      const userId = req.user.id;
      
      const wallet = await walletService.getWallet(walletId, userId);
      
      res.json({
        success: true,
        data: wallet
      });
      
    } catch (error) {
      logger.error('Get wallet error:', {
        error: error.message,
        walletId: req.params.walletId,
        userId: req.user?.id
      });
      
      if (error.message === 'کیف پول یافت نشد') {
        return res.status(404).json({
          success: false,
          error: error.message
        });
      }
      
      res.status(500).json({
        success: false,
        error: 'خطا در دریافت اطلاعات کیف پول'
      });
    }
  }

  // ⚠️ عمداً حذف شده‌اند: deposit / withdraw / lockBalance / unlockBalance
  // عملیات مالی نباید مستقیماً از API عمومی قابل‌فراخوانی باشند:
  //  - شارژ: فقط پس از verify موفق درگاه و از داخل سرور (walletService.increaseBalance)
  //  - برداشت: فقط با جریان تسویه + تأیید ادمین (هنوز پیاده‌سازی نشده)
  //  - lock/unlock: فقط از داخل سرویس سفارش

  // لیست کیف پول‌های کاربر
  async getUserWallets(req, res) {
    try {
      const userId = req.user.id;
      
      const wallets = await Wallet.find({ user: userId })
        .select('-__v -verification.nationalId')
        .sort({ createdAt: -1 })
        .lean();
      
      // محاسبه موجودی قابل برداشت برای هر کیف پول
      const walletsWithAvailableBalance = wallets.map(wallet => ({
        ...wallet,
        availableBalance: wallet.balance - wallet.lockedBalance
      }));
      
      res.json({
        success: true,
        data: {
          wallets: walletsWithAvailableBalance,
          totalWallets: wallets.length,
          totalBalance: wallets.reduce((sum, w) => sum + w.balance, 0),
          totalAvailableBalance: wallets.reduce((sum, w) => sum + (w.balance - w.lockedBalance), 0)
        }
      });
      
    } catch (error) {
      logger.error('Get user wallets error:', {
        error: error.message,
        userId: req.user?.id
      });
      
      res.status(500).json({
        success: false,
        error: 'خطا در دریافت کیف پول‌ها'
      });
    }
  }
}

module.exports = new WalletController();