/**
 * @file کنترلر احراز هویت HTLand (نسخه کامل و اصلاح شده)
 * @description مدیریت ثبت‌نام، ورود، OTP و پروفایل کاربر
 */

const User = require('../models/User.model');
// const Wallet = require('../models/Wallet.model'); // بعدا فعال کن اگر مدل Wallet داری
const authService = require('../services/authService');
// ✅ تغییر نام validationResult برای جلوگیری از تداخل
const { validationResult: validatorResult } = require('express-validator'); 
const logger = require('../utils/logger');

class AuthController {
  
  async sendOTP(req, res, next) {
    try {
      const errors = validatorResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }
      
      const { phone } = req.body;
      
      let user = await User.findOne({ phone });
      const isNewUser = !user;
      
      if (isNewUser) {
        user = new User({ phone });
      }
      
      const otpCode = user.generateOTP();
      await user.save();
      
      // ارسال واقعی پیامک (در توسعه فقط لاگ می‌شود)
      const sent = await authService.sendOTPSMS(phone, otpCode);
      
      // FIX: اگر ارسال پیامک در production شکست بخورد، موفقیت جعلی برگردانده نمی‌شود
      if (!sent) {
        return res.status(500).json({
          success: false,
          message: 'ارسال کد تأیید ناموفق بود. لطفاً دوباره تلاش کنید'
        });
      }
      
      // لاگ کد برای تست (فقط خارج از production)
      if (process.env.NODE_ENV !== 'production') {
        console.log(`📲 OTP for ${phone}: ${otpCode}`);
      }
      
      res.status(200).json({
        success: true,
        message: 'کد تأیید به شماره موبایل شما ارسال شد',
        data: {
          phone,
          isNewUser,
          expiresIn: 120,
          // کد فقط در غیر production در پاسخ برگردانده می‌شود (برای تست بدون سرویس پیامک)
          ...(process.env.NODE_ENV !== 'production' && { otpCode })
        }
      });
      
    } catch (error) {
      logger.error('Error in sendOTP:', error);
      next(error);
    }
  }
  
  async verifyOTP(req, res, next) {
    try {
      const errors = validatorResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }
      
      const { phone, otpCode, acceptedTerms, acceptedPrivacy } = req.body;
      
      const user = await User.findOne({ phone });
      if (!user) {
        return res.status(404).json({ success: false, message: 'کاربری با این شماره یافت نشد' });
      }
      
      // ✅ اعتبارسنجی OTP: هش + انقضا + سقف تلاش (۵ بار برای هر کد)
      const check = await user.verifyOTPCode(otpCode);
      
      if (!check.ok) {
        const messages = {
          no_otp: 'کد تأیید یافت نشد. ابتدا درخواست کد جدید بدهید',
          expired: 'کد تأیید منقضی شده است',
          too_many_attempts: 'تعداد تلاش‌ها بیش از حد مجاز است. درخواست کد جدید بدهید',
          mismatch: `کد تأیید نامعتبر است${check.remainingAttempts !== undefined ? ` (${check.remainingAttempts} تلاش باقی مانده)` : ''}`
        };
        return res.status(400).json({ success: false, message: messages[check.reason] || 'کد تأیید نامعتبر است' });
      }

      // ذخیره شرایط استفاده
      if (acceptedTerms !== undefined) user.acceptedTerms = acceptedTerms;
      if (acceptedPrivacy !== undefined) user.acceptedPrivacy = acceptedPrivacy;
      
      user.clearOTP(); // پاک کردن کد استفاده شده
      user.phoneVerified = true;
      
      // تولید توکن
      const token = user.generateAuthToken();
      await user.save();
      
      const userResponse = user.toObject();
      delete userResponse.password;
      delete userResponse.otp;
      
      res.status(200).json({
        success: true,
        message: 'ورود موفقیت‌آمیز بود',
        data: {
          user: userResponse,
          token
        }
      });
      
    } catch (error) {
      logger.error('Error in verifyOTP:', error);
      next(error);
    }
  }
  
  async getProfile(req, res, next) {
    try {
      const user = await User.findById(req.user.userId).select('-password -otp');
      if (!user) return res.status(404).json({ success: false, message: 'کاربر یافت نشد' });
      res.status(200).json({ success: true, data: { user } });
    } catch (error) { next(error); }
  }
  
  async updateProfile(req, res, next) {
    try {
      const updates = req.body;
      // SECURITY: فیلدهای حساس هرگز از طریق این endpoint قابل تغییر نیستند
      const restrictedFields = [
        'phone', 'role', 'password', 'otp', 'isActive',
        'phoneVerified', 'walletBalance', 'referralCode', 'lastLogin'
      ];
      restrictedFields.forEach(field => delete updates[field]);
      
      const user = await User.findByIdAndUpdate(req.user.userId, { $set: updates }, { new: true, runValidators: true }).select('-password -otp');
      res.status(200).json({ success: true, message: 'پروفایل بروزرسانی شد', data: { user } });
    } catch (error) { next(error); }
  }
  
  async changePassword(req, res, next) {
    try {
      const { currentPassword, newPassword } = req.body;
      const user = await User.findById(req.user.userId).select('+password');
      if (!user) return res.status(404).json({ success: false, message: 'کاربر یافت نشد' });
      
      const isMatch = await user.comparePassword(currentPassword);
      if (!isMatch) return res.status(400).json({ success: false, message: 'رمز فعلی اشتباه است' });
      
      user.password = newPassword;
      await user.save();
      res.status(200).json({ success: true, message: 'رمز عبور تغییر کرد' });
    } catch (error) { next(error); }
  }

  // مدیریت آدرس‌ها (ساده‌سازی شده برای جلوگیری از خطا)
  async addAddress(req, res, next) {
    res.status(501).json({ success: false, message: 'این بخش هنوز پیاده‌سازی نشده است' });
  }
  async updateAddress(req, res, next) {
    res.status(501).json({ success: false, message: 'این بخش هنوز پیاده‌سازی نشده است' });
  }
  async deleteAddress(req, res, next) {
    res.status(501).json({ success: false, message: 'این بخش هنوز پیاده‌سازی نشده است' });
  }
  async getAddresses(req, res, next) {
    res.status(501).json({ success: false, message: 'این بخش هنوز پیاده‌سازی نشده است' });
  }

  async logout(req, res, next) {
    res.status(200).json({ success: true, message: 'خارج شدید' });
  }
  async logoutAll(req, res, next) {
    res.status(200).json({ success: true, message: 'از همه دستگاه‌ها خارج شدید' });
  }
  
  async forgotPassword(req, res, next) {
    try {
      const { phone } = req.body;
      const user = await User.findOne({ phone });
      if (!user) return res.status(200).json({ success: true, message: 'اگر وجود داشته باشد کد ارسال می‌شود' });
      
      const otpCode = user.generateOTP();
      await user.save();
      
      // FIX: کد قبلاً هرگز ارسال نمی‌شد و در پاسخ هم برمی‌گشت (نقض امنیتی جدی —
      // امکان بازنشانی رمز هر حساب). اکنون واقعاً پیامک می‌شود و کد فقط در
      // غیر production در پاسخ می‌آید (برای تست).
      const sent = await authService.sendOTPSMS(phone, otpCode);
      if (!sent) {
        return res.status(500).json({ success: false, message: 'ارسال کد بازیابی ناموفق بود' });
      }
      
      res.status(200).json({
        success: true,
        message: 'کد بازیابی ارسال شد',
        ...(process.env.NODE_ENV !== 'production' && { data: { otpCode } })
      });
    } catch (error) { next(error); }
  }
  
  async resetPassword(req, res, next) {
    try {
      const { phone, otpCode, newPassword } = req.body;
      const user = await User.findOne({ phone }).select('+otp +password');
      
      // FIX: بررسی انقضا و سقف تلاش هم اضافه شد (قبلاً فقط تطابق متن ساده چک می‌شد)
      if (!user) return res.status(400).json({ success: false, message: 'کد نامعتبر است' });
      
      const check = await user.verifyOTPCode(otpCode);
      if (!check.ok) return res.status(400).json({ success: false, message: 'کد نامعتبر یا منقضی شده است' });
      
      user.password = newPassword;
      user.clearOTP();
      await user.save();
      res.status(200).json({ success: true, message: 'رمز عبور تغییر کرد' });
    } catch (error) { next(error); }
  }
  
  async deleteAccount(req, res, next) {
    res.status(200).json({ success: true, message: 'حساب حذف شد' });
  }
  async getActiveSessions(req, res, next) {
    res.status(200).json({ success: true, data: { sessions: [] } });
  }
  async revokeSession(req, res, next) {
    res.status(200).json({ success: true, message: 'سشن حذف شد' });
  }
}

module.exports = new AuthController();