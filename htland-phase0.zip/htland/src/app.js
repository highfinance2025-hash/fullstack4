const express = require('express');
const path = require('path');
const fs = require('fs');
const config = require('./config/env.config');
const logger = require('./utils/logger');

// ✅ اضافه کردن Swagger
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./config/swagger.config');

// Middleware imports
const securityMiddleware = require('./middlewares/security.middleware');
const { ErrorMiddleware } = require('./middlewares/error.middleware');
const { apiResponse } = require('./utils/api-response');

// Import routes
const authRoutes = require('./routes/auth.routes');
const walletRoutes = require('./routes/wallet.routes');
const productRoutes = require('./routes/product.routes');
const cartRoutes = require('./routes/cart.routes');
const orderRoutes = require('./routes/order.routes');
const addressRoutes = require('./routes/address.routes');
const profileRoutes = require('./routes/profile.routes');

class HTLandApp {
  constructor() {
    this.app = express();
    this.config = config;
    this.logger = logger;
    
    // ترتیب مهم است: اول Middlewares، بعد فایل‌های استاتیک، بعد API Routes
    this.initializeMiddlewares();
    this.initializeFrontendServing(); // ✅ استاتیک‌ها قبل از Routes
    this.initializeRoutes();
    this.initializeErrorHandling();
    this.setupGracefulShutdown();
  }

  initializeMiddlewares() {
    // 🛡️ Security First
    this.app.use(securityMiddleware.helmet());
    this.app.use(securityMiddleware.cors(this.config.cors.allowedOrigins));
    this.app.use(securityMiddleware.rateLimit(this.config.rateLimit));
    this.app.use(securityMiddleware.sanitize());
    this.app.use(securityMiddleware.xssFilter());
    
    // 📊 Logging & Monitoring
    this.app.use(logger.middleware());
    
    // 🔄 Request Processing
    this.app.use(express.json({ 
      limit: this.config?.file?.maxSize || '20mb',
      verify: this.rawBodyMiddleware()
    }));
    
    this.app.use(express.urlencoded({ 
      extended: true, 
     limit: this.config?.file?.maxSize || '20mb',
    }));
    
    // ✅ API Response Formatter
    this.app.use(apiResponse);
    
    // 🔍 Request ID for tracing
    this.app.use((req, res, next) => {
      req.id = req.headers['x-request-id'] || 
               Date.now().toString(36) + Math.random().toString(36).substr(2);
      res.setHeader('X-Request-ID', req.id);
      next();
    });
  }

  rawBodyMiddleware() {
    return (req, res, buf) => {
      if (buf && buf.length) {
        req.rawBody = buf.toString();
        
        try {
          if (req.is('application/json')) {
            JSON.parse(buf.toString());
          }
        } catch (e) {
          throw new Error('JSON ارسالی نامعتبر است');
        }
      }
    };
  }

  // ✅ متد کامل شده: سرو کردن فایل‌های فرانت‌اند
  initializeFrontendServing() {
    // مسیر ریشه پروژه (خروج از پوشه src)
    const rootPath = path.resolve(__dirname, '..');

    // ۱. تصاویر برند (فرانت قدیمی /css و /js حذف شده است)
    this.app.use('/images', express.static(path.join(rootPath, 'images')));

    // ۱.۵ React SPA build (Vite) — استاتیک‌های هش‌دار
    const spaDir = path.join(rootPath, 'frontend', 'dist');
    if (fs.existsSync(path.join(spaDir, 'index.html'))) {
      this.app.use(express.static(spaDir, { index: false }));
    }

    // ۲. سرو کردن فایل‌های تکی (برای PWA الزامی است)
    this.app.get('/manifest.json', (req, res) => {
      res.sendFile(path.join(rootPath, 'manifest.json'));
    });

    this.app.get('/service-worker.js', (req, res) => {
      res.setHeader('Service-Worker-Allowed', '/');
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(path.join(rootPath, 'service-worker.js'));
    });

    // ۳. SPA fallback — فقط برای مسیرهای غیر API (پس از تعریف روت‌ها اجرا می‌شود)
    this.initializeSpaServing(spaDir);
  }

  // ✅ SPA history fallback — بعد از initializeRoutes فراخوانی می‌شود
  initializeSpaServing(spaDir) {
    const spaIndex = path.join(spaDir, 'index.html');
    if (!fs.existsSync(spaIndex)) return;

    this.app.use((req, res, next) => {
      // مسیرهایی که باید به API/404 خودشان برسند
      if (
        req.method !== 'GET' ||
        req.path.startsWith('/api/') ||
        req.path.startsWith('/api-docs') ||
        req.path.startsWith('/health') ||
        req.path.startsWith('/uploads') ||
        req.path.startsWith('/css/') ||
        req.path.startsWith('/js/') ||
        req.path.startsWith('/images/') ||
        req.path === '/manifest.json' ||
        req.path === '/service-worker.js' ||
        path.extname(req.path) // فایل‌های استاتیک با پسوند
      ) {
        return next();
      }
      res.sendFile(spaIndex);
    });
  }

  initializeRoutes() {
    // 🩺 Health Check (Public)
    this.app.get('/health', async (req, res) => {
      const health = await this.healthCheck();
      res.api.success(health, 'Service is healthy');
    });

    // 📚 API Documentation (Public)
    this.app.get('/api/docs', (req, res) => {
      res.api.success({
        service: 'HTLand Wallet API',
        version: this.config.app.version,
        environment: this.config.env,
        endpoints: this.getApiEndpoints(),
        documentation: 'https://docs.htland.ir',
        timestamp: new Date().toISOString()
      });
    });

    // ✅ Swagger Documentation (فقط در محیط توسعه)
    if (this.config.env !== 'production') {
      this.app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
      console.log('📚 Swagger docs available at /api-docs');
    }

    // 🛡️ Protected Routes (with rate limiting per endpoint)
    // FIX: سقف از env قابل تنظیم باشد (RATE_LIMIT_MAX_REQUESTS) — پیش‌فرض ۱۰۰
    const apiLimiter = securityMiddleware.apiRateLimiter({
      windowMs: 15 * 60 * 1000,
      max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100
    });

    // Authentication routes with stricter rate limiting
    const authLimiter = securityMiddleware.createAuthLimiter();
    
    this.app.use('/api/v1/auth', authLimiter, authRoutes);
    this.app.use('/api/v1/wallet', apiLimiter, walletRoutes);
    this.app.use('/api/v1/products', apiLimiter, productRoutes);
    this.app.use('/api/v1/cart', apiLimiter, cartRoutes);
    this.app.use('/api/v1/orders', apiLimiter, orderRoutes);
    this.app.use('/api/v1/addresses', apiLimiter, addressRoutes);
    this.app.use('/api/v1/profile', apiLimiter, profileRoutes);

    // 📁 Static Files (Secure) - فایل‌های آپلود شده کاربران
    if (this.config.file?.uploadPath) {
      this.app.use('/uploads', express.static(
        path.resolve(this.config.file.uploadPath), 
        this.getStaticFileOptions()
      ));
    }
  }

  getApiEndpoints() {
    return {
      auth: {
        register: { method: 'POST', path: '/api/v1/auth/register', auth: false },
        login: { method: 'POST', path: '/api/v1/auth/login', auth: false },
        refresh: { method: 'POST', path: '/api/v1/auth/refresh', auth: true },
        logout: { method: 'POST', path: '/api/v1/auth/logout', auth: true }
      },
      wallet: {
        list: { method: 'GET', path: '/api/v1/wallet', auth: true },
        create: { method: 'POST', path: '/api/v1/wallet/create', auth: true },
        detail: { method: 'GET', path: '/api/v1/wallet/:walletId', auth: true }
        // شارژ/برداشت عمداً از API عمومی حذف شده‌اند (فقط از طریق درگاه + سرور)
      },
      products: {
        list: { method: 'GET', path: '/api/v1/products', auth: false },
        detail: { method: 'GET', path: '/api/v1/products/:id', auth: false },
        create: { method: 'POST', path: '/api/v1/products', auth: true },
        update: { method: 'PUT', path: '/api/v1/products/:id', auth: true },
        delete: { method: 'DELETE', path: '/api/v1/products/:id', auth: true }
      }
    };
  }

  getStaticFileOptions() {
    return {
      maxAge: this.config.env === 'production' ? '365d' : '1h',
      setHeaders: (res, filePath) => {
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('X-Frame-Options', 'DENY');
        
        const executableRegex = /\.(php|exe|sh|bat|cmd|ps1|js|html)$/i;
        if (executableRegex.test(filePath)) {
          res.setHeader('Content-Type', 'text/plain');
          res.setHeader('Content-Disposition', 'inline');
        }
        
        const imageRegex = /\.(jpg|jpeg|png|gif|webp|svg)$/i;
        if (imageRegex.test(filePath)) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
        
        res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
      }
    };
  } 

  async healthCheck() {
    const checks = {
      api: { 
        status: 'healthy', 
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
      },
      database: { status: 'unknown', latency: null },
      redis: { status: 'unknown', latency: null },
      payment: { status: 'unknown' },
      memory: {
        used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024)
      },
      system: {
        platform: process.platform,
        nodeVersion: process.version,
        pid: process.pid
      }
    };

    try {
      const database = require('./config/database.config');
      const dbHealth = await database.healthCheck();
      checks.database = dbHealth;

      if (this.config.redis?.url) {
        const redis = require('./config/redis.config');
        const redisHealth = await redis.healthCheck();
        checks.redis = redisHealth;
      }

      if (this.config.zarinpal?.merchantId) {
        const zarinpalConfig = require('./config/zarinpal.config');
        const paymentHealth = await zarinpalConfig.healthCheck();
        checks.payment = paymentHealth;
      }

      const criticalServices = [checks.database.status];
      if (checks.redis.status) criticalServices.push(checks.redis.status);
      
      const allHealthy = criticalServices.every(s => s === 'healthy');
      checks.overall = allHealthy ? 'healthy' : 'degraded';

    } catch (error) {
      checks.overall = 'unhealthy';
      checks.error = error.message;
      this.logger.error('Health check failed:', error);
    }

    return checks;
  }

  initializeErrorHandling() {
    this.app.use(ErrorMiddleware.notFoundHandler);
    this.app.use(ErrorMiddleware.errorHandler);
  }

  setupGracefulShutdown() {
    const shutdown = async (signal) => {
      this.logger.warn(`Received ${signal}, shutting down gracefully...`);
      
      setTimeout(() => {
        this.logger.info('Graceful shutdown complete');
        process.exit(0);
      }, 10000);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  }

  getApp() {
    return this.app;
  }
}


module.exports = new HTLandApp().getApp();