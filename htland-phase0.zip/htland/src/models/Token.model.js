// models/Token.model.js

const mongoose = require('mongoose');

/**
 * اسکیما و مدل توکن (برای ردیابی سشن‌ها / refresh token ها)
 * توجه: سیستم احراز هویت فعلی (auth.middleware.js) عمدتاً از آرایه‌ی
 * sessions داخل خود User استفاده می‌کند. این مدل جدا برای مواردی است
 * که بخواهید سشن‌ها را در یک کالکشن مستقل MongoDB نگه دارید
 * (مثلاً برای مدیریت بهتر expire شدن خودکار با TTL index).
 */
const tokenSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'شناسه کاربر الزامی است'],
      index: true,
    },
    token: {
      type: String,
      required: [true, 'مقدار توکن الزامی است'],
    },
    type: {
      type: String,
      enum: ['refresh', 'access', 'reset_password', 'email_verify'],
      default: 'refresh',
    },
    userAgent: String,
    ip: String,
    revoked: {
      type: Boolean,
      default: false,
      index: true,
    },
    expiresAt: {
      type: Date,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// حذف خودکار توکن‌های منقضی‌شده توسط خود MongoDB
tokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Token', tokenSchema);
