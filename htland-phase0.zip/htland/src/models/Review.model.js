// models/Review.model.js

const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');

/**
 * اسکیما و مدل نقد و بررسی (Review) برای محصولات HTLand
 */
const reviewSchema = new mongoose.Schema(
  {
    // محصولی که این نظر برای آن ثبت شده
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'شناسه محصول الزامی است'],
      index: true,
    },
    // کاربری که نظر را ثبت کرده
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'شناسه کاربر الزامی است'],
      index: true,
    },
    // امتیاز (۱ تا ۵)
    rating: {
      type: Number,
      required: [true, 'امتیاز الزامی است'],
      min: [1, 'حداقل امتیاز ۱ است'],
      max: [5, 'حداکثر امتیاز ۵ است'],
    },
    // عنوان کوتاه نظر
    title: {
      type: String,
      trim: true,
      maxlength: [120, 'عنوان نمی‌تواند بیشتر از ۱۲۰ کاراکتر باشد'],
    },
    // متن نظر
    comment: {
      type: String,
      required: [true, 'متن نظر الزامی است'],
      trim: true,
      maxlength: [2000, 'متن نظر نمی‌تواند بیشتر از ۲۰۰۰ کاراکتر باشد'],
    },
    // آیا این کاربر واقعاً این محصول را خریداری کرده (برای نشان "خرید تایید شده")
    verifiedPurchase: {
      type: Boolean,
      default: false,
    },
    // وضعیت تایید توسط مدیر (برای جلوگیری از اسپم/نظرات نامناسب)
    approved: {
      type: Boolean,
      default: false,
      index: true,
    },
    // تعداد لایک (مفید بودن نظر)
    helpfulCount: {
      type: Number,
      default: 0,
    },
    // پاسخ فروشنده/مدیر به این نظر (اختیاری)
    reply: {
      text: { type: String, trim: true, maxlength: 1000 },
      repliedAt: Date,
      repliedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    },
    // تصاویر ضمیمه شده توسط کاربر (اختیاری)
    images: [
      {
        url: String,
        publicId: String,
      },
    ],
  },
  {
    timestamps: true,
  }
);

// هر کاربر فقط یک نظر برای هر محصول می‌تواند ثبت کند
reviewSchema.index({ product: 1, user: 1 }, { unique: true });

reviewSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('Review', reviewSchema);