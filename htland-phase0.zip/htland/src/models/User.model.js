/**
 * @file مدل کاربران HTLand (نسخه نهایی اصلاح شده)
 */
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const validator = require('validator');
const crypto = require('crypto');

const userSchema = new mongoose.Schema({
  // اطلاعات اصلی
  phone: {
    type: String,
    required: [true, 'شماره موبایل الزامی است'],
    unique: true,
    index: true,
    validate: {
      validator: function(v) {
        return /^09[0-9]{9}$/.test(v);
      },
      message: 'شماره موبایل معتبر نیست'
    }
  },
  
  fullName: {
    type: String,
    trim: true,
    minlength: 3,
    maxlength: 100
  },
  
  email: {
    type: String,
    lowercase: true,
    trim: true,
    validate: {
      validator: validator.isEmail,
      message: 'ایمیل معتبر نیست'
    }
  },
  
  password: {
    type: String,
    minlength: [6, 'رمز عبور باید حداقل ۶ کاراکتر باشد'],
    select: false
  },
  
  // ✅ فیلد OTP
  // SECURITY FIX: کد OTP دیگر به‌صورت متن ساده ذخیره نمی‌شود؛ فقط هش bcrypt
  // به‌همراه شمارنده تلاش ذخیره می‌شود تا سرریز دیتابیس امکان حدس آفلاین
  // کد ۶ رقمی را ندهد.
  otp: {
    codeHash: {
      type: String
    },
    attempts: {
      type: Number,
      default: 0
    },
    expiresAt: {
      type: Date
    }
  },

  profileImage: {
    type: String,
    default: 'https://res.cloudinary.com/htland/image/upload/v1/default-avatar.png'
  },
  
  isActive: {
    type: Boolean,
    default: true
  },
  
  role: {
    type: String,
    enum: ['user', 'admin', 'seller'],
    default: 'user'
  },
  
  phoneVerified: {
    type: Boolean,
    default: false
  },
  
  walletBalance: {
    type: Number,
    default: 0
  },
  
  referralCode: {
    type: String,
    unique: true,
    sparse: true
  },

  lastLogin: {
    type: Date
  }

}, {
  timestamps: true
});

// ایندکس‌ها
userSchema.index({ phone: 1 });

// میدلور: هش کردن رمز عبور قبل از ذخیره
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// میدلور: ایجاد کد ارجاع خودکار
userSchema.pre('save', function(next) {
  if (!this.referralCode) {
    this.referralCode = 'HT' + Math.random().toString(36).substr(2, 8).toUpperCase();
  }
  next();
});

// متد نمونه: مقایسه رمز عبور
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// متد نمونه: تولید توکن JWT
// متد نمونه: تولید توکن JWT
userSchema.methods.generateAuthToken = function() {
  const jwt = require('jsonwebtoken');
  return jwt.sign(
    { 
      userId: this._id,
      phone: this.phone,
      role: this.role,
      type: 'access' 
    },
    process.env.JWT_SECRET || 'htland-secret-key',
    { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
  );
};

// ✅ متد نمونه: تولید کد OTP
// SECURITY: crypto.randomInt (تصادف رمزنگارانه) به‌جای Math.random،
// ذخیره‌سازی هش bcrypt و شمارنده تلاش (حداکثر ۵ تلاش برای هر کد).
const OTP_MAX_ATTEMPTS = 5;
const OTP_TTL_MS = 2 * 60 * 1000; // ۲ دقیقه

userSchema.methods.generateOTP = function() {
  // تولید کد ۶ رقمی تصادفی رمزنگارانه
  const otpCode = crypto.randomInt(100000, 1000000).toString();
  
  // ذخیره هش (نه متن ساده) + زمان انقضا + ریست شمارنده تلاش
  this.otp = {
    codeHash: bcrypt.hashSync(otpCode, 10),
    attempts: 0,
    expiresAt: new Date(Date.now() + OTP_TTL_MS)
  };

  return otpCode;
};

// بررسی صحت کد OTP (هش + انقضا + سقف تلاش)
userSchema.methods.verifyOTPCode = async function(candidateCode) {
  if (!this.otp || !this.otp.codeHash) {
    return { ok: false, reason: 'no_otp' };
  }
  
  if (this.otp.expiresAt < new Date()) {
    return { ok: false, reason: 'expired' };
  }
  
  if (this.otp.attempts >= OTP_MAX_ATTEMPTS) {
    return { ok: false, reason: 'too_many_attempts' };
  }
  
  const match = await bcrypt.compare(String(candidateCode), this.otp.codeHash);
  
  if (!match) {
    this.otp.attempts += 1;
    await this.save();
    const remaining = Math.max(0, OTP_MAX_ATTEMPTS - this.otp.attempts);
    return { ok: false, reason: 'mismatch', remainingAttempts: remaining };
  }
  
  return { ok: true };
};

// پاک‌سازی OTP (پس از موفقیت یا قفل شدن)
userSchema.methods.clearOTP = function() {
  this.otp = undefined;
};

const User = mongoose.model('User', userSchema);

module.exports = User;