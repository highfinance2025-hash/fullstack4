// upload.js
const FileUpload = require('./fileUpload');

// ایجاد instance
const fileUpload = new FileUpload({
  uploadDir: process.env.UPLOAD_PATH || 'uploads',
  maxSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024,
  allowedMimes: {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
    'image/gif': 'gif',
    'application/pdf': 'pdf'
  }
});

// Export متدها
module.exports = {
  uploadProfileImage: fileUpload.getProfileImageUpload(),
  deleteFile: fileUpload.deleteFile.bind(fileUpload),
  isImageFile: fileUpload.isImageFile.bind(fileUpload),
  isValidFileSize: fileUpload.isValidFileSize.bind(fileUpload),
  getFileInfo: fileUpload.getFileInfo.bind(fileUpload),

  // متدهای جدید
  fileUpload, // instance اصلی
  uploadProductImages: fileUpload.getProductImagesUpload(),
  uploadDocument: fileUpload.getDocumentUpload(),
  validateFile: fileUpload.validateFile.bind(fileUpload),
  processImage: fileUpload.processImage.bind(fileUpload),
  generateSafeFilename: fileUpload.generateSafeFilename.bind(fileUpload)
};
