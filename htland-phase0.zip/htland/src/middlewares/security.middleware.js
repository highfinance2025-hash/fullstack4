// src/middlewares/security.middleware.js - Security Middleware Collection
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');
const xss = require('xss-clean');

class SecurityMiddleware {
  static helmet() {
    return helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          // اجازه لود استایل از خود سایت، Inline Styles، Google Fonts و CDNها
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
          // اجازه لود اسکریپت از خود سایت، Inline Scripts و CDNهای مورد نیاز
          scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
          // اجازه لود تصاویر از هر منبع امن
          imgSrc: ["'self'", "data:", "https:", "http:"],
          // اجازه لود فونت از خود سایت، Google Fonts و CDNها
          fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
          // اجازه اتصال به APIهای جدید
          connectSrc: ["'self'", "https://htland.shop", "https://api.htland.shop"],
          frameSrc: ["'none'"],
          objectSrc: ["'none'"]
        }
      },
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
      }
    });
  }

  static cors(allowedOrigins = []) {
    // اضافه کردن دامنه‌های جدید به لیست پیش‌فرض
    const defaultOrigins = [
      'https://htland.shop',
      'https://www.htland.shop',
      'https://api.htland.shop'
    ];
    
    // FIX: URLهای خودِ سرویس (APP_URL/BACKEND_URL) همیشه مجازند — مرورگر برای
    // اسکریپت‌های module حتی در درخواست هم‌مبدأ هدر Origin می‌فرستد و اگر
    // URL خود سرویس در لیست نباشد، بارگذاری bundle با CORS رد می‌شد.
    const selfOrigins = [
      process.env.APP_URL,
      process.env.BACKEND_URL,
      process.env.FRONTEND_URL
    ].filter(Boolean).flatMap((u) => {
      // نسخه localhost و 127.0.0.1 هر دو پذیرفته شوند (alias های رایج localhost)
      const alt = u.includes('//localhost:') ? u.replace('//localhost:', '//127.0.0.1:')
        : u.includes('//127.0.0.1:') ? u.replace('//127.0.0.1:', '//localhost:') : null;
      return alt ? [u, alt] : [u];
    });
    
    const finalOrigins = [...new Set([...defaultOrigins, ...selfOrigins, ...allowedOrigins])];

    const corsOptions = {
      origin: (origin, callback) => {
        // Allow requests with no origin (mobile apps, curl, etc.) in non-production
        if (!origin && process.env.NODE_ENV !== 'production') {
          return callback(null, true);
        }
        
        // Block requests with no origin in production
        if (!origin && process.env.NODE_ENV === 'production') {
          return callback(new Error('CORS policy requires origin'), false);
        }
        
        // Allow if origin is in allowed list
        if (finalOrigins.includes(origin)) {
          return callback(null, true);
        }
        
        callback(new Error(`Origin ${origin} not allowed by CORS`), false);
      },
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'Accept', 'X-Request-ID'],
      maxAge: 86400
    };
    
    return cors(corsOptions);
  }

  static rateLimit(config = {}) {
    const defaultConfig = {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100,
      standardHeaders: true,
      legacyHeaders: false,
      message: {
        success: false,
        error: 'تعداد درخواست‌های شما بیش از حد مجاز است. لطفا بعدا تلاش کنید.',
        code: 'RATE_LIMIT_EXCEEDED'
      },
      skip: (req) => {
        // Skip for health checks, static files and SPA assets
        return req.path === '/health' ||
               req.path.startsWith('/uploads') ||
               req.path.startsWith('/images') ||
               req.path.startsWith('/assets') ||
               req.path.startsWith('/css') ||
               req.path.startsWith('/js') ||
               req.path.startsWith('/fonts') ||
               req.path === '/favicon.ico' ||
               req.path === '/manifest.json' ||
               req.path === '/service-worker.js';
      },
      keyGenerator: (req) => {
        // Use X-Forwarded-For header in production (behind proxy)
        return process.env.NODE_ENV === 'production' 
          ? req.headers['x-forwarded-for'] || req.ip
          : req.ip;
      }
    };
    
    // FIX: env.config از کلید maxRequests استفاده می‌کند؛ به express-rate-limit نگاشت شود
    // (قبلاً مقدار ENV نادیده گرفته می‌شد و لیمیت پیش‌فرض اعمال می‌شد)
    const merged = { ...defaultConfig, ...config };
    if (config?.maxRequests && !config.max) merged.max = config.maxRequests;
    return rateLimit(merged);
  }

  static sanitize() {
    return mongoSanitize({
      replaceWith: '_',
      onSanitize: ({ req, key }) => {
        console.warn(`MongoDB injection attempt detected:`, {
          key,
          value: req.body[key],
          ip: req.ip,
          path: req.path
        });
      }
    });
  }

  static xssFilter() {
    return xss();
  }

  static apiRateLimiter(options = {}) {
    return rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 100,
      standardHeaders: true,
      legacyHeaders: false,
      ...options
    });
  }

  static createAuthLimiter() {
    return rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 5,
      skipSuccessfulRequests: true,
      keyGenerator: (req) => {
        const username = req.body.email || req.body.phone || req.body.username || 'unknown';
        return `${req.ip}_${username}`;
      },
      handler: (req, res) => {
        res.status(429).json({
          success: false,
          error: 'تعداد تلاش‌های ناموفق بیش از حد مجاز است. لطفاً 15 دقیقه دیگر تلاش کنید.',
          code: 'RATE_LIMIT_EXCEEDED'
        });
      }
    });
  }
}

module.exports = SecurityMiddleware;