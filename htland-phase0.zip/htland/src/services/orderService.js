/**
 * @file سرویس سفارشات HTLand
 * @description منطق کسب‌وکار و عملیات مربوط به سفارشات
 */

const mongoose = require('mongoose');
const Order = require('../models/Order.model');
const Cart = require('../models/Cart.model');
const Product = require('../models/Product.model');
const Wallet = require('../models/Wallet.model');
// FIX: کلاس AppError باید همان باشد که error.middleware در instanceof می‌شناسد
const { AppError } = require('../utils/error-builder');
const logger = require('../utils/logger');
const config = require('../config/env.config');
const axios = require('axios');

// نرخ مالیات از env خوانده شود (قبلاً ۹٪ هاردکد شده بود)
const TAX_RATE = config.financial.taxRate;

// تفکیک صریح درگاه واقعی از درگاه شبیه‌سازی‌شده
const ZARINPAL_SANDBOX = process.env.ZARINPAL_SANDBOX === 'true';
const ZARINPAL_API = ZARINPAL_SANDBOX
  ? 'https://sandbox.zarinpal.com/pg/v4/payment'
  : 'https://api.zarinpal.com/pg/v4/payment';
const ZARINPAL_STARTPAY = ZARINPAL_SANDBOX
  ? 'https://sandbox.zarinpal.com/pg/StartPay/'
  : 'https://www.zarinpal.com/pg/StartPay/';

/**
 * سرویس مدیریت سفارشات
 */
const orderService = {
  
  /**
   * اعتبارسنجی آیتم‌های سبد خرید برای سفارش
   * @param {Array} cartItems - آیتم‌های سبد خرید
   * @returns {Promise<Object>} - نتیجه اعتبارسنجی
   */
  validateCartItems: async (cartItems) => {
    const invalidItems = [];
    let allValid = true;
    
    for (const item of cartItems) {
      try {
        const product = await Product.findById(item.productId._id || item.productId);
        
        if (!product) {
          invalidItems.push({
            productId: item.productId,
            reason: 'محصول حذف شده است',
            itemName: item.productName
          });
          allValid = false;
          continue;
        }
        
        if (!product.active) {
          invalidItems.push({
            productId: product._id,
            reason: 'محصول غیرفعال شده است',
            itemName: product.name
          });
          allValid = false;
          continue;
        }
        
        if (!product.inStock) {
          invalidItems.push({
            productId: product._id,
            reason: 'محصول موجود نیست',
            itemName: product.name
          });
          allValid = false;
          continue;
        }
        
        if (product.stock < item.quantity) {
          invalidItems.push({
            productId: product._id,
            reason: `موجودی کافی نیست (موجودی: ${product.stock}, درخواست: ${item.quantity})`,
            itemName: product.name,
            requested: item.quantity,
            available: product.stock
          });
          allValid = false;
        }
        
      } catch (error) {
        logger.error(`خطا در بررسی محصول ${item.productId}:`, error);
        invalidItems.push({
          productId: item.productId,
          reason: 'خطای سرور در بررسی محصول',
          itemName: item.productName
        });
        allValid = false;
      }
    }
    
    return {
      valid: allValid,
      invalidItems,
      totalItems: cartItems.length,
      validItems: cartItems.length - invalidItems.length
    };
  },
  
  /**
   * محاسبه جمع‌های مالی سفارش — منطبق بر فرمول سبد خرید (کوپن + مالیات)
   * FIX: قبلاً کوپن نادیده گرفته می‌شد (کاربر بیشتر از مبلغ نمایش‌داده‌شده
   * شارژ می‌شد) و مالیات ۹٪ هاردکد بود در حالی که در نمایش تسویه حساب
   * نشان داده نمی‌شد. اکنون: پایه مالیات = مبلغ پس از کوپن، نرخ از env.
   * @param {Array} items - آیتم‌های سفارش
   * @param {number} shippingFee - هزینه ارسال
   * @param {number} couponPercent - درصد کوپن (۰ تا ۱۰۰)
   * @returns {Object} - محاسبات مالی
   */
  calculateOrderTotals: (items, shippingFee = 0, couponPercent = 0) => {
    let subtotal = 0;
    let totalDiscount = 0;
    let totalItems = 0;
    
    items.forEach(item => {
      const itemPrice = item.finalPriceAtTime || item.unitPrice;
      const itemTotal = itemPrice * item.quantity;
      
      subtotal += itemTotal;
      totalItems += item.quantity;
      
      // محاسبه تخفیف آیتم
      if (item.priceAtTime > itemPrice) {
        totalDiscount += (item.priceAtTime - itemPrice) * item.quantity;
      }
    });
    
    const couponPercentSafe = Math.min(Math.max(couponPercent || 0, 0), 100);
    const couponAmount = Math.round((subtotal * couponPercentSafe) / 100);
    const taxableAmount = subtotal - couponAmount;
    const tax = Math.round(taxableAmount * TAX_RATE);
    
    const finalAmount = taxableAmount + tax + shippingFee;
    
    return {
      subtotal,
      totalDiscount,
      totalItems,
      couponPercent: couponPercentSafe,
      couponAmount,
      taxableAmount,
      shippingFee,
      tax,
      taxRate: TAX_RATE,
      finalAmount,
      formatted: {
        subtotal: subtotal.toLocaleString('fa-IR'),
        discount: totalDiscount.toLocaleString('fa-IR'),
        coupon: couponAmount.toLocaleString('fa-IR'),
        shipping: shippingFee.toLocaleString('fa-IR'),
        tax: tax.toLocaleString('fa-IR'),
        final: finalAmount.toLocaleString('fa-IR')
      }
    };
  },
  
  /**
   * SECURITY FIX: ایجاد سفارش با پرداخت واقعیِ کیف پول
   * قبلاً این تابع موجودی ساختگی (۱٬۰۰۰٬۰۰۰ ثابت) را بررسی و هیچ پولی
   * واقعاً کسر نمی‌کرد — سفارش بدون پرداخت واقعی «paid» می‌شد.
   * اکنون همه‌چیز در یک تراکنش اتمیک مونگو انجام می‌شود:
   *   (۱) قفل/بررسی کیف پول واقعی کاربر، (۲) ایجاد سفارش،
   *   (۳) کسر اتمیک موجودی، (۴) کاهش موجودی محصولات.
   * اگر هر گام شکست بخورد، کل تراکنش rollback می‌شود.
   * @param {Object} orderData - داده‌های سفارش
   * @param {Object} user - کاربر
   * @returns {Promise<Object>} - سفارش ایجاد شده
   */
  createOrderWithWalletPayment: async (orderData, user) => {
    const amount = orderData.totalAmount;
    const session = await mongoose.startSession();
    
    try {
      let order;
      let newBalance = null;
      await session.withTransaction(async () => {
        // ۱) کیف پول واقعی کاربر
        const wallet = await Wallet.findOne({ user: user._id, isActive: true }).session(session);
        
        if (!wallet) {
          throw new AppError('کیف پول یافت نشد. ابتدا کیف پول خود را بسازید', 400);
        }
        
        const availableBalance = wallet.balance - wallet.lockedBalance;
        if (availableBalance < amount) {
          throw new AppError(
            `موجودی کیف پول کافی نیست. موجودی قابل استفاده: ${availableBalance.toLocaleString('fa-IR')}، مورد نیاز: ${amount.toLocaleString('fa-IR')}`,
            400
          );
        }
        
        // ۲) ایجاد سفارش داخل همان تراکنش
        const transactionId = `wtx_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
        orderData.payment.status = 'completed';
        orderData.payment.transactionId = transactionId;
        orderData.payment.paidAt = new Date();
        orderData.status = 'paid';
        
        const created = await Order.create([orderData], { session });
        order = created[0];
        
        // ۳) کسر اتمیک موجودی (مشروط به مانده کافی — جلوگیری از موجودی منفی)
        const updatedWallet = await Wallet.findOneAndUpdate(
          {
            _id: wallet._id,
            isActive: true,
            balance: { $gte: wallet.lockedBalance + amount }
          },
          {
            $inc: {
              balance: -amount,
              'stats.totalTransactions': 1,
              'stats.successfulTransactions': 1,
              __v: 1
            },
            $set: { 'stats.lastActivityDate': new Date(), updatedAt: new Date() }
          },
          { session, new: true }
        );
        
        if (!updatedWallet) {
          throw new AppError('پرداخت با کیف پول ناموفق بود (تداخل همزمانی)', 400);
        }
        
        newBalance = updatedWallet.balance;
        
        // ۴) کاهش موجودی محصولات داخل همان تراکنش
        for (const item of orderData.items) {
          const product = await Product.findById(item.product).session(session);
          
          if (!product) {
            throw new AppError(`محصول ${item.productName} یافت نشد`, 400);
          }
          
          if (product.stock < item.quantity) {
            throw new AppError(`موجودی ${product.name} کافی نیست`, 400);
          }
          
          product.stock -= item.quantity;
          product.inStock = product.stock > 0;
          await product.save({ session });
        }
      });
      
      logger.info(`سفارش با پرداخت واقعی کیف پول ایجاد شد`, {
        userId: user._id,
        orderId: order._id,
        orderNumber: order.orderNumber,
        amount,
        remainingBalance: newBalance
      });
      
      return order;
      
    } catch (error) {
      logger.error('خطا در ایجاد سفارش با کیف پول:', error);
      throw error;
    } finally {
      session.endSession();
    }
  },
  
  /**
   * کاهش موجودی محصولات پس از سفارش
   * @param {Array} items - آیتم‌های سفارش
   * @returns {Promise<void>}
   */
  decreaseProductStock: async (items) => {
    const session = await Product.startSession();
    
    try {
      session.startTransaction();
      
      for (const item of items) {
        const product = await Product.findById(item.product).session(session);
        
        if (!product) {
          throw new AppError(`محصول ${item.product} یافت نشد`, 404);
        }
        
        if (product.stock < item.quantity) {
          throw new AppError(
            `موجودی محصول ${product.name} کافی نیست. موجودی: ${product.stock}, فروخته شده: ${item.quantity}`,
            400
          );
        }
        
        product.stock -= item.quantity;
        product.inStock = product.stock > 0;
        
        await product.save({ session });
      }
      
      await session.commitTransaction();
      
      logger.info(`موجودی ${items.length} محصول کاهش یافت`);
      
    } catch (error) {
      await session.abortTransaction();
      logger.error('خطا در کاهش موجودی محصولات:', error);
      throw error;
    } finally {
      session.endSession();
    }
  },
  
  /**
   * بازگرداندن موجودی محصولات پس از لغو سفارش
   * @param {Array} items - آیتم‌های سفارش
   * @returns {Promise<void>}
   */
  restoreProductStock: async (items) => {
    const session = await Product.startSession();
    
    try {
      session.startTransaction();
      
      for (const item of items) {
        const product = await Product.findById(item.product).session(session);
        
        if (!product) {
          // اگر محصول حذف شده، ادامه بده
          continue;
        }
        
        product.stock += item.quantity;
        product.inStock = true;
        
        await product.save({ session });
      }
      
      await session.commitTransaction();
      
      logger.info(`موجودی ${items.length} محصول بازگردانده شد`);
      
    } catch (error) {
      await session.abortTransaction();
      logger.error('خطا در بازگرداندن موجودی محصولات:', error);
      throw error;
    } finally {
      session.endSession();
    }
  },
  
  /**
   * ایجاد درخواست پرداخت زرین‌پال
   * تفکیک صریح: با ZARINPAL_SANDBOX=true درگاه شبیه‌سازی‌شده و مسیر آزمایشی
   * همان verify داخلی بک‌اند است؛ در غیر این صورت درخواست واقعی به API زرین‌پال
   * ارسال می‌شود و در صورت نبود MERCHANT_ID با خطای واضح متوقف می‌شود (هیچ
   * موفقیت جعلی‌ای وجود ندارد).
   * @param {Object} order - سفارش
   * @returns {Promise<Object>} - اطلاعات پرداخت
   */
  createZarinpalPayment: async (order) => {
    try {
      const merchantId = process.env.ZARINPAL_MERCHANT_ID;
      
      // در حالت واقعی مرچنت معتبر الزامی است؛ در حالت شبیه‌سازی‌شده هیچ تماس
      // واقعی زده نمی‌شود و placeholder هم پذیرفته می‌شود (تست بدون پیکربندی).
      if (!ZARINPAL_SANDBOX && (!merchantId || merchantId.includes('xxxx'))) {
        throw new AppError(
          'درگاه پرداخت پیکربندی نشده است (ZARINPAL_MERCHANT_ID نامعتبر است)',
          500
        );
      }
      
      if (ZARINPAL_SANDBOX) {
        logger.warn('ZARINPAL_SANDBOX=true — درگاه پرداخت شبیه‌سازی‌شده است و پرداخت واقعی انجام نمی‌شود.');
      }
      
      const payload = {
        merchant_id: merchantId,
        amount: order.totalAmount, // تومان
        description: `پرداخت سفارش ${order.orderNumber} - HTLand`,
        callback_url: `${process.env.BACKEND_URL || process.env.APP_URL || ''}/api/v1/orders/payment/verify`,
        metadata: {
          order_id: order.orderNumber,
          mobile: order.shippingAddress.recipientPhone
        }
      };
      
      let authority;
      
      if (ZARINPAL_SANDBOX) {
        // شبیه‌ساز محلی: authority ساختگی ولی کاملاً علامت‌گذاری‌شده
        authority = `SANDBOX${Date.now()}${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
      } else {
        // درخواست واقعی به API زرین‌پال (v4)
        const response = await axios.post(
          `${ZARINPAL_API}/request.json`,
          payload,
          { timeout: 15000, headers: { 'Content-Type': 'application/json', Accept: 'application/json' } }
        );
        
        const data = response.data?.data;
        if (response.data?.errors?.length || !data || data.code !== 100 || !data.authority) {
          const msg = response.data?.errors?.message || response.data?.errors?.[0]?.message || 'درگاه پرداخت درخواست را نپذیرفت';
          throw new AppError(`خطا در ایجاد درخواست پرداخت زرین‌پال: ${msg}`, 400);
        }
        authority = data.authority;
      }
      
      // FIX (sandbox): با ZARINPAL_SANDBOX=true درگاه شبیه‌سازی‌شده همان verify داخلی بک‌اند است
      // تا چرخه پرداخت → تأیید → بازگشت به فرانت به‌صورت کامل قابل آزمایش باشد.
      const paymentUrl = ZARINPAL_SANDBOX
        ? `${process.env.BACKEND_URL || ''}/api/v1/orders/payment/verify?Authority=${authority}&Status=OK`
        : `${ZARINPAL_STARTPAY}${authority}`;
      
      return {
        success: true,
        sandbox: ZARINPAL_SANDBOX,
        authority,
        paymentUrl,
        amount: order.totalAmount
      };
      
    } catch (error) {
      logger.error('خطا در ایجاد درخواست پرداخت زرین‌پال:', error);
      throw error instanceof AppError ? error : new AppError('خطا در ارتباط با درگاه پرداخت', 500);
    }
  },
  
  /**
   * تایید پرداخت زرین‌پال
   * SECURITY FIX: قبلاً همیشه «موفق» ساختگی برمی‌گشت — حتی با ZARINPAL_SANDBOX=false.
   * اکنون: در حالت sandbox پرداخت شبیه‌سازی می‌شود (و صریحاً علامت‌گذاری می‌شود)،
   * در حالت واقعی حتماً verify واقعی زرین‌پال فراخوانی می‌شود و مبلغ بررسی می‌گردد.
   * @param {string} authority - کد authority
   * @param {number} amount - مبلغ (تومان)
   * @returns {Promise<Object>} - نتیجه تایید
   */
  verifyZarinpalPayment: async (authority, amount) => {
    try {
      // درگاه شبیه‌سازی‌شده: فقط authorityهای صادرشده توسط همین بک‌اند در حالت sandbox پذیرفته می‌شوند
      if (ZARINPAL_SANDBOX) {
        if (!authority || !String(authority).startsWith('SANDBOX')) {
          throw new AppError('کد پرداخت نامعتبر است (خارج از درگاه شبیه‌سازی‌شده)', 400);
        }
        logger.warn('ZARINPAL_SANDBOX=true — تأیید پرداخت شبیه‌سازی شد؛ پرداخت واقعی انجام نشده است.');
        return {
          success: true,
          sandbox: true,
          refId: `SBX${Date.now()}`,
          cardPan: null,
          cardHash: null,
          fee: 0
        };
      }
      
      // حالت واقعی: verify واقعی زرین‌پال
      const merchantId = process.env.ZARINPAL_MERCHANT_ID;
      if (!merchantId || merchantId.includes('xxxx')) {
        throw new AppError('درگاه پرداخت پیکربندی نشده است (ZARINPAL_MERCHANT_ID نامعتبر است)', 500);
      }
      
      const response = await axios.post(
        `${ZARINPAL_API}/verify.json`,
        {
          merchant_id: merchantId,
          amount,
          authority
        },
        { timeout: 15000, headers: { 'Content-Type': 'application/json', Accept: 'application/json' } }
      );
      
      const data = response.data?.data;
      const code = data?.code;
      
      // 100 = تأیید شد، 101 = قبلاً تأیید شده (idempotent)
      if (code !== 100 && code !== 101) {
        throw new AppError('تأیید پرداخت نزد درگاه ناموفق بود', 400);
      }
      
      // مبلغ بازگشتی درگاه باید با مبلغ سفارش یکی باشد
      if (code === 100 && Number(data.amount) !== Number(amount)) {
        logger.error('عدم تطابق مبلغ در verify زرین‌پال', { expected: amount, got: data.amount });
        throw new AppError('مبلغ تأییدشده با مبلغ سفارش مطابقت ندارد', 400);
      }
      
      return {
        success: true,
        sandbox: false,
        refId: data.ref_id,
        cardPan: data.card_pan || null,
        cardHash: data.card_hash || null,
        fee: data.fee || 0
      };
      
    } catch (error) {
      logger.error('خطا در تایید پرداخت زرین‌پال:', error);
      throw error instanceof AppError ? error : new AppError('تأیید پرداخت ناموفق بود', 400);
    }
  },
  
  /**
   * بازگشت وجه سفارش
   * @param {Object} order - سفارش
   * @returns {Promise<Object>} - نتیجه بازگشت وجه
   */
  refundPayment: async (order) => {
    try {
      if (order.payment.method === 'wallet') {
        // بازگشت به کیف پول
        return await orderService.refundToWallet(order);
      } else if (order.payment.method === 'zarinpal') {
        // بازگشت از زرین‌پال
        return await orderService.refundZarinpalPayment(order);
      } else {
        // برای سایر روش‌ها، فقط وضعیت را تغییر می‌دهیم
        order.payment.status = 'refunded';
        await order.save();
        
        return {
          success: true,
          message: 'وضعیت پرداخت به بازگشت وجه تغییر یافت',
          refundId: `ref_${Date.now()}`
        };
      }
      
    } catch (error) {
      logger.error('خطا در بازگشت وجه:', error);
      throw new AppError('خطا در فرآیند بازگشت وجه', 500);
    }
  },
  
  /**
   * بازگشت وجه به کیف پول — REAL credit (قبلاً ساختگی بود)
   * موجودی کیف پول واقعی کاربر در یک تراکنش اتمیک افزایش می‌یابد.
   * @param {Object} order - سفارش
   * @returns {Promise<Object>} - نتیجه بازگشت
   */
  refundToWallet: async (order) => {
    const session = await mongoose.startSession();
    
    try {
      let refundId;
      await session.withTransaction(async () => {
        const wallet = await Wallet.findOne({ user: order.user, isActive: true }).session(session);
        
        if (!wallet) {
          throw new AppError('کیف پول کاربر یافت نشد؛ بازگشت وجه انجام نشد', 400);
        }
        
        const refundAmount = order.payment.amount || order.totalAmount;
        refundId = `rtx_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
        
        const updatedWallet = await Wallet.findOneAndUpdate(
          { _id: wallet._id, isActive: true },
          {
            $inc: {
              balance: refundAmount,
              'stats.totalTransactions': 1,
              'stats.successfulTransactions': 1,
              __v: 1
            },
            $set: { 'stats.lastActivityDate': new Date(), updatedAt: new Date() }
          },
          { session, new: true }
        );
        
        if (!updatedWallet) {
          throw new AppError('بازگشت وجه به کیف پول ناموفق بود', 400);
        }
        
        logger.info('بازگشت وجه به کیف پول انجام شد', {
          walletId: wallet._id,
          userId: order.user.toString(),
          orderId: order._id.toString(),
          refundId,
          refundAmount,
          newBalance: updatedWallet.balance
        });
      });
      
      if (order.payment.status !== 'refunded') {
        order.payment.status = 'refunded';
        await order.save();
      }
      
      return {
        success: true,
        refundId,
        message: 'وجه به کیف پول شما بازگشت داده شد'
      };
      
    } catch (error) {
      logger.error('خطا در بازگشت وجه به کیف پول:', error);
      throw error;
    } finally {
      session.endSession();
    }
  },
  
  /**
   * بازگشت وجه از زرین‌پال
   * @param {Object} order - سفارش
   * @returns {Promise<Object>} - نتیجه بازگشت
   */
  refundZarinpalPayment: async (order) => {
    try {
      // اینجا باید API بازگشت وجه زرین‌پال فراخوانی شود
      // برای نمونه:
      
      return {
        success: true,
        refundId: `zref_${Date.now()}`,
        message: 'درخواست بازگشت وجه ثبت شد. طی ۷۲ ساعت کاری انجام می‌شود.'
      };
      
    } catch (error) {
      logger.error('خطا در بازگشت وجه زرین‌پال:', error);
      throw error;
    }
  },
  
  /**
   * ارسال نوتیفیکیشن سفارش
   * @param {Object} order - سفارش
   * @param {string} event - رویداد
   * @returns {Promise<void>}
   */
  sendOrderNotification: async (order, event) => {
    try {
      const notifications = {
        created: {
          title: 'سفارش جدید ثبت شد',
          message: `سفارش ${order.orderNumber} با موفقیت ثبت شد.`,
          type: 'info'
        },
        paid: {
          title: 'پرداخت تایید شد',
          message: `پرداخت سفارش ${order.orderNumber} با موفقیت انجام شد.`,
          type: 'success'
        },
        status_updated: {
          title: 'وضعیت سفارش تغییر کرد',
          message: `وضعیت سفارش ${order.orderNumber} به "${order.statusFa}" تغییر یافت.`,
          type: 'info'
        },
        shipped: {
          title: 'سفارش ارسال شد',
          message: `سفارش ${order.orderNumber} ارسال شد. ${order.trackingCode ? `کد رهگیری: ${order.trackingCode}` : ''}`,
          type: 'info'
        },
        delivered: {
          title: 'سفارش تحویل داده شد',
          message: `سفارش ${order.orderNumber} با موفقیت تحویل داده شد.`,
          type: 'success'
        },
        cancelled: {
          title: 'سفارش لغو شد',
          message: `سفارش ${order.orderNumber} لغو شد.`,
          type: 'warning'
        }
      };
      
      const notification = notifications[event];
      if (!notification) return;
      
      // ارسال ایمیل
      await orderService.sendEmailNotification(order, notification);
      
      // ارسال پیامک
      await orderService.sendSMSNotification(order, notification);
      
      // ارسال نوتیفیکیشن درون‌برنامه‌ای (در صورت وجود)
      await orderService.sendPushNotification(order, notification);
      
      logger.info(`نوتیفیکیشن سفارش ارسال شد`, {
        orderId: order._id,
        orderNumber: order.orderNumber,
        event,
        userId: order.user
      });
      
    } catch (error) {
      logger.error('خطا در ارسال نوتیفیکیشن:', error);
      // این خطا نباید فرآیند اصلی را مختل کند
    }
  },
  
  /**
   * ارسال ایمیل نوتیفیکیشن
   */
  sendEmailNotification: async (order, notification) => {
    // پیاده‌سازی ارسال ایمیل
    // می‌توان از سرویس‌هایی مثل SendGrid, Mailgun, یا SMTP مستقیم استفاده کرد
  },
  
  /**
   * ارسال پیامک نوتیفیکیشن
   */
  sendSMSNotification: async (order, notification) => {
    // پیاده‌سازی ارسال پیامک
    // می‌توان از سرویس‌های ایرانی مثل پیامک، کاوه‌نگار، یا سیگنال استفاده کرد
  },
  
  /**
   * ارسال نوتیفیکیشن درون‌برنامه‌ای
   */
  sendPushNotification: async (order, notification) => {
    // پیاده‌سازی ارسال push notification
    // می‌توان از FCM (Firebase Cloud Messaging) استفاده کرد
  },
  
  /**
   * دریافت آمار مدیریتی
   * @returns {Promise<Object>} - آمار ادمین
   */
  getAdminStatistics: async () => {
    try {
      const stats = await Order.aggregate([
        {
          $facet: {
            // آمار روزانه
            dailyStats: [
              {
                $group: {
                  _id: {
                    year: { $year: '$createdAt' },
                    month: { $month: '$createdAt' },
                    day: { $dayOfMonth: '$createdAt' }
                  },
                  count: { $sum: 1 },
                  revenue: { $sum: '$totalAmount' }
                }
              },
              { $sort: { '_id.year': -1, '_id.month': -1, '_id.day': -1 } },
              { $limit: 7 }
            ],
            
            // آمار بر اساس استان
            provinceStats: [
              {
                $group: {
                  _id: '$shippingAddress.province',
                  count: { $sum: 1 },
                  revenue: { $sum: '$totalAmount' }
                }
              },
              { $sort: { count: -1 } },
              { $limit: 5 }
            ],
            
            // آمار بر اساس محصول
            productStats: [
              { $unwind: '$items' },
              {
                $group: {
                  _id: '$items.product',
                  productName: { $first: '$items.productName' },
                  quantity: { $sum: '$items.quantity' },
                  revenue: { $sum: '$items.totalPrice' },
                  orderCount: { $sum: 1 }
                }
              },
              { $sort: { quantity: -1 } },
              { $limit: 10 }
            ],
            
            // آمار بازگشت وجه
            refundStats: [
              { $match: { 'payment.status': 'refunded' } },
              {
                $group: {
                  _id: null,
                  count: { $sum: 1 },
                  amount: { $sum: '$payment.amount' }
                }
              }
            ]
          }
        }
      ]);
      
      return {
        dailyStats: stats[0]?.dailyStats || [],
        provinceStats: stats[0]?.provinceStats || [],
        productStats: stats[0]?.productStats || [],
        refundStats: stats[0]?.refundStats[0] || { count: 0, amount: 0 }
      };
      
    } catch (error) {
      logger.error('خطا در دریافت آمار ادمین:', error);
      return {};
    }
  },
  
  /**
   * گزارش‌گیری سفارشات
   * @param {Object} filters - فیلترها
   * @returns {Promise<Array>} - گزارش
   */
  generateOrderReport: async (filters = {}) => {
    try {
      const match = { isDeleted: false, ...filters };
      
      const orders = await Order.find(match)
        .populate('user', 'name email phone')
        .populate('items.product', 'name categoryFa')
        .sort('-createdAt')
        .lean();
      
      // فرمت گزارش
      const report = orders.map(order => ({
        orderNumber: order.orderNumber,
        customer: {
          name: order.user?.name || 'ناشناس',
          phone: order.shippingAddress.recipientPhone
        },
        items: order.items.map(item => ({
          name: item.productName,
          quantity: item.quantity,
          unitPrice: item.finalUnitPrice,
          total: item.totalPrice
        })),
        totals: {
          subtotal: order.subtotal,
          discount: order.discount,
          shipping: order.shippingCost,
          tax: order.tax || 0,
          total: order.totalAmount
        },
        status: order.status,
        statusFa: order.statusFa,
        orderedAt: order.timeline.orderedAt,
        paidAt: order.timeline.paidAt,
        deliveredAt: order.timeline.deliveredAt,
        shippingAddress: {
          province: order.shippingAddress.province,
          city: order.shippingAddress.city,
          address: order.shippingAddress.address
        },
        payment: {
          method: order.payment.method,
          status: order.payment.status,
          amount: order.payment.amount
        }
      }));
      
      return report;
      
    } catch (error) {
      logger.error('خطا در تولید گزارش سفارشات:', error);
      throw error;
    }
  }
};

module.exports = orderService;