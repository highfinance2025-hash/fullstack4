const Redis = require('ioredis');
const logger = require('../utils/logger');
const config = require('./env.config');

/**
 * SECURITY / RELIABILITY FIX:
 * قبلاً این فایل همیشه یک کلاینت ioredis واقعی می‌ساخت — حتی وقتی
 * USE_REDIS=false بود. نتیجه: لوپ بی‌پایان اتصال مجدد در محیط‌های بدون
 * Redis و غیرفعال‌شدنِ خاموشِ rate limiting سرویس احراز هویت.
 * اکنون با USE_REDIS=false یک fallback درون‌حافظه‌ای (محدود اما سازگار
 * با همین زیرمجموعه از دستورات) ارائه می‌شود.
 */

class InMemoryRedis {
  constructor() {
    this.store = new Map(); // key -> { value, type, expiresAt }
    this.listeners = {};
  }

  _alive(entry) {
    if (!entry) return false;
    if (entry.expiresAt && entry.expiresAt < Date.now()) {
      this.store.delete(entry.key);
      return false;
    }
    return true;
  }

  _set(key, value, type) {
    this.store.set(key, { key, value, type, expiresAt: null });
  }

  async get(key) {
    const e = this.store.get(key);
    return this._alive(e) && e.type === 'string' ? e.value : null;
  }

  async set(key, value) {
    this._set(key, String(value), 'string');
    return 'OK';
  }

  async setex(key, ttlSeconds, value) {
    this._set(key, String(value), 'string');
    this.store.get(key).expiresAt = Date.now() + ttlSeconds * 1000;
    return 'OK';
  }

  async del(...keys) {
    let n = 0;
    for (const k of keys) {
      if (this.store.delete(k)) n++;
    }
    return n;
  }

  async keys(pattern) {
    // تبدیل الگوی ساده redis (prefix* یا *) به regex
    const regex = new RegExp('^' + pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
    const out = [];
    for (const [k, e] of this.store) {
      if (this._alive(e) && regex.test(k)) out.push(k);
    }
    return out;
  }

  async lrange(key, start, stop) {
    const e = this.store.get(key);
    if (!this._alive(e) || e.type !== 'list') return [];
    const n = e.value.length;
    let s = start < 0 ? Math.max(n + start, 0) : start;
    let en = stop < 0 ? n + stop + 1 : Math.min(stop + 1, n);
    return e.value.slice(s, en);
  }

  async lpush(key, value) {
    const e = this.store.get(key);
    if (e && this._alive(e) && e.type === 'list') {
      e.value.unshift(String(value));
    } else {
      this._set(key, [String(value)], 'list');
    }
    return this.store.get(key).value.length;
  }

  async ltrim(key, start, stop) {
    const e = this.store.get(key);
    if (this._alive(e) && e.type === 'list') {
      e.value = e.value.slice(start, stop + 1);
    }
    return 'OK';
  }

  async expire(key, ttlSeconds) {
    const e = this.store.get(key);
    if (this._alive(e)) {
      e.expiresAt = Date.now() + ttlSeconds * 1000;
      return 1;
    }
    return 0;
  }

  async ping() {
    return 'PONG';
  }

  async quit() {
    return 'OK';
  }

  async disconnect() {
    this.store.clear();
  }

  async flushAll() {
    this.store.clear();
    return 'OK';
  }

  async connect() {
    // no-op برای سازگاری با ioredis
  }

  on() { /* no-op */ }
}

let redisClient;

if (config.redis.enabled === false || process.env.USE_REDIS === 'false') {
  logger.info('USE_REDIS=false — using in-memory fallback (rate-limit/cache without Redis)');
  redisClient = new InMemoryRedis();
  redisClient.healthCheck = async () => ({ status: 'healthy (in-memory)', latency: 0 });
} else {
  redisClient = new Redis(config.redis.url, {
    maxRetriesPerRequest: 3,
    retryStrategy(times) {
      const delay = Math.min(times * 100, 3000);
      return delay;
    }
  });

  redisClient.on('connect', () => {
    logger.info('✅ Redis Connected');
  });

  redisClient.on('error', (err) => {
    logger.error('❌ Redis Error:', err.message);
  });

  redisClient.healthCheck = async () => {
    try {
      const start = Date.now();
      await redisClient.ping();
      return { status: 'healthy', latency: Date.now() - start };
    } catch (err) {
      return { status: 'unhealthy', error: err.message };
    }
  };
}

module.exports = redisClient;
// سازگاری با destructuring: const { redisClient } = require('.../redis.config')
module.exports.redisClient = redisClient;
