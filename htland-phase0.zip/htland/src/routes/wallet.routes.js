const express = require('express');
const router = express.Router();
const walletController = require('../controllers/walletController');
const authMiddleware = require('../middlewares/auth.middleware');

// همه routes نیاز به احراز هویت دارند
router.use(authMiddleware.authenticate());

// ایجاد کیف پول جدید
router.post('/create', walletController.createWallet);

// دریافت تمام کیف پول‌های کاربر
router.get('/', walletController.getUserWallets);

// دریافت اطلاعات کیف پول خاص (سرویس مالکیت را با userId بررسی می‌کند)
router.get('/:walletId', walletController.getWallet);

// ⚠️ عمداً حذف شده‌اند (عملیات مالی نباید مستقیم از API عمومی قابل‌فراخوانی باشند):
//  - POST /deposit  → شارژ فقط بعد از verify موفق درگاه و از داخل سرور
//  - POST /withdraw → تا ساخته‌شدن جریان تسویه با تأیید ادمین
//  - POST /lock, /unlock → فقط داخل سرویس سفارش

module.exports = router;
