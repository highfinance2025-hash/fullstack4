/**
 * @file روت‌های سبد خرید HTLand
 * @description تعریف مسیرهای API برای عملیات سبد خرید
 */

const express = require('express');
const router = express.Router();

const cartController = require('../controllers/cart.controller');
const authMiddleware = require('../middlewares/auth.middleware');
const cartMiddleware = require('../middlewares/cart.middleware');

// تمام مسیرهای سبد خرید نیاز به احراز هویت دارند
router.use(authMiddleware.authenticate());
router.use(cartMiddleware.cartRequestLogger);

// دریافت سبد خرید فعلی کاربر
router.get('/', cartController.getCart);

// افزودن آیتم به سبد خرید
router.post(
  '/items',
  cartMiddleware.validateCartItem,
  cartMiddleware.checkProductStock,
  cartMiddleware.checkCartItemLimit,
  cartController.addItem
);

// تغییر تعداد یک آیتم
router.put(
  '/items/:productId',
  cartMiddleware.checkProductStock,
  cartController.updateItemQuantity
);

// حذف یک آیتم از سبد خرید
router.delete('/items/:productId', cartController.removeItem);

// خالی کردن کل سبد خرید
router.delete('/', cartController.clearCart);

// اعمال کد تخفیف
router.post('/coupon', cartController.applyCoupon);

// حذف کد تخفیف
router.delete('/coupon', cartController.removeCoupon);

// به‌روزرسانی اطلاعات ارسال
router.put('/shipping', cartController.updateShipping);

// آماده‌سازی برای پرداخت نهایی
router.post(
  '/checkout/prepare',
  cartMiddleware.checkCartNotEmpty,
  cartMiddleware.checkPriceChanges,
  cartController.prepareCheckout
);

// همگام‌سازی سبد خرید بین دستگاه‌ها
router.post('/sync', cartController.syncCart);

module.exports = router;