/**
 * HTLand — Integration tests for the implemented/fixed flows
 * Runs against a real MongoDB (replica set) via MONGODB_TEST_URI.
 *   MONGODB_TEST_URI="mongodb://127.0.0.1:27017/htland_test" npx jest src/tests/integration/htland-fixes.integration.test.js --forceExit
 * Covers:
 *  - req.user identity fixes (_id/userId/isAdmin)
 *  - product lookup by slug (regression for CastError)
 *  - OTP auth flow payloads (send-otp / verify-otp) incl. wrong-OTP rejection
 *  - cart operations (add/update/coupon/prepare)
 *  - address creation + order creation using the REAL address (regression for hardcoded address)
 *  - orderNumber generation in pre('validate') (regression: required orderNumber failed)
 *  - wallet deposit/withdraw via real endpoints (regression: shadowed __v broke optimistic lock)
 */

const request = require('supertest');
const mongoose = require('mongoose');

const app = require('../../app');
const User = require('../../models/User.model');
const Product = require('../../models/Product.model');

const MONGO_URI = process.env.MONGODB_TEST_URI || 'mongodb://127.0.0.1:27017/htland_test?replicaSet=rs0';

let token;
let phone;
let product;
let addressId;
let orderId;

const toman = (n) => n; // clarity helper

beforeAll(async () => {
  await mongoose.connect(MONGO_URI);
  phone = '0912' + String(Date.now()).slice(-7);
  // unique product for this run
  const admin = await User.findOneAndUpdate(
    { phone: '09120000000' },
    { $setOnInsert: { phone: '09120000000', fullName: 'مدیر تست', role: 'admin', isActive: true } },
    { upsert: true, new: true }
  );
  product = await Product.findOneAndUpdate(
    { slug: `test-slug-product-${Date.now()}` },
    {
      $setOnInsert: {
        name: 'محصول تست یکپارچگی',
        description: 'توضیحات محصول آزمایشی برای تست‌های یکپارچگی اچ‌تی‌لند که بیش از ده کاراکتر است.',
        price: 250000,
        discountPrice: 225000,
        category: 'honey',
        categoryFa: 'عسل طبیعی',
        image: '/images/brand/honey-1.svg',
        stock: 10,
        inStock: true,
        active: true,
        tags: ['تست'],
        createdBy: admin._id,
      },
    },
    { upsert: true, new: true }
  );
});

afterAll(async () => {
  await mongoose.connection.dropDatabase().catch(() => undefined);
  await mongoose.connection.close();
});

describe('Auth — OTP flow (real payload names)', () => {
  it('send-otp accepts {phone} and returns dev otpCode', async () => {
    const res = await request(app).post('/api/v1/auth/send-otp').send({ phone });
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.otpCode).toBeDefined();
  });

  it('verify-otp rejects a wrong 6-digit code', async () => {
    const res = await request(app).post('/api/v1/auth/verify-otp').send({ phone, otpCode: '000000' });
    expect(res.status).toBe(400);
  });

  it('verify-otp with {phone, otpCode} returns user+token', async () => {
    const send = await request(app).post('/api/v1/auth/send-otp').send({ phone });
    const otpCode = send.body.data.otpCode;
    const res = await request(app)
      .post('/api/v1/auth/verify-otp')
      .send({ phone, otpCode, acceptedTerms: true, acceptedPrivacy: true });
    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
    expect(res.body.data.user.phone).toBe(phone);
    token = res.body.data.token;
  });

  it('profile endpoints resolve the user (req.user._id/userId fix)', async () => {
    const auth = await request(app).get('/api/v1/auth/profile').set('Authorization', `Bearer ${token}`);
    expect(auth.status).toBe(200);
    expect(auth.body.data.user.phone).toBe(phone);

    const prof = await request(app).get('/api/v1/profile').set('Authorization', `Bearer ${token}`);
    expect(prof.status).toBe(200);
  });
});

describe('Products — slug lookup regression', () => {
  it('GET /api/v1/products/:slug returns the product (no CastError)', async () => {
    const res = await request(app).get(`/api/v1/products/${product.slug}`);
    expect(res.status).toBe(200);
    expect(res.body.data.slug).toBe(product.slug);
    // backend does not expose finalPrice/discountPercentage — the frontend derives them
    expect(res.body.data.discountPrice).toBe(toman(225000));
    expect(res.body.data.price).toBe(toman(250000));
  });

  it('GET /api/v1/products list carries pagination metadata', async () => {
    const res = await request(app).get('/api/v1/products?limit=5');
    expect(res.status).toBe(200);
    expect(res.body.pagination).toMatchObject({ total: expect.any(Number), page: 1 });
  });
});

describe('Cart — authenticated operations', () => {
  it('add → update → coupon → prepareCheckout all work', async () => {
    const add = await request(app)
      .post('/api/v1/cart/items')
      .set('Authorization', `Bearer ${token}`)
      .send({ productId: product._id.toString(), quantity: 2 });
    expect(add.status).toBe(200);
    expect(add.body.data.cartSummary.totalItems).toBe(2);

    const upd = await request(app)
      .put(`/api/v1/cart/items/${product._id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ quantity: 3 });
    expect(upd.status).toBe(200);
    expect(upd.body.data.cartSummary.totalItems).toBe(3);

    const coupon = await request(app)
      .post('/api/v1/cart/coupon')
      .set('Authorization', `Bearer ${token}`)
      .send({ couponCode: 'HTLAND10' });
    expect(coupon.status).toBe(200);
    expect(coupon.body.data.discountPercentage).toBe(10);

    const prep = await request(app).post('/api/v1/cart/checkout/prepare').set('Authorization', `Bearer ${token}`);
    expect(prep.status).toBe(200);
    expect(prep.body.data.canCheckout).toBe(true);
  });
});

describe('Addresses + Orders — real address in order creation', () => {
  it('creates an address and uses it for the order (city must match)', async () => {
    const create = await request(app)
      .post('/api/v1/addresses')
      .set('Authorization', `Bearer ${token}`)
      .send({
        fullName: 'کاربر تست',
        phone,
        province: 'مازندران',
        city: 'آمل',
        address: `خیابان تست ${Date.now()}، ساختمان یکپارچگی، پلاک ۲`,
        postalCode: '4811111111',
        label: 'خانه',
      });
    expect([200, 201]).toContain(create.status);
    addressId = create.body.data._id;

    const order = await request(app)
      .post('/api/v1/orders')
      .set('Authorization', `Bearer ${token}`)
      .send({ shippingAddressId: addressId, paymentMethod: 'cash_on_delivery', notes: 'تست یکپارچگی' });
    expect(order.status).toBe(201);
    expect(order.body.data.orderNumber).toMatch(/^HT-\d{8}-\d{5}$/);
    orderId = order.body.data.orderId;

    const detail = await request(app).get(`/api/v1/orders/${orderId}`).set('Authorization', `Bearer ${token}`);
    expect(detail.status).toBe(200);
    expect(detail.body.data.order.shippingAddress.city).toBe('آمل');
  });

  it('order tracking requires the matching recipient phone (ownership guard)', async () => {
    const detail = await request(app).get(`/api/v1/orders/${orderId}`).set('Authorization', `Bearer ${token}`);
    const orderNumber = detail.body.data.order.orderNumber;

    // بدون شماره موبایل → 400
    const noPhone = await request(app).get(`/api/v1/orders/track/${orderNumber}`);
    expect(noPhone.status).toBe(400);

    // شماره ناهمسان → 403
    const wrongPhone = await request(app).get(`/api/v1/orders/track/${orderNumber}?phone=09120001122`);
    expect(wrongPhone.status).toBe(403);

    // شماره منطبق (همان شماره صاحب سفارش) → 200
    const track = await request(app).get(`/api/v1/orders/track/${orderNumber}?phone=${phone}`);
    expect(track.status).toBe(200);
    expect(track.body.data.orderNumber).toBe(orderNumber);
  });
});

describe('Wallet — financial endpoints are NOT publicly callable (security regression)', () => {
  it('create works; deposit/withdraw/lock/unlock return 404 and balance never changes', async () => {
    const created = await request(app).post('/api/v1/wallet/create').set('Authorization', `Bearer ${token}`);
    expect(created.status).toBeLessThan(500);
    const walletId = created.body?.data?.walletId || created.body?.data?._id;
    expect(walletId).toBeTruthy();

    for (const path of ['deposit', 'withdraw', 'lock', 'unlock']) {
      const res = await request(app)
        .post(`/api/v1/wallet/${path}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ walletId, amount: 100000 });
      expect(res.status).toBe(404);
    }

    const after = await request(app).get('/api/v1/wallet').set('Authorization', `Bearer ${token}`);
    expect(after.status).toBe(200);
    expect(after.body.data.wallets[0].balance).toBe(0);
  });
});
