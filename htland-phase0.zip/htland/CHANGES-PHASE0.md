# تغییرات فاز ۰ (اضطراری)

## امنیت مالی
- حذف `POST /api/v1/wallet/deposit|withdraw|lock|unlock` از routes و controller (قبلاً هر کاربر می‌توانست موجودی رایگان بسازد یا مبلغ رزروشده را آزاد کند). سرویس‌ها (`walletService`) برای استفادهٔ داخلی سرور باقی ماندند.
- صفحهٔ کیف پول فرانت: دکمه‌های شارژ/برداشت و `walletApi.deposit/withdraw` حذف شدند.
- `ZARINPAL_SANDBOX=true` با `NODE_ENV=production` دیگر فقط هشدار نیست؛ سرور بالا نمی‌آید. پیش‌فرض `.env.example` روی `false` است.
- `verifyPayment` اتمیک شد (`pending → processing` با `findOneAndUpdate`)؛ دو callback همزمان دیگر موجودی انبار را دوبار کم نمی‌کنند. اگر کاهش انبار بعد از پرداخت موفق خطا بدهد، به‌جای «پرداخت ناموفق» لاگ CRITICAL ثبت می‌شود. در خطای verify وضعیت به `pending` برمی‌گردد تا تلاش مجدد ممکن باشد. (`processing` به enum وضعیت پرداخت اضافه شد.)

## پاک‌سازی
- حذف فرانت قدیمی: `index.html`, `js/`, `css/`, `src/api.js` (و سرو استاتیک `/css` و `/js` در `app.js`).
- نام پروژه در `package.json` اصلاح شد.
- `src/validators/product.validator.js` دو فایل چسبیده به هم بود (SyntaxError در صورت require)؛ نسخهٔ کامل‌تر نگه داشته شد.
- مستندات endpointها در `app.js` با routeهای واقعی هماهنگ شد.

## Docker
- Dockerfile حالا فرانت را در یک stage جدا build می‌کند (قبلاً `frontend/dist` در image ساخته نمی‌شد). `frontend/dist` و `node_modules` دیگر در zip نیستند.

## تست‌ها
- تست integration کیف پول: اکنون ثابت می‌کند deposit/withdraw/lock/unlock همه 404 می‌دهند و موجودی تغییر نمی‌کند.
- `scripts/smoke-test.mjs`: همین بررسی را انجام می‌دهد؛ بخش «سفارش با کیف پول» فقط وقتی اجرا می‌شود که کیف پول با seed موجودی داشته باشد.

## هنوز باید انجام شود (خارج از این فاز)
- چرخش کلیدها (JWT_SECRET, ENCRYPTION_KEY, Cloudinary, مرچنت زرین‌پال) اگر قبلاً در آرشیو بوده‌اند.
- شارژ کیف پول از مسیر درگاه (فاز ۲).
- تست یک پرداخت واقعی با مرچنت واقعی.
- اجرای `npm ci && npm test` و `cd frontend && npm ci && npm run build` (این تغییرات در محیط بدون دسترسی به رجیستری npm نوشته شده‌اند و فقط syntax-check شده‌اند).
