# HTLand — فروشگاه آنلاین محصولات شمال ایران

فروشگاه اینترنتی HTLand: بک‌اند Node.js/Express + MongoDB و فرانت‌اند React/TypeScript (Vite + Tailwind 4 + RTL) با تجربه خرید کامل (کاتالوگ، سبد خرید مهمان/کاربر، ورود با OTP، تسویه‌حساب مرحله‌ای، پرداخت کیف پول/زرین‌پال، پیگیری سفارش).

---

## ۱) پیش‌نیازها

| نرم‌افزار | نسخه | الزامی؟ |
|---|---|---|
| Node.js | ≥ 18 (توصیه: 20 LTS) | الزامی |
| npm | ≥ 9 | الزامی (یا bun ≥ 1) |
| MongoDB | ≥ 6 — **به‌صورت Replica Set** | الزامی |
| Redis | هر نسخه پایدار | اختیاری |

**چرا Replica Set؟** تراکنش‌های چندسندی (پرداخت کیف پول + ایجاد سفارش + کاهش موجودی) به تراکنش مونگو نیاز دارند که فقط روی replica set کار می‌کند. برای توسعه محلی، یک نود کافی است:

```bash
# مثال لینوکس/مک — شروع مونگو به‌صورت single-node replica set
mongod --dbpath /path/to/data --replSet rs0 --bind_ip 127.0.0.1
# سپس یک‌بار:
mongosh --eval 'rs.initiate()'
```

**Redis اختیاری است.** با `USE_REDIS=false` اپلیکیشن از fallback درون‌حافظه‌ای استفاده می‌کند (rate limiting احراز هویت و کش تک‌پردازشی همچنان کار می‌کنند). برای دیپلوی چندنمونه‌ای، Redis واقعی را تنظیم کنید.

## ۲) نصب و راه‌اندازی محلی

```bash
# ۱) نصب وابستگی‌های بک‌اند
npm install            # یا: bun install

# ۲) نصب وابستگی‌های فرانت‌اند
cd frontend && npm install && cd ..

# ۳) متغیرهای محیطی
cp .env.example .env   # سپس مقادیر JWT_SECRET و ENCRYPTION_KEY را واقعی کنید
# توسعه محلی پیشنهادی: ZARINPAL_SANDBOX=true و USE_REDIS=false بمانند

# ۴) داده اولیه (فقط توسعه/تست — در production مسدود است)
node scripts/seed.js

# ۵) ساخت فرانت‌اند
cd frontend && npm run build && cd ..

# ۶) اجرا
npm start              # http://localhost:3000
# حالت توسعه بک‌اند: npm run dev
# حالت توسعه فرانت‌اند: cd frontend && npm run dev  (پروکسی به :3000)
```

اسکریپت راه‌اندازی همه‌در‌یک برای توسعه نیز موجود است: `scripts/start-htland.sh`.

### حساب‌های seed (فقط توسعه/تست)

| حساب | شماره | توضیح |
|---|---|---|
| ادمین | `09120000000` | نقش admin، ورود فقط با OTP |
| مشتری نمونه | `09121112233` | کیف پول ۸۰۰٬۰۰۰ تومان + آدرس نمونه |

- در `NODE_ENV=production` اجرای seed به‌صورت پیش‌فرض **مسدود** است و فقط با `SEED_ALLOW_PRODUCTION=true` (تصریح صریح) ممکن می‌شود.
- هیچ رمز عبور پیش‌فرضی وجود ندارد؛ ورود فقط با OTP است و در production کد فقط از طریق پیامک واقعی (`SMS_API_KEY`) ارسال می‌شود.
- `mongo-init.js` فقط برای docker-compose توسعه است؛ اعتبار مونگوی آن را هرگز در production استفاده نکنید.

## ۳) اجرای آزمون‌ها

```bash
npm test                                   # کل suite با jest
node scripts/smoke-test.mjs                # E2E روی HTTP واقعی (سرور باید روشن باشد)
```

خروجی واقعی آخرین اجرا در سند تحویل آمده است.

## ۴) مهاجرت الزامی: حذف ایندکس TTL سفارشات

نسخه‌های قبلی مدل Order فیلد `expiresAt` را با default «now + 30 روز» و ایندکس TTL تعریف می‌کردند؛ مونگو تمام سفارش‌ها (حتی پرداخت‌شده/تحویل‌شده) را ۳۰ روز پس از ثبت **خودکار حذف می‌کرد**. کد فعلی ایندکس را ندارد، اما اگر دیتابیس شما قبلاً با کد قدیم بالا آمده باشد، ایندکس TTL همچنان در مونگو باقی است و باید یک‌بار حذف شود:

```bash
# فقط گزارش (بدون تغییر):
DRY_RUN=true node scripts/migrations/remove-order-ttl-index.js

# اجرای واقعی (فقط ایندکس حذف می‌شود؛ هیچ سندی تغییر یا حذف نمی‌شود):
node scripts/migrations/remove-order-ttl-index.js
```

این مهاجرت idempotent است و در هر محیط (dev/staging/production) یک‌بار باید اجرا شود. حذف خودکار سفارش مشتری هیچ‌گاه نیازمند تأیید کسب‌وکار نیست؛ اگر در آینده سیاست نگهداری/آرشیو سفارش خواستید، به‌صورت آگاهانه و با آرشیو پیاده‌سازی شود.

نکته: TTL سی‌روزه روی **سبد خرید** عمداً حفظ شده (پاکسازی سبد متروک رفتار استاندارد فروشگاه است).

## ۵) پرداخت: واقعی در برابر شبیه‌سازی‌شده

| حالت | رفتار | آماده production؟ |
|---|---|---|
| `ZARINPAL_SANDBOX=true` | درگاه **شبیه‌سازی‌شده**: authority با پیشوند `SANDBOX` صادر می‌شود، تأیید توسط خود بک‌اند شبیه‌سازی می‌شود، در لاگ‌ها هشدار صریح دارد و در production boot هم warning چاپ می‌شود | ❌ فقط تست |
| `ZARINPAL_SANDBOX=false` | فراخوانی واقعی API v4 زرین‌پال (request + verify) با بررسی تطابق مبلغ و پشتیبانی از کد ۱۰۱ | مسیر کد طبق مستندات زرین‌پال است اما **با مرچنت واقعی آزمایش نشده** — پیش از بهره‌برداری واقعی، یک تراکنش آزمایشی کم‌مبلغ بزنید |
| `paymentMethod: 'wallet'` | پرداخت **واقعی**: بررسی موجودی واقعی، کسر اتمیک در یک تراکنش مونگو (سفارش + کسر کیف پول + کاهش موجودی)، بازگشت وجه واقعی هنگام لغو | ✅ |
| `bank_transfer` / `cash_on_delivery` | سفارش با پرداخت `pending` ثبت می‌شود؛ تسویه دستی | ✅ (بدون درگاه) |

## ۶) نکات امنیتی پیاده‌سازی‌شده

- **OTP:** تولید با `crypto.randomInt`، ذخیره هش bcrypt (بدون متن ساده)، انقضای ۲ دقیقه، حداکثر ۵ تلاش برای هر کد، rate limit لایه‌ای (IP+شماره). کد فقط در محیط غیر-production در پاسخ API می‌آید.
- **forgot-password:** کد واقعاً پیامک می‌شود و هرگز در پاسخ production برنمی‌گردد (قبلاً در پاسخ بود — نقض جدی).
- **JWT:** boot در production با `JWT_SECRET`/`ENCRYPTION_KEY` ناموجود یا placeholder/ضعیف متوقف می‌شود.
- **دسترسی:** همه روت‌های نویسه‌محصولات/تغییر وضعیت سفارش `admin`-gated؛ سفارش/سبد/کیف پول/آدرس هر کاربر فقط برای مالک (به‌جز ادمین).
- **کیف پول:** کسر/عودت با قفل اتمیک شرطی و تراکنش مونگو — موجودی منفی و پرداخت جعلی ناممکن است.
- **پیگیری سفارش:** عمومی اما منوط به تطابق شماره موبایل گیرنده.
- **CORS / Helmet / mongo-sanitize / rate-limit / اعتبارسنجی آپلود** فعال‌اند؛ توکن از query string پذیرفته نمی‌شود.
- در production بدون `SMS_API_KEY`، ارسال OTP با خطای واضح شکست می‌خورد (بدون موفقیت جعلی).

## ۷) ساختار پروژه

```
├─ src/                    # بک‌اند Express
│  ├─ app.js               # پیکربندی Express + سرو فرانت‌اند build شده + SPA fallback
│  ├─ server.js            # نقطه شروع
│  ├─ config/              # env, database, redis (fallback درون‌حافظه‌ای), zarinpal, swagger
│  ├─ routes/              # auth, products, cart, orders, addresses, profile, wallet
│  ├─ controllers/         # منطق HTTP
│  ├─ services/            # کسب‌وکار (orderService, walletService, authService, …)
│  ├─ models/              # Mongoose (User, Product, Order, Wallet, Cart, Address, …)
│  ├─ middlewares/         # auth, security, error, validation, …
│  └─ tests/               # jest: integration + unit
├─ frontend/               # React 18 + TS + Vite + Tailwind 4 (RTL, Vazirmatn)
│  └─ dist/                # خروجی build (سرو توسط Express)
├─ images/brand/           # تصاویر SVG برند/محصولات
├─ scripts/
│  ├─ seed.js              # داده اولیه (با گارد production)
│  ├─ smoke-test.mjs       # تست E2E داخلی
│  └─ migrations/          # مهاجرت‌ها (TTL سفارشات)
├─ uploads/                # فایل‌های آپلودی (در زمان اجرا)
├─ manifest.json / service-worker.js   # PWA
├─ docker-compose.yml / dockerfile     # دیپلوی (توسعه)
└─ .env.example            # نمونه متغیرهای محیطی مستند
```

## ۸) عیب‌یابی

- **خطای تراکنش مونگو** (`Transaction numbers are only allowed on a replica set`): مونگو را با `--replSet rs0` بالا بیاورید و `rs.initiate()` را اجرا کنید؛ `MONGODB_URI` باید `?replicaSet=rs0` داشته باشد.
- **`Crash on boot: Missing/weak required ENV vars`**: در production مقدارهای placeholder را با مقادیر قوی واقعی جایگزین کنید.
- **OTP در development دریافت نمی‌کنم**: کد در پاسخ `POST /api/v1/auth/send-otp` (فیلد `data.otpCode`) و در لاگ کنسول چاپ می‌شود.
- **پرداخت آزمایشی زرین‌پال redirect نمی‌شود**: `BACKEND_URL`/`FRONTEND_URL` را در `.env` درست کنید (برای هم‌مبدأ می‌توانند خالی باشند).
