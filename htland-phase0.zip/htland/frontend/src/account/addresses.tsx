/* Addresses management — list, create, edit, delete, set-default (real endpoints) */
import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { MapPin, Pencil, Plus, Star, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { addressesApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Input, Select, Textarea } from '@/components/ui/input'
import { Label, FormError } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState, ErrorState } from '@/components/states'
import { ADDRESS_LABELS, PROVINCES } from '@/lib/provinces'
import { cn, faNum } from '@/lib/format'
import { z } from 'zod'

const addressSchema = z.object({
  fullName: z.string().min(3, 'نام و نام خانوادگی را کامل وارد کنید').regex(/^[\u0600-\u06FF\s]+$/, 'نام باید با حروف فارسی باشد'),
  phone: z.string().transform((s) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))).pipe(z.string().regex(/^09\d{9}$/, 'شماره موبایل معتبر نیست')),
  province: z.string().min(1, 'استان را انتخاب کنید'),
  city: z.string().min(2, 'نام شهر را وارد کنید'),
  address: z.string().min(10, 'نشانی کامل را وارد کنید (حداقل ۱۰ کاراکتر)'),
  postalCode: z.string().transform((s) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))).pipe(z.string().regex(/^\d{10}$/, 'کد پستی باید ۱۰ رقم باشد')),
  description: z.string().max(200, 'توضیحات حداکثر ۲۰۰ کاراکتر').optional().or(z.literal('')),
})

export default function AccountAddresses() {
  const qc = useQueryClient()
  const [editing, setEditing] = useState<any | null>(null)
  const [creating, setCreating] = useState(false)
  const [deleting, setDeleting] = useState<any | null>(null)

  const { data: addresses, isLoading, error, refetch } = useQuery({
    queryKey: ['addresses'],
    queryFn: () => addressesApi.list(),
    retry: 1,
  })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['addresses'] })

  const setDefault = useMutation({
    mutationFn: (id: string) => addressesApi.setDefault(id),
    onSuccess: () => {
      toast.success('آدرس پیش‌فرض به‌روزرسانی شد')
      invalidate()
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const remove = useMutation({
    mutationFn: (id: string) => addressesApi.remove(id),
    onSuccess: () => {
      toast.success('آدرس حذف شد')
      setDeleting(null)
      invalidate()
    },
    onError: (e: Error) => toast.error(e.message),
  })

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-lg font-extrabold sm:text-xl">آدرس‌های من</h1>
        <Button size="sm" className="gap-2" onClick={() => setCreating(true)} disabled={(addresses?.length ?? 0) >= 3}>
          <Plus className="size-4" aria-hidden />
          افزودن آدرس
        </Button>
      </div>
      {(addresses?.length ?? 0) >= 3 && (
        <p className="rounded-lg bg-saffron-50 p-3 text-xs text-saffron-600">
          حداکثر تعداد آدرس‌های فعال (۳ عدد) تکمیل شده است؛ برای افزودن آدرس جدید ابتدا یکی از آدرس‌ها را حذف کنید.
        </p>
      )}

      {isLoading ? (
        <div className="flex flex-col gap-3">
          <Skeleton className="h-28 rounded-xl" />
          <Skeleton className="h-28 rounded-xl" />
        </div>
      ) : error ? (
        <ErrorState error={error} onRetry={refetch} title="خطا در دریافت آدرس‌ها" />
      ) : addresses!.length === 0 ? (
        <EmptyState
          icon={<MapPin className="size-7" aria-hidden />}
          title="هنوز آدرسی ثبت نکرده‌اید"
          description="برای خرید و ارسال سفارش، یک آدرس تحویل اضافه کنید."
          action={
            <Button onClick={() => setCreating(true)}>
              <Plus className="size-4" aria-hidden />
              افزودن اولین آدرس
            </Button>
          }
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {addresses!.map((a) => (
            <div key={a._id} className={cn('flex flex-col gap-2 rounded-xl border bg-card p-5 shadow-soft', a.isDefault && 'border-forest-600')}>
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-sm font-bold">
                  <MapPin className="size-4 text-forest-700" aria-hidden />
                  {a.label ?? 'آدرس'}
                </span>
                <div className="flex items-center gap-1">
                  {!a.isDefault && (
                    <button
                      className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] text-muted-foreground hover:bg-forest-50 hover:text-forest-700 cursor-pointer"
                      onClick={() => setDefault.mutate(a._id)}
                      disabled={setDefault.isPending}
                      aria-label="تنظیم به‌عنوان پیش‌فرض"
                    >
                      <Star className="size-3.5" aria-hidden />
                      پیش‌فرض
                    </button>
                  )}
                  <button
                    className="rounded-md p-1.5 text-muted-foreground hover:bg-forest-50 hover:text-forest-700 cursor-pointer"
                    onClick={() => setEditing(a)}
                    aria-label={`ویرایش آدرس ${a.city}`}
                  >
                    <Pencil className="size-4" />
                  </button>
                  <button
                    className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive cursor-pointer"
                    onClick={() => setDeleting(a)}
                    aria-label={`حذف آدرس ${a.city}`}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </div>
              <p className="text-sm font-semibold">
                {a.fullName} — <span className="font-normal text-muted-foreground">{faNum(a.phone)}</span>
              </p>
              <p className="text-sm leading-7 text-foreground/85">
                {a.province}، {a.city}، {a.address}
                {a.buildingNumber ? `، پلاک ${a.buildingNumber}` : ''}
                {a.unit ? `، واحد ${a.unit}` : ''}
              </p>
              <p className="text-xs text-muted-foreground">کد پستی: {faNum(a.postalCode)}</p>
              {a.isDefault && <span className="w-fit rounded-full bg-secondary px-2.5 py-0.5 text-[10px] font-bold">آدرس پیش‌فرض</span>}
            </div>
          ))}
        </div>
      )}

      {/* delete confirm */}
      <Dialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <DialogContent aria-describedby={undefined} className="max-w-md">
          <DialogHeader>
            <DialogTitle>حذف آدرس</DialogTitle>
            <DialogDescription>
              آیا از حذف آدرس «{deleting?.province}، {deleting?.city}» مطمئن هستید؟ این عملیات قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-2 flex gap-2">
            <Button variant="destructive" loading={remove.isPending} onClick={() => deleting && remove.mutate(deleting._id)} className="flex-1">
              حذف آدرس
            </Button>
            <Button variant="ghost" onClick={() => setDeleting(null)}>
              انصراف
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AddressDialog
        open={creating || !!editing}
        editAddress={editing}
        onClose={() => {
          setCreating(false)
          setEditing(null)
        }}
        onSaved={invalidate}
      />
    </div>
  )
}

function AddressDialog({ open, editAddress, onClose, onSaved }: { open: boolean; editAddress?: any; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState(() => ({
    fullName: editAddress?.fullName ?? '',
    phone: editAddress?.phone ?? '',
    province: editAddress?.province ?? '',
    city: editAddress?.city ?? '',
    address: editAddress?.address ?? '',
    postalCode: editAddress?.postalCode ?? '',
    label: editAddress?.label ?? 'خانه',
    buildingNumber: editAddress?.buildingNumber ?? '',
    unit: editAddress?.unit ?? '',
    floor: editAddress?.floor ?? '',
    description: editAddress?.description ?? '',
    isDefault: editAddress?.isDefault ?? false,
  }))
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  // reset form when target changes
  const key = editAddress?._id ?? 'new'
  const [lastKey, setLastKey] = useState(key)
  if (key !== lastKey) {
    setLastKey(key)
    setForm({
      fullName: editAddress?.fullName ?? '',
      phone: editAddress?.phone ?? '',
      province: editAddress?.province ?? '',
      city: editAddress?.city ?? '',
      address: editAddress?.address ?? '',
      postalCode: editAddress?.postalCode ?? '',
      label: editAddress?.label ?? 'خانه',
      buildingNumber: editAddress?.buildingNumber ?? '',
      unit: editAddress?.unit ?? '',
      floor: editAddress?.floor ?? '',
      description: editAddress?.description ?? '',
      isDefault: editAddress?.isDefault ?? false,
    })
    setErrors({})
  }

  const set = (k: string, v: string | boolean) => setForm((f) => ({ ...f, [k]: v }))

  const save = async () => {
    const parsed = addressSchema.safeParse(form)
    if (!parsed.success) {
      const errs: Record<string, string> = {}
      parsed.error.issues.forEach((i) => {
        const key2 = String(i.path[0] ?? 'form')
        if (!errs[key2]) errs[key2] = i.message
      })
      setErrors(errs)
      return
    }
    setErrors({})
    setSaving(true)
    try {
      if (editAddress) {
        await addressesApi.update(editAddress._id, { ...(parsed.data as any), ...(form.isDefault ? { isDefault: true } : {}) })
        toast.success('آدرس به‌روزرسانی شد')
      } else {
        await addressesApi.create({ ...(parsed.data as any), label: form.label, ...(form.isDefault ? { isDefault: true } : {}) })
        toast.success('آدرس جدید ثبت شد')
      }
      onSaved()
      onClose()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'ثبت آدرس ناموفق بود')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xl" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle>{editAddress ? 'ویرایش آدرس' : 'افزودن آدرس جدید'}</DialogTitle>
          <DialogDescription>اطلاعات تحویل سفارش‌ها را اینجا مدیریت می‌کنید.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <Label htmlFor="ad-name">نام و نام خانوادگی (فارسی)</Label>
            <Input id="ad-name" value={form.fullName} onChange={(e) => set('fullName', e.target.value)} className="mt-1.5" />
            <FormError message={errors.fullName} />
          </div>
          <div>
            <Label htmlFor="ad-phone">شماره موبایل گیرنده</Label>
            <Input id="ad-phone" inputMode="numeric" dir="ltr" value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="09121112233" className="mt-1.5 text-left" />
            <FormError message={errors.phone} />
          </div>
          <div>
            <Label htmlFor="ad-province">استان</Label>
            <Select id="ad-province" value={form.province} onChange={(e) => set('province', e.target.value)} className="mt-1.5">
              <option value="">انتخاب استان…</option>
              {PROVINCES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </Select>
            <FormError message={errors.province} />
          </div>
          <div>
            <Label htmlFor="ad-city">شهر</Label>
            <Input id="ad-city" value={form.city} onChange={(e) => set('city', e.target.value)} className="mt-1.5" />
            <FormError message={errors.city} />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="ad-address">نشانی کامل</Label>
            <Textarea id="ad-address" value={form.address} onChange={(e) => set('address', e.target.value)} className="mt-1.5" />
            <FormError message={errors.address} />
          </div>
          <div>
            <Label htmlFor="ad-postal">کد پستی ۱۰ رقمی</Label>
            <Input id="ad-postal" inputMode="numeric" dir="ltr" value={form.postalCode} onChange={(e) => set('postalCode', e.target.value)} className="mt-1.5 text-left" />
            <FormError message={errors.postalCode} />
          </div>
          <div>
            <Label htmlFor="ad-label">برچسب</Label>
            <Select id="ad-label" value={form.label} onChange={(e) => set('label', e.target.value)} className="mt-1.5">
              {ADDRESS_LABELS.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label htmlFor="ad-building">پلاک (اختیاری)</Label>
            <Input id="ad-building" value={form.buildingNumber} onChange={(e) => set('buildingNumber', e.target.value)} className="mt-1.5" />
          </div>
          <div>
            <Label htmlFor="ad-unit">واحد (اختیاری)</Label>
            <Input id="ad-unit" value={form.unit} onChange={(e) => set('unit', e.target.value)} className="mt-1.5" />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="ad-desc">توضیحات برای پیک (اختیاری)</Label>
            <Input id="ad-desc" value={form.description} onChange={(e) => set('description', e.target.value)} className="mt-1.5" />
            <FormError message={errors.description} />
          </div>
          <label className="flex cursor-pointer items-center gap-2.5 text-sm sm:col-span-2">
            <input type="checkbox" checked={form.isDefault} onChange={(e) => set('isDefault', e.target.checked)} className="size-4 accent-forest-800" />
            تنظیم به‌عنوان آدرس پیش‌فرض
          </label>
        </div>
        <div className="mt-2 flex gap-2">
          <Button onClick={save} loading={saving} className="flex-1">
            {editAddress ? 'ذخیره تغییرات' : 'ثبت آدرس'}
          </Button>
          <Button variant="ghost" onClick={onClose}>
            انصراف
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
