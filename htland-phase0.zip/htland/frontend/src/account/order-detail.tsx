/* Order detail — timeline, items, payment state, cancel (real endpoints) */
import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { ArrowRight, Ban, MapPin, Package, ReceiptText, Truck } from 'lucide-react'
import { toast } from 'sonner'
import { ordersApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/input'
import { ErrorState } from '@/components/states'
import { ORDER_STATUS_COLORS, faDateTime, faNum, toman } from '@/lib/format'
import type { OrderDetail } from '@/lib/types'

const PAYMENT_FA: Record<string, string> = {
  wallet: 'کیف پول',
  zarinpal: 'زرین‌پال',
  bank_transfer: 'انتقال بانکی',
  cash_on_delivery: 'پرداخت در محل',
}

const PAYMENT_STATUS_FA: Record<string, string> = {
  pending: 'در انتظار پرداخت',
  completed: 'پرداخت شده',
  failed: 'ناموفق',
  refunded: 'بازگشت داده شده',
}

const CANCELLABLE = ['pending', 'paid', 'processing', 'shipped']

export default function AccountOrderDetail() {
  const { id } = useParams<{ id: string }>()
  const qc = useQueryClient()
  const [cancelOpen, setCancelOpen] = useState(false)
  const [reason, setReason] = useState('')

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['order', id],
    queryFn: () => ordersApi.get(id!),
    enabled: !!id,
    retry: 1,
  })

  const cancelOrder = useMutation({
    mutationFn: () => ordersApi.cancel(id!, reason.trim() || undefined),
    onSuccess: () => {
      toast.success('سفارش لغو شد')
      setCancelOpen(false)
      setReason('')
      qc.invalidateQueries({ queryKey: ['order', id] })
      qc.invalidateQueries({ queryKey: ['orders'] })
    },
    onError: (e: Error) => toast.error(e.message),
  })

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <Skeleton className="h-24 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    )
  }
  if (error || !data?.order) {
    return <ErrorState error={error} onRetry={refetch} title="سفارش یافت نشد" />
  }

  const o: OrderDetail = data.order
  const canCancel = CANCELLABLE.includes(o.status) && o.payment.status !== 'completed' ? true : ['pending', 'paid', 'processing', 'shipped'].includes(o.status)

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <h1 className="text-lg font-extrabold sm:text-xl" dir="ltr">{faNum(o.orderNumber)}</h1>
          <span className={`rounded-full border px-3 py-1 text-xs font-bold ${ORDER_STATUS_COLORS[o.status] ?? 'bg-secondary'}`}>
            {o.statusFa ?? o.status}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/account/orders">
            <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground">
              <ArrowRight className="size-4" aria-hidden />
              سفارش‌های من
            </Button>
          </Link>
          {canCancel && o.status !== 'cancelled' && (
            <Button variant="outline" size="sm" className="gap-1.5 text-destructive hover:text-destructive" onClick={() => setCancelOpen(true)}>
              <Ban className="size-4" aria-hidden />
              لغو سفارش
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_320px]">
        <div className="flex flex-col gap-5">
          {/* items */}
          <div className="rounded-xl border bg-card p-5 shadow-soft">
            <h2 className="mb-4 flex items-center gap-2 font-bold">
              <Package className="size-5 text-forest-700" aria-hidden />
              اقلام سفارش
            </h2>
            <ul className="flex flex-col gap-3">
              {o.items.map((it, i) => (
                <li key={i} className="flex items-center gap-3 rounded-lg border p-3">
                  <div className="size-14 shrink-0 overflow-hidden rounded-lg bg-ivory-2">
                    {it.productImage || (typeof it.product === 'object' && it.product?.image) ? (
                      <img
                        src={(it.productImage || (it.product as any)?.image) as string}
                        alt=""
                        width={56}
                        height={56}
                        loading="lazy"
                        className="size-full object-cover"
                      />
                    ) : null}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold leading-6">
                      {typeof it.product === 'object' && it.product?.name ? (
                        <Link to={`/products/${(it.product as any).slug ?? (it.product as any)._id}`} className="hover:text-forest-600">
                          {it.productName}
                        </Link>
                      ) : (
                        it.productName
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {faNum(it.quantity)} × {toman(it.finalUnitPrice ?? it.unitPrice)}
                    </p>
                  </div>
                  <p className="text-sm font-bold text-forest-800">{toman(it.totalPrice)}</p>
                </li>
              ))}
            </ul>
          </div>

          {/* timeline */}
          {o.timeline && o.timeline.length > 0 && (
            <div className="rounded-xl border bg-card p-5 shadow-soft">
              <h2 className="mb-4 flex items-center gap-2 font-bold">
                <Truck className="size-5 text-forest-700" aria-hidden />
                وضعیت سفارش
              </h2>
              <ol className="relative flex flex-col gap-4 ps-5">
                {o.timeline.map((t, i) => (
                  <li key={i} className="relative">
                    <span className="absolute -start-5 top-1 size-2.5 rounded-full bg-forest-600" aria-hidden />
                    {i < o.timeline!.length - 1 && <span className="absolute -start-[17px] top-4 h-full w-px bg-border" aria-hidden />}
                    <p className="text-sm font-semibold">{t.status}</p>
                    <p className="text-xs text-muted-foreground">{faDateTime(t.date)}</p>
                    {t.description && <p className="mt-1 text-sm leading-6 text-foreground/85">{t.description}</p>}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>

        {/* side info */}
        <aside className="flex flex-col gap-5">
          <div className="rounded-xl border bg-card p-5 shadow-soft">
            <h2 className="mb-3 flex items-center gap-2 font-bold">
              <MapPin className="size-5 text-forest-700" aria-hidden />
              آدرس تحویل
            </h2>
            <div className="text-sm leading-7">
              <p className="font-semibold">{o.shippingAddress?.recipientName}</p>
              <p className="text-muted-foreground">{faNum(o.shippingAddress?.recipientPhone ?? '')}</p>
              <p className="mt-1 text-foreground/85">
                {o.shippingAddress?.province}، {o.shippingAddress?.city}، {o.shippingAddress?.address}
              </p>
              <p className="text-xs text-muted-foreground">کد پستی: {faNum(o.shippingAddress?.postalCode ?? '')}</p>
              {o.shippingAddress?.deliveryNotes && <p className="mt-2 text-xs text-muted-foreground">یادداشت: {o.shippingAddress.deliveryNotes}</p>}
            </div>
          </div>

          <div className="rounded-xl border bg-card p-5 shadow-soft">
            <h2 className="mb-3 flex items-center gap-2 font-bold">
              <ReceiptText className="size-5 text-forest-700" aria-hidden />
              پرداخت و صورت‌حساب
            </h2>
            <dl className="flex flex-col gap-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">روش پرداخت</dt>
                <dd className="font-semibold">{PAYMENT_FA[o.payment?.method] ?? o.payment?.method}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">وضعیت پرداخت</dt>
                <dd className={`font-semibold ${o.payment?.status === 'completed' ? 'text-forest-600' : o.payment?.status === 'failed' ? 'text-destructive' : 'text-saffron-600'}`}>
                  {PAYMENT_STATUS_FA[o.payment?.status] ?? o.payment?.status}
                </dd>
              </div>
              <Separator className="my-1" />
              <div className="flex justify-between">
                <dt className="text-muted-foreground">مبلغ کالاها</dt>
                <dd>{toman(o.subtotal)}</dd>
              </div>
              {(o.discount ?? 0) > 0 && (
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">تخفیف</dt>
                  <dd className="text-forest-600">− {toman(o.discount)}</dd>
                </div>
              )}
              {(o.tax ?? 0) > 0 && (
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">مالیات بر ارزش افزوده</dt>
                  <dd>{toman(o.tax)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">هزینه ارسال</dt>
                <dd>{toman(o.shippingCost ?? 0)}</dd>
              </div>
              <Separator className="my-1" />
              <div className="flex justify-between">
                <dt className="font-bold">مبلغ کل</dt>
                <dd className="text-base font-extrabold text-forest-800">{toman(o.totalAmount)}</dd>
              </div>
              {o.payment?.transactionId && (
                <p className="text-[11px] text-muted-foreground">شماره تراکنش: <span dir="ltr">{faNum(o.payment.transactionId)}</span></p>
              )}
            </dl>
          </div>
        </aside>
      </div>

      {/* cancel dialog */}
      <Dialog open={cancelOpen} onOpenChange={setCancelOpen}>
        <DialogContent aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>لغو سفارش</DialogTitle>
            <DialogDescription>
              آیا از لغو سفارش مطمئن هستید؟ این عملیات بسته به وضعیت پرداخت ممکن است مستلزم بازگشت وجه باشد.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            maxLength={200}
            placeholder="دلیل لغو (اختیاری)"
            aria-label="دلیل لغو سفارش"
          />
          <DialogFooter>
            <Button variant="destructive" loading={cancelOrder.isPending} onClick={() => cancelOrder.mutate()}>
              تأیید لغو سفارش
            </Button>
            <Button variant="ghost" onClick={() => setCancelOpen(false)}>
              انصراف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
