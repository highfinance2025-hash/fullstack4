/* Order history — real orders list with pagination and status filter */
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { ChevronLeft, ChevronRight, Package } from 'lucide-react'
import { ordersApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState, ErrorState } from '@/components/states'
import { ORDER_STATUS_COLORS, faDateTime, faNum, toman } from '@/lib/format'

const STATUS_FILTERS = [
  { value: '', label: 'همه سفارش‌ها' },
  { value: 'pending', label: 'در انتظار پرداخت' },
  { value: 'paid', label: 'پرداخت شده' },
  { value: 'processing', label: 'در حال آماده‌سازی' },
  { value: 'shipped', label: 'ارسال شده' },
  { value: 'delivered', label: 'تحویل داده شده' },
  { value: 'cancelled', label: 'لغو شده' },
]

export default function AccountOrders() {
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState('')

  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ['orders', { page, status }],
    queryFn: () => ordersApi.listWithPage({ page, limit: 8, status: status || undefined }),
    placeholderData: keepPreviousData,
    retry: 1,
  })

  const orders = data?.data ?? []
  const pagination = data?.pagination

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-lg font-extrabold sm:text-xl">سفارش‌های من</h1>
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1) }} className="w-48" aria-label="فیلتر وضعیت">
          {STATUS_FILTERS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </div>

      {isLoading ? (
        <div className="flex flex-col gap-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <ErrorState error={error} onRetry={refetch} title="خطا در دریافت سفارش‌ها" />
      ) : orders.length === 0 ? (
        <EmptyState
          icon={<Package className="size-7" aria-hidden />}
          title={status ? 'سفارشی با این وضعیت ندارید' : 'هنوز سفارشی ثبت نکرده‌اید'}
          description="اولین خرید خود را از فروشگاه اچ‌تی‌لند تجربه کنید."
          action={
            <Link to="/products">
              <Button>شروع خرید</Button>
            </Link>
          }
        />
      ) : (
        <>
          <div className="flex flex-col gap-3">
            {orders.map((o) => (
              <Link
                key={o.id}
                to={`/account/orders/${o.id}`}
                className="group flex flex-wrap items-center gap-4 rounded-xl border bg-card p-4 shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-lift"
              >
                <div className="size-16 shrink-0 overflow-hidden rounded-lg bg-ivory-2">
                  {o.firstItem?.image ? (
                    <img src={o.firstItem.image} alt="" width={64} height={64} loading="lazy" className="size-full object-cover" />
                  ) : (
                    <div className="flex size-full items-center justify-center text-muted-foreground">
                      <Package className="size-6" aria-hidden />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-extrabold" dir="ltr">{faNum(o.orderNumber)}</span>
                    <span className={`rounded-full border px-2.5 py-0.5 text-[11px] font-bold ${ORDER_STATUS_COLORS[o.status] ?? 'bg-secondary'}`}>
                      {o.statusFa}
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-1 text-sm text-muted-foreground">
                    {o.firstItem ? `${o.firstItem.productName}${o.itemCount > 1 ? ` و ${faNum(o.itemCount - 1)} کالای دیگر` : ''}` : '—'}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{faDateTime(o.orderedAt)}</p>
                </div>
                <div className="text-end">
                  <p className="text-sm font-extrabold text-forest-800">{toman(o.totalAmount)}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">{faNum(o.itemCount)} کالا</p>
                </div>
                <ChevronLeft className="size-5 text-muted-foreground transition-transform group-hover:-translate-x-0.5" aria-hidden />
              </Link>
            ))}
          </div>

          {pagination && pagination.pages > 1 && (
            <nav className="flex items-center justify-center gap-2" aria-label="صفحه‌بندی سفارش‌ها">
              <Button variant="outline" size="icon" disabled={!pagination.hasPrev || isFetching} onClick={() => setPage((p) => p - 1)} aria-label="صفحه قبل">
                <ChevronRight className="size-4" aria-hidden />
              </Button>
              <span className="text-sm text-muted-foreground">
                صفحه {faNum(pagination.page)} از {faNum(pagination.pages)}
              </span>
              <Button variant="outline" size="icon" disabled={!pagination.hasNext || isFetching} onClick={() => setPage((p) => p + 1)} aria-label="صفحه بعد">
                <ChevronLeft className="size-4" aria-hidden />
              </Button>
            </nav>
          )}
        </>
      )}
    </div>
  )
}
