/* Account profile — real profile endpoints with graceful degradation */
import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { CalendarDays, Mail, Phone, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { authApi, profileApi } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label, FormError } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { ErrorState } from '@/components/states'
import { faDate, faNum, toman } from '@/lib/format'
import { z } from 'zod'

const profileSchema = z.object({
  fullName: z.string().min(3, 'نام و نام خانوادگی را کامل وارد کنید').optional().or(z.literal('')),
  email: z.string().email('ایمیل معتبر نیست').optional().or(z.literal('')),
})

export default function AccountProfile() {
  const { user, updateUser } = useAuth()
  const qc = useQueryClient()
  const [form, setForm] = useState({ fullName: user?.fullName ?? '', email: user?.email ?? '' })
  const [errors, setErrors] = useState<Record<string, string>>({})

  /* real profile endpoint (stats included when server supports it) */
  const { data: profile, isLoading, error, refetch } = useQuery({
    queryKey: ['profile'],
    queryFn: () => profileApi.get(),
    retry: 1,
  })

  const save = useMutation({
    mutationFn: async () => {
      const parsed = profileSchema.safeParse(form)
      if (!parsed.success) {
        const errs: Record<string, string> = {}
        parsed.error.issues.forEach((i) => (errs[String(i.path[0])] = i.message))
        setErrors(errs)
        throw new Error('اطلاعات فرم معتبر نیست')
      }
      setErrors({})
      const updates: Record<string, unknown> = {}
      if (parsed.data.fullName) updates.fullName = parsed.data.fullName
      if (parsed.data.email) updates.email = parsed.data.email
      return authApi.updateProfile(updates)
    },
    onSuccess: (u) => {
      updateUser(u)
      toast.success('پروفایل به‌روزرسانی شد')
      qc.invalidateQueries({ queryKey: ['profile'] })
    },
    onError: (e: Error) => {
      if (e.message !== 'اطلاعات فرم معتبر نیست') toast.error(e.message)
    },
  })

  if (isLoading) {
    return (
      <div className="grid gap-4">
        <Skeleton className="h-64 rounded-xl" />
        <Skeleton className="h-48 rounded-xl" />
      </div>
    )
  }
  if (error) return <ErrorState error={error} onRetry={refetch} title="خطا در دریافت پروفایل" />

  const p = profile ?? user
  const stats = (profile as any)?.stats

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardHeader>
          <CardTitle>اطلاعات حساب</CardTitle>
          <CardDescription>اطلاعات تماس و هویتی حساب خود را مدیریت کنید.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-lg bg-forest-50 p-4 text-sm">
            <span className="flex items-center gap-2 text-muted-foreground">
              <Phone className="size-4 text-forest-700" aria-hidden />
              {faNum(p?.phone ?? '')}
              {p?.phoneVerified && (
                <span className="flex items-center gap-1 text-[11px] font-semibold text-forest-600">
                  <ShieldCheck className="size-3.5" aria-hidden />
                  تأیید شده
                </span>
              )}
            </span>
            {p?.createdAt && (
              <span className="flex items-center gap-2 text-muted-foreground">
                <CalendarDays className="size-4 text-forest-700" aria-hidden />
                عضویت از {faDate(p.createdAt)}
              </span>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="pf-name">نام و نام خانوادگی</Label>
              <Input
                id="pf-name"
                value={form.fullName}
                onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))}
                placeholder="مثلاً سارا محمدی"
                className="mt-1.5"
              />
              <FormError message={errors.fullName} />
            </div>
            <div>
              <Label htmlFor="pf-email">ایمیل (اختیاری)</Label>
              <Input
                id="pf-email"
                type="email"
                dir="ltr"
                value={form.email}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                placeholder="you@example.com"
                className="mt-1.5 text-left"
              />
              <FormError message={errors.email} />
            </div>
          </div>
          <div>
            <Button onClick={() => save.mutate()} loading={save.isPending}>
              ذخیره تغییرات
            </Button>
          </div>
          <p className="text-[11px] leading-5 text-muted-foreground">
            شماره موبایل، شناسه ورود شماست و قابل تغییر نیست.
          </p>
        </CardContent>
      </Card>

      {stats && (
        <Card>
          <CardHeader>
            <CardTitle>خلاصه فعالیت شما</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border p-4 text-center">
                <p className="text-xl font-extrabold text-forest-800">{faNum(stats.orders?.total ?? 0)}</p>
                <p className="mt-1 text-xs text-muted-foreground">سفارش</p>
              </div>
              <div className="rounded-xl border p-4 text-center">
                <p className="text-xl font-extrabold text-forest-800">{toman(stats.spending?.total ?? 0)}</p>
                <p className="mt-1 text-xs text-muted-foreground">مجموع خرید</p>
              </div>
              <div className="rounded-xl border p-4 text-center">
                <p className="text-xl font-extrabold text-forest-800">{faNum(stats.addresses?.count ?? 0)}</p>
                <p className="mt-1 text-xs text-muted-foreground">آدرس</p>
              </div>
              <div className="rounded-xl border p-4 text-center">
                <p className="text-xl font-extrabold text-forest-800">{toman(stats.wallet?.balance ?? 0)}</p>
                <p className="mt-1 text-xs text-muted-foreground">کیف پول</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
