/* Wallet — real endpoints only: GET /, POST /create.
   شارژ/برداشت عمداً حذف شده‌اند: تغییر موجودی فقط باید از سمت سرور (پس از verify درگاه) انجام شود. */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Lock, Wallet as WalletIcon } from 'lucide-react'
import { toast } from 'sonner'
import { walletApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState, ErrorState } from '@/components/states'
import { toman } from '@/lib/format'

export default function AccountWallet() {
  const qc = useQueryClient()
  const { data: wallets, isLoading, error: walletError, refetch } = useQuery({
    queryKey: ['wallets'],
    queryFn: () => walletApi.list(),
    retry: 1,
  })

  const invalidate = () => qc.invalidateQueries({ queryKey: ['wallets'] })

  const createWallet = useMutation({
    mutationFn: () => walletApi.create(),
    onSuccess: () => {
      toast.success('کیف پول شما ساخته شد')
      invalidate()
    },
    onError: (e: Error) => toast.error(e.message),
  })

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <Skeleton className="h-44 rounded-xl" />
        <Skeleton className="h-24 rounded-xl" />
      </div>
    )
  }
  if (walletError) return <ErrorState error={walletError} onRetry={refetch} title="خطا در دریافت کیف پول" />

  const wallet = wallets?.[0]

  if (!wallet) {
    return (
      <div className="flex flex-col gap-5">
        <h1 className="text-lg font-extrabold sm:text-xl">کیف پول</h1>
        <EmptyState
          icon={<WalletIcon className="size-7" aria-hidden />}
          title="هنوز کیف پولی ندارید"
          description="با ساخت کیف پول می‌توانید خرید خود را سریع‌تر پرداخت کنید."
          action={
            <Button loading={createWallet.isPending} onClick={() => createWallet.mutate()}>
              ساخت کیف پول
            </Button>
          }
        />
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-lg font-extrabold sm:text-xl">کیف پول</h1>

      <div className="rounded-2xl bg-forest-800 p-6 text-ivory shadow-lift sm:p-8">
        <p className="text-xs text-ivory/70">موجودی قابل استفاده</p>
        <p className="mt-2 text-3xl font-extrabold tracking-tight">{toman(wallet.balance)}</p>
        {(wallet.lockedBalance ?? 0) > 0 && (
          <p className="mt-2 flex items-center gap-1.5 text-xs text-ivory/75">
            <Lock className="size-3.5" aria-hidden />
            بلوکه‌شده: {toman(wallet.lockedBalance)}
          </p>
        )}
        <p className="mt-5 rounded-lg bg-ivory/10 px-3 py-2 text-xs leading-6 text-ivory/85">
          شارژ آنلاین کیف پول از طریق درگاه پرداخت به‌زودی فعال می‌شود. تا آن زمان، موجودی کیف پول از بازگشت وجه
          سفارش‌های لغوشده تأمین می‌شود و می‌توانید با آن سفارش خود را پرداخت کنید.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border bg-card p-4 text-center">
          <p className="text-sm font-extrabold text-forest-800">{toman(wallet.totalDeposits ?? 0)}</p>
          <p className="mt-1 text-xs text-muted-foreground">مجموع شارژ</p>
        </div>
        <div className="rounded-xl border bg-card p-4 text-center">
          <p className="text-sm font-extrabold text-forest-800">{toman(wallet.totalWithdrawals ?? 0)}</p>
          <p className="mt-1 text-xs text-muted-foreground">مجموع برداشت</p>
        </div>
        <div className="rounded-xl border bg-card p-4 text-center">
          <p className="text-sm font-extrabold text-forest-800">{wallet.isActive ? 'فعال' : 'غیرفعال'}</p>
          <p className="mt-1 text-xs text-muted-foreground">وضعیت کیف پول</p>
        </div>
      </div>

      <div className="rounded-xl border bg-card p-5 text-xs leading-6 text-muted-foreground">
        <p className="mb-1 font-bold text-foreground">قوانین کیف پول</p>
        <p>• پرداخت سفارش با کیف پول، آنی و بدون انتقال به درگاه انجام می‌شود.</p>
        <p>• مبلغ سفارش‌های لغوشده به کیف پول شما بازگردانده می‌شود.</p>
        <p>• شارژ و برداشت پس از راه‌اندازی درگاه، از همین صفحه در دسترس خواهد بود.</p>
      </div>
    </div>
  )
}
