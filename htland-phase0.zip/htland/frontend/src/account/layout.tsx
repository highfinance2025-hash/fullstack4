/* Account layout — sidebar nav + auth guard */
import { useEffect } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { LogOut, MapPin, Package, UserRound, Wallet } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { cn, faNum } from '@/lib/format'

const NAV = [
  { to: '/account', label: 'پروفایل', icon: UserRound, end: true },
  { to: '/account/orders', label: 'سفارش‌های من', icon: Package },
  { to: '/account/addresses', label: 'آدرس‌ها', icon: MapPin },
  { to: '/account/wallet', label: 'کیف پول', icon: Wallet },
]

export default function AccountLayout() {
  const { user, loading, logout } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (!loading && !user) navigate('/login?redirect=/account', { replace: true })
  }, [loading, user, navigate])

  if (loading || !user) {
    return (
      <div className="container-page py-10">
        <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-96 rounded-xl" />
        </div>
      </div>
    )
  }

  return (
    <div className="container-page py-8">
      <nav aria-label="مسیر" className="mb-5 text-xs text-muted-foreground">
        <NavLink to="/" className="hover:text-forest-700">
          خانه
        </NavLink>
        <span className="mx-1.5" aria-hidden>/</span>
        <span className="font-medium text-foreground">حساب کاربری</span>
      </nav>

      <div className="grid items-start gap-6 lg:grid-cols-[240px_1fr]">
        <aside className="rounded-xl border bg-card p-4 shadow-soft">
          <div className="mb-4 flex items-center gap-3 rounded-lg bg-forest-50 p-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-forest-800 text-ivory">
              <UserRound className="size-5" aria-hidden />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-bold">{user.fullName || 'کاربر اچ‌تی‌لند'}</p>
              <p className="text-xs text-muted-foreground">{faNum(user.phone)}</p>
            </div>
          </div>
          <nav className="flex flex-col gap-1" aria-label="منوی حساب">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
                    isActive ? 'bg-forest-800 text-ivory' : 'hover:bg-forest-50'
                  )
                }
              >
                <n.icon className="size-4" aria-hidden />
                {n.label}
              </NavLink>
            ))}
            <Button
              variant="ghost"
              size="sm"
              className="mt-2 justify-start gap-2.5 px-3 text-muted-foreground hover:text-destructive"
              onClick={async () => {
                await logout()
                navigate('/')
              }}
            >
              <LogOut className="size-4" aria-hidden />
              خروج از حساب
            </Button>
          </nav>
        </aside>
        <section aria-label="محتوای حساب">
          <Outlet />
        </section>
      </div>
    </div>
  )
}
