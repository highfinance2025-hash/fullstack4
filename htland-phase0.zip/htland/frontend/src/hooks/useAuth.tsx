/* Auth context — token persistence + profile via backend */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { authApi } from '@/api'
import { getToken, setToken } from '@/lib/api'
import type { User } from '@/lib/types'

interface AuthContextValue {
  user: User | null
  loading: boolean // initial session check
  login: (token: string, user: User) => void
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
  updateUser: (u: User) => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const mounted = useRef(true)

  const refreshUser = useCallback(async () => {
    if (!getToken()) {
      setUser(null)
      return
    }
    try {
      const u = await authApi.profile()
      if (mounted.current) setUser(u)
    } catch {
      // invalid/expired token
      setToken(null)
      if (mounted.current) setUser(null)
    }
  }, [])

  useEffect(() => {
    mounted.current = true
    refreshUser().finally(() => setLoading(false))
    return () => {
      mounted.current = false
    }
  }, [refreshUser])

  const login = useCallback((token: string, u: User) => {
    setToken(token)
    setUser(u)
  }, [])

  const logout = useCallback(async () => {
    await authApi.logout()
    setToken(null)
    setUser(null)
  }, [])

  const updateUser = useCallback((u: User) => setUser(u), [])

  const value = useMemo(
    () => ({ user, loading, login, logout, refreshUser, updateUser }),
    [user, loading, login, logout, refreshUser, updateUser]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
