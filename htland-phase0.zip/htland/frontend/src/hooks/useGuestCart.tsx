/* Guest cart — localStorage-backed, clearly separated from the server cart.
   Items store a snapshot; the cart page revalidates prices/stock from the backend. */
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { productsApi } from '@/api'
import type { Product } from '@/lib/types'

export interface GuestCartItem {
  productId: string
  slug: string
  name: string
  image?: string
  price: number // final (discounted) unit price at add time
  originalPrice: number
  quantity: number
  stock?: number
}

interface GuestCartContextValue {
  items: GuestCartItem[]
  count: number
  add: (product: Product, quantity?: number) => void
  setQuantity: (productId: string, quantity: number) => void
  remove: (productId: string) => void
  clear: () => void
  /* reconcile guest items into the authenticated server cart; returns migrated count */
  migrateToServer: (addItem: (productId: string, qty: number) => Promise<unknown>) => Promise<number>
}

const KEY = 'htland.guestCart.v1'
const MAX_QTY = 99

const GuestCartContext = createContext<GuestCartContextValue | null>(null)

function load(): GuestCartItem[] {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.filter((i) => i && typeof i.productId === 'string' && i.quantity > 0)
  } catch {
    return []
  }
}

export function GuestCartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<GuestCartItem[]>([])

  useEffect(() => {
    setItems(load())
  }, [])

  const persist = useCallback((next: GuestCartItem[]) => {
    setItems(next)
    try {
      localStorage.setItem(KEY, JSON.stringify(next))
    } catch {
      /* ignore */
    }
  }, [])

  const add = useCallback(
    (product: Product, quantity = 1) => {
      const current = load()
      const existing = current.find((i) => i.productId === product._id)
      if (existing) {
        existing.quantity = Math.min(MAX_QTY, existing.quantity + quantity)
        existing.price = product.discountPrice ?? product.price
        persist([...current])
      } else {
        persist([
          ...current,
          {
            productId: product._id,
            slug: product.slug,
            name: product.name,
            image: product.image,
            price: product.discountPrice ?? product.price,
            originalPrice: product.price,
            quantity: Math.min(MAX_QTY, quantity),
            stock: product.stock,
          },
        ])
      }
    },
    [persist]
  )

  const setQuantity = useCallback(
    (productId: string, quantity: number) => {
      const current = load()
      if (quantity <= 0) {
        persist(current.filter((i) => i.productId !== productId))
      } else {
        persist(current.map((i) => (i.productId === productId ? { ...i, quantity: Math.min(MAX_QTY, quantity) } : i)))
      }
    },
    [persist]
  )

  const remove = useCallback(
    (productId: string) => persist(load().filter((i) => i.productId !== productId)),
    [persist]
  )

  const clear = useCallback(() => persist([]), [persist])

  /* After login: push each guest item through the real cart API, then clear local state. */
  const migrateToServer = useCallback(
    async (addItem: (productId: string, qty: number) => Promise<unknown>) => {
      const current = load()
      if (current.length === 0) return 0
      let migrated = 0
      for (const item of current) {
        try {
          await addItem(item.productId, item.quantity)
          migrated += 1
        } catch {
          /* stock/availability failures are surfaced by the cart page refresh */
        }
      }
      persist([])
      return migrated
    },
    [persist]
  )

  const count = useMemo(() => items.reduce((s, i) => s + i.quantity, 0), [items])

  const value = useMemo(
    () => ({ items, count, add, setQuantity, remove, clear, migrateToServer }),
    [items, count, add, setQuantity, remove, clear, migrateToServer]
  )

  return <GuestCartContext.Provider value={value}>{children}</GuestCartContext.Provider>
}

export function useGuestCart(): GuestCartContextValue {
  const ctx = useContext(GuestCartContext)
  if (!ctx) throw new Error('useGuestCart must be used within GuestCartProvider')
  return ctx
}

/* Revalidate guest items against the live backend (price/stock may have changed) */
export async function revalidateGuestItems(items: GuestCartItem[]): Promise<Array<GuestCartItem & { product?: Product; missing?: boolean }>> {
  const out: Array<GuestCartItem & { product?: Product; missing?: boolean }> = []
  for (const item of items) {
    try {
      const p = await productsApi.detail(item.productId)
      out.push({
        ...item,
        price: p.discountPrice ?? p.price,
        originalPrice: p.price,
        stock: p.stock,
        product: p,
      })
    } catch {
      out.push({ ...item, missing: true })
    }
  }
  return out
}
