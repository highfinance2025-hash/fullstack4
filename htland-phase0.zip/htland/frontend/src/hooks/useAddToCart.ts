/* Central add-to-cart behavior: server cart when authenticated, guest cart otherwise */
import { useCallback, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { cartApi } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { useGuestCart } from '@/hooks/useGuestCart'
import { useQueryClient } from '@tanstack/react-query'
import type { Product } from '@/lib/types'
import { ApiError } from '@/lib/api'

export function useAddToCart() {
  const { user } = useAuth()
  const guestCart = useGuestCart()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [pendingId, setPendingId] = useState<string | null>(null)

  const addToCart = useCallback(
    async (product: Product, quantity = 1, opts: { silent?: boolean } = {}) => {
      if (!product.inStock || product.stock <= 0) {
        toast.error('این محصول در حال حاضر موجود نیست')
        return false
      }
      setPendingId(product._id)
      try {
        if (user) {
          await cartApi.addItem(product._id, quantity)
          qc.invalidateQueries({ queryKey: ['cart'] })
          if (!opts.silent) toast.success(`«${product.name}» به سبد خرید اضافه شد`)
        } else {
          guestCart.add(product, quantity)
          if (!opts.silent) toast.success(`«${product.name}» به سبد خرید اضافه شد`, {
            action: {
              label: 'مشاهده سبد',
              onClick: () => navigate('/cart'),
            },
          })
        }
        return true
      } catch (e) {
        if (e instanceof ApiError && e.status === 401) {
          guestCart.add(product, quantity)
          toast.info('برای ثبت نهایی سبد، وارد حساب خود شوید', {
            description: 'محصول به سبد خرید شما اضافه شد',
          })
          return true
        }
        const msg = e instanceof Error ? e.message : 'افزودن به سبد خرید ناموفق بود'
        toast.error(msg)
        return false
      } finally {
        setPendingId(null)
      }
    },
    [user, guestCart, qc, navigate]
  )

  return { addToCart, pendingId }
}
