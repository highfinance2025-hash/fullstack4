/* Payment/order success — reached via backend redirect (real verified state) */
import { useEffect } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { motion } from 'motion/react'
import { CheckCircle2, Package, Receipt } from 'lucide-react'
import { cartApi, ordersApi } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { faNum, toman } from '@/lib/format'

export default function OrderSuccess() {
  const { id } = useParams<{ id: string }>()
  const [params] = useSearchParams()
  const orderNumber = params.get('orderNumber')
  const refId = params.get('refId')
  const { user } = useAuth()
  const qc = useQueryClient()

  /* after a paid order the backend may leave residual cart rows — refresh real cart */
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ['cart'] })
    qc.invalidateQueries({ queryKey: ['orders'] })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const { data: orderRes } = useQuery({
    queryKey: ['order', id],
    queryFn: () => ordersApi.get(id!),
    enabled: !!user && !!id,
    retry: 1,
  })
  const order = orderRes?.order

  /* Backend clears the cart for wallet/bank/cod orders but not for zarinpal
     (pending at creation). Once the backend verifies the payment, clear the
     residual cart through the real API so the user cannot double-order. */
  useEffect(() => {
    if (order && (order.status === 'paid' || order.payment?.status === 'completed')) {
      cartApi
        .clear()
        .catch(() => undefined)
        .finally(() => qc.invalidateQueries({ queryKey: ['cart'] }))
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.status, order?.payment?.status])

  return (
    <div className="container-page flex min-h-[65dvh] items-center justify-center py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.35 }}
        className="w-full max-w-lg rounded-2xl border bg-card p-8 text-center shadow-soft"
      >
        <div className="mx-auto mb-5 flex size-16 items-center justify-center rounded-full bg-forest-50 text-forest-600">
          <CheckCircle2 className="size-9" aria-hidden />
        </div>
        <h1 className="text-xl font-extrabold">
          {order?.payment?.status === 'completed' || order?.status === 'paid' ? 'پرداخت با موفقیت انجام شد' : 'سفارش شما ثبت شد'}
        </h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">
          {order?.status === 'pending'
            ? 'سفارش شما ثبت شد؛ پس از تأیید پرداخت، آماده‌سازی آغاز می‌شود.'
            : 'سفارش شما ثبت و پرداخت آن تأیید شد. آماده‌سازی به‌زودی آغاز می‌شود.'}
        </p>

        <div className="my-6 flex flex-col gap-2.5 rounded-xl border bg-ivory-2/60 p-4 text-sm">
          {order?.orderNumber && (
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">شماره سفارش</span>
              <span className="font-extrabold" dir="ltr">{faNum(order.orderNumber)}</span>
            </div>
          )}
          {!order && orderNumber && (
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">شماره سفارش</span>
              <span className="font-extrabold" dir="ltr">{faNum(orderNumber)}</span>
            </div>
          )}
          {order?.totalAmount !== undefined && (
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">مبلغ کل</span>
              <span className="font-bold text-forest-800">{toman(order.totalAmount)}</span>
            </div>
          )}
          {refId && (
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">شماره پیگیری پرداخت</span>
              <span className="font-bold" dir="ltr">{faNum(refId)}</span>
            </div>
          )}
          {order?.status && (
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">وضعیت</span>
              <span className="font-bold">{order.statusFa ?? order.status}</span>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-2 sm:flex-row sm:justify-center">
          {user && id ? (
            <Link to={`/account/orders/${id}`}>
              <Button className="w-full gap-2 sm:w-auto">
                <Receipt className="size-4" aria-hidden />
                مشاهده جزئیات سفارش
              </Button>
            </Link>
          ) : (
            <Link to="/track">
              <Button className="w-full gap-2 sm:w-auto">
                <Package className="size-4" aria-hidden />
                پیگیری سفارش
              </Button>
            </Link>
          )}
          <Link to="/products">
            <Button variant="outline" className="w-full sm:w-auto">
              ادامه خرید
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  )
}
