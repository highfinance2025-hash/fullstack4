/* Cart — server cart when authenticated (totals always from backend), guest cart otherwise */
import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AnimatePresence, motion } from 'motion/react'
import { ArrowLeft, ShoppingBasket, Trash2, Tag, TriangleAlert } from 'lucide-react'
import { toast } from 'sonner'
import { cartApi, productsApi } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { useGuestCart, revalidateGuestItems } from '@/hooks/useGuestCart'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { QuantityStepper } from '@/components/quantity-stepper'
import { Price } from '@/components/price'
import { ProductCard } from '@/components/product-card'
import { EmptyState } from '@/components/states'
import { faNum, toman } from '@/lib/format'
import type { CartItem, Product } from '@/lib/types'
import type { GuestCartItem } from '@/hooks/useGuestCart'

function CartRow({
  name,
  image,
  unitPrice,
  originalPrice,
  quantity,
  stock,
  href,
  onQty,
  onRemove,
  disabled,
  warning,
}: {
  name: string
  image?: string
  unitPrice: number
  originalPrice?: number
  quantity: number
  stock?: number
  href: string
  onQty: (q: number) => void
  onRemove: () => void
  disabled?: boolean
  warning?: string | null
}) {
  return (
    <div className="flex gap-4 rounded-xl border bg-card p-4">
      <Link to={href} className="shrink-0 overflow-hidden rounded-lg bg-ivory-2" aria-label={name}>
        <img
          src={image || '/images/brand/cat-rice.svg'}
          alt=""
          width={96}
          height={96}
          loading="lazy"
          className="size-20 object-cover sm:size-24"
        />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col gap-2">
        <div className="flex items-start justify-between gap-3">
          <Link to={href} className="font-semibold leading-6 hover:text-forest-600 line-clamp-2">
            {name}
          </Link>
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={onRemove}
            disabled={disabled}
            aria-label={`حذف ${name} از سبد`}
            className="shrink-0 text-muted-foreground hover:text-destructive"
          >
            <Trash2 className="size-4" />
          </Button>
        </div>
        {warning && (
          <p className="flex items-center gap-1.5 text-xs font-medium text-destructive" role="alert">
            <TriangleAlert className="size-3.5" aria-hidden />
            {warning}
          </p>
        )}
        <div className="mt-auto flex flex-wrap items-center justify-between gap-3">
          <QuantityStepper value={quantity} onChange={onQty} disabled={disabled} max={Math.max(1, Math.min(99, stock ?? 99))} size="sm" />
          <Price price={originalPrice ?? unitPrice} discountPrice={originalPrice && originalPrice !== unitPrice ? unitPrice : null} size="md" className="text-end" />
        </div>
        <p className="text-xs text-muted-foreground">
          جمع: {toman(unitPrice * quantity)}
        </p>
      </div>
    </div>
  )
}

function Summary({ rows, coupon, children }: { rows: Array<[string, string, string?]>; coupon?: { code: string; percent: number } | null; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border bg-card p-5 shadow-soft">
      <h2 className="font-bold">خلاصه سفارش</h2>
      <Separator />
      <dl className="flex flex-col gap-2.5 text-sm">
        {rows.map(([label, value, cls]) => (
          <div key={label} className="flex items-center justify-between">
            <dt className="text-muted-foreground">{label}</dt>
            <dd className={cn('font-semibold', cls)}>{value}</dd>
          </div>
        ))}
      </dl>
      {children}
    </div>
  )
}

const cn = (...c: Array<string | false | null | undefined>) => c.filter(Boolean).join(' ')

export default function Cart() {
  const { user } = useAuth()
  const guest = useGuestCart()
  const navigate = useNavigate()
  const qc = useQueryClient()

  /* ── server cart ── */
  const { data: cart, isLoading, error, refetch } = useQuery({
    queryKey: ['cart'],
    queryFn: () => cartApi.get(),
    enabled: !!user,
    retry: 1,
  })

  const [couponInput, setCouponInput] = useState('')
  const applyCoupon = useMutation({
    mutationFn: (code: string) => cartApi.applyCoupon(code),
    onSuccess: (d) => {
      toast.success(d.discountPercentage ? `کد تخفیف ٪${faNum(d.discountPercentage)} اعمال شد` : 'کد تخفیف اعمال شد')
      setCouponInput('')
      qc.invalidateQueries({ queryKey: ['cart'] })
    },
    onError: (e: Error) => toast.error(e.message),
  })
  const removeCoupon = useMutation({
    mutationFn: () => cartApi.removeCoupon(),
    onSuccess: () => {
      toast.success('کد تخفیف حذف شد')
      qc.invalidateQueries({ queryKey: ['cart'] })
    },
  })

  const updateItem = useMutation({
    mutationFn: ({ productId, quantity }: { productId: string; quantity: number }) =>
      cartApi.updateItem(productId, quantity),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['cart'] }),
    onError: (e: Error) => {
      toast.error(e.message)
      qc.invalidateQueries({ queryKey: ['cart'] })
    },
  })
  const removeItem = useMutation({
    mutationFn: (productId: string) => cartApi.removeItem(productId),
    onSuccess: (d) => {
      toast.success('محصول از سبد حذف شد', {
        action: {
          label: 'بازگردانی',
          onClick: () => {
            // real undo: re-add requires product id; we re-fetch detail from removedProductId
            const pid = (d as any)?.removedProductId
            if (pid) cartApi.addItem(pid, 1).then(() => qc.invalidateQueries({ queryKey: ['cart'] })).catch(() => undefined)
          },
        },
      })
      qc.invalidateQueries({ queryKey: ['cart'] })
    },
    onError: (e: Error) => toast.error(e.message),
  })
  const clearCart = useMutation({
    mutationFn: () => cartApi.clear(),
    onSuccess: () => {
      toast.success('سبد خرید خالی شد')
      qc.invalidateQueries({ queryKey: ['cart'] })
    },
  })

  /* undo buffer for guest removal */
  const [guestUndo, setGuestUndo] = useState<{ item: GuestCartItem; index: number } | null>(null)

  /* ── guest cart revalidation ── */
  const [guestValidated, setGuestValidated] = useState<Array<ReturnType<typeof guest.add> extends never ? never : any> | null>(null)
  const [guestLoading, setGuestLoading] = useState(false)
  useEffect(() => {
    if (user) return
    if (guest.items.length === 0) {
      setGuestValidated([])
      return
    }
    setGuestLoading(true)
    revalidateGuestItems(guest.items)
      .then(setGuestValidated)
      .finally(() => setGuestLoading(false))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, guest.items])

  /* recommended products for empty state */
  const { data: recs } = useQuery({
    queryKey: ['featured', 4],
    queryFn: () => productsApi.featured(4),
    enabled: (user ? (cart?.totalItems ?? 0) === 0 : guest.count === 0),
  })

  const serverItems: CartItem[] = useMemo(() => cart?.items ?? [], [cart])

  const goCheckout = () => {
    if (!user) {
      toast.info('برای ادامه خرید، وارد حساب خود شوید', {
        description: 'سبد خرید شما حفظ می‌شود',
      })
      navigate('/login?redirect=/checkout')
      return
    }
    navigate('/checkout')
  }

  /* ── guest migrate on login ── handled in Login page */

  const isEmpty = user ? !isLoading && serverItems.length === 0 : !guestLoading && guest.items.length === 0

  return (
    <div className="container-page py-8">
      <nav aria-label="مسیر" className="mb-5 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-forest-700">خانه</Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <span className="font-medium text-foreground">سبد خرید</span>
      </nav>

      <h1 className="mb-6 text-xl font-extrabold sm:text-2xl">سبد خرید {user ? '' : '(مهمان)'}</h1>

      {!user && guest.items.length > 0 && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-saffron-100 bg-saffron-50 p-4 text-sm">
          <p className="leading-6">
            سبد خرید شما به‌صورت مهمان ذخیره شده است. برای نهایی کردن خرید و استفاده از تخفیف‌ها وارد حساب شوید.
          </p>
          <Link to="/login?redirect=/cart">
            <Button size="sm">ورود به حساب</Button>
          </Link>
        </div>
      )}

      {isLoading || (!user && guestLoading && guest.items.length > 0) ? (
        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          <div className="flex flex-col gap-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 rounded-xl" />
        </div>
      ) : error && user ? (
        <EmptyState icon={<ShoppingBasket className="size-7" aria-hidden />} title="خطا در دریافت سبد خرید" description={error instanceof Error ? error.message : undefined} action={<Button onClick={() => refetch()}>تلاش مجدد</Button>} />
      ) : isEmpty ? (
        <div className="grid gap-8">
          <EmptyState
            icon={<ShoppingBasket className="size-7" aria-hidden />}
            title="سبد خرید شما خالی است"
            description="از میان محصولات اصیل شمال ایران انتخاب کنید."
            action={
              <Link to="/products">
                <Button>
                  رفتن به فروشگاه
                  <ArrowLeft className="size-4" aria-hidden />
                </Button>
              </Link>
            }
          />
          {recs && recs.length > 0 && (
            <section aria-labelledby="recs-title">
              <h2 id="recs-title" className="mb-4 text-lg font-bold">پیشنهاد ویژه برای شروع</h2>
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                {recs.map((p: Product) => <ProductMini key={p._id} product={p} />)}
              </div>
            </section>
          )}
        </div>
      ) : (
        <div className="grid items-start gap-6 lg:grid-cols-[1fr_320px]">
          {/* items */}
          <div className="flex flex-col gap-3">
            {user
              ? serverItems.map((item) => {
                  const pid = typeof item.productId === 'object' && item.productId !== null ? (item.productId as any)._id : (item.productId as string)
                  const populated = typeof item.productId === 'object' && item.productId !== null ? (item.productId as any) : null
                  const stock = populated?.stock
                  const original = populated?.price ?? item.price
                  return (
                    <CartRow
                      key={pid}
                      name={item.productName || populated?.name}
                      image={item.image || populated?.image}
                      unitPrice={item.price}
                      originalPrice={original !== item.price ? original : undefined}
                      quantity={item.quantity}
                      stock={stock}
                      href={populated?.slug ? `/products/${populated.slug}` : `/products/${pid}`}
                      disabled={updateItem.isPending || removeItem.isPending}
                      warning={!item.available || !item.active ? 'این محصول در حال حاضر قابل خرید نیست' : null}
                      onQty={(q) => updateItem.mutate({ productId: pid, quantity: q })}
                      onRemove={() => removeItem.mutate(pid)}
                    />
                  )
                })
              : (guestValidated ?? []).map((g: any) => (
                  <CartRow
                    key={g.productId}
                    name={g.product?.name ?? g.name}
                    image={g.product?.image ?? g.image}
                    unitPrice={g.price}
                    originalPrice={g.originalPrice !== g.price ? g.originalPrice : undefined}
                    quantity={g.quantity}
                    stock={g.stock}
                    href={`/products/${g.product?.slug ?? g.slug}`}
                    warning={g.missing ? 'این محصول دیگر در فروشگاه موجود نیست' : g.stock === 0 ? 'موجودی تمام شده است' : null}
                    onQty={(q) => guest.setQuantity(g.productId, q)}
                    onRemove={() => {
                      const idx = guest.items.findIndex((i) => i.productId === g.productId)
                      const item = guest.items[idx]
                      guest.remove(g.productId)
                      setGuestUndo(item ? { item, index: idx } : null)
                      toast.success('محصول از سبد حذف شد', {
                        action: {
                          label: 'بازگردانی',
                          onClick: () => {
                            if (item) {
                              guest.add(
                                {
                                  _id: item.productId,
                                  name: item.name,
                                  slug: item.slug,
                                  image: item.image,
                                  price: item.originalPrice,
                                  discountPrice: item.originalPrice !== item.price ? item.price : undefined,
                                  stock: item.stock,
                                  inStock: true,
                                  featured: false,
                                  active: true,
                                  category: 'rice',
                                  categoryFa: '',
                                  description: '',
                                  tags: [],
                                  rating: 0,
                                  reviewsCount: 0,
                                } as unknown as Product,
                                item.quantity
                              )
                            }
                            setGuestUndo(null)
                          },
                        },
                        duration: 6000,
                      })
                    }}
                  />
                ))}

            {user && serverItems.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="w-fit text-muted-foreground hover:text-destructive"
                onClick={() => clearCart.mutate()}
                disabled={clearCart.isPending}
              >
                <Trash2 className="size-4" />
                خالی کردن سبد
              </Button>
            )}
          </div>

          {/* summary */}
          <div className="flex flex-col gap-4 lg:sticky lg:top-32">
            {user ? (
              <Summary
                rows={[
                  ['مبلغ کالاها', toman(cart!.totalAmount)],
                  ...(cart!.totalDiscount > 0 ? [['تخفیف محصولات', `− ${toman(cart!.totalDiscount)}`, 'text-forest-600'] as [string, string, string]] : []),
                  ...(cart!.couponDiscount > 0 ? [[`کد تخفیف (٪${faNum(cart!.couponDiscount)})`, `− ${toman(cart!.couponAmount ?? 0)}`, 'text-forest-600'] as [string, string, string]] : []),
                  ...((cart!.taxAmount ?? 0) > 0 ? [['مالیات بر ارزش افزوده', toman(cart!.taxAmount!)] as [string, string]] : []),
                  ['هزینه ارسال', cart!.shippingFee > 0 ? toman(cart!.shippingFee) : 'در مرحله بعد محاسبه می‌شود'],
                ]}
              >
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="font-bold">مبلغ قابل پرداخت</span>
                  <span className="text-lg font-extrabold text-forest-800">{toman(cart!.finalAmount)}</span>
                </div>

                {/* coupon */}
                {cart!.couponCode ? (
                  <div className="flex items-center justify-between rounded-lg bg-forest-50 p-3 text-sm">
                    <span className="flex items-center gap-2 font-semibold text-forest-700">
                      <Tag className="size-4" aria-hidden />
                      {cart!.couponCode}
                    </span>
                    <button
                      className="text-xs text-destructive hover:underline cursor-pointer"
                      onClick={() => removeCoupon.mutate()}
                      disabled={removeCoupon.isPending}
                    >
                      حذف کد
                    </button>
                  </div>
                ) : (
                  <form
                    className="flex gap-2"
                    onSubmit={(e) => {
                      e.preventDefault()
                      if (couponInput.trim()) applyCoupon.mutate(couponInput.trim())
                    }}
                  >
                    <Input
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="کد تخفیف (مثلاً HTLAND10)"
                      aria-label="کد تخفیف"
                      className="h-9 text-xs"
                    />
                    <Button type="submit" size="sm" variant="secondary" disabled={applyCoupon.isPending || !couponInput.trim()}>
                      اعمال
                    </Button>
                  </form>
                )}

                <Button size="lg" onClick={goCheckout} className="w-full gap-2">
                  ادامه فرآیند خرید
                  <ArrowLeft className="size-4" aria-hidden />
                </Button>
                <p className="text-center text-[11px] text-muted-foreground">هزینه ارسال در مرحله پرداخت، بر اساس آدرس محاسبه می‌شود</p>
              </Summary>
            ) : (
              <Summary
                rows={[
                  ...guestValidatedRows(guestValidated),
                ]}
              >
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="font-bold">مبلغ تقریبی</span>
                  <span className="text-lg font-extrabold text-forest-800">
                    {toman((guestValidated ?? []).reduce((s: number, g: any) => s + (g.missing || g.stock === 0 ? 0 : g.price * g.quantity), 0))}
                  </span>
                </div>
                <Button size="lg" onClick={goCheckout} className="w-full gap-2">
                  ادامه و ورود به حساب
                  <ArrowLeft className="size-4" aria-hidden />
                </Button>
                <p className="text-center text-[11px] text-muted-foreground">
                  پس از ورود، سبد شما با سبد حساب کاربری یکپارچه می‌شود
                </p>
              </Summary>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function guestValidatedRows(guestValidated: any[] | null): Array<[string, string, string?]> {
  const items = guestValidated ?? []
  const subtotal = items.reduce((s, g) => s + (g.missing || g.stock === 0 ? 0 : g.price * g.quantity), 0)
  const savings = items.reduce((s, g) => (g.originalPrice > g.price && !g.missing ? s + (g.originalPrice - g.price) * g.quantity : s), 0)
  const rows: Array<[string, string, string?]> = [
    [`${faNum(items.reduce((s, g) => s + (g.missing ? 0 : g.quantity), 0))} کالا`, toman(subtotal)],
  ]
  if (savings > 0) rows.push(['سود شما از تخفیف', `− ${toman(savings)}`, 'text-forest-600'])
  return rows
}

/* compact product tile for empty-cart recommendations */
function ProductMini({ product }: { product: Product }) {
  return <ProductCard product={product} />
}
