/* Homepage — editorial, data-driven, no fabricated content */
import { Link, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { motion } from 'motion/react'
import { ArrowLeft, Leaf, ShieldCheck, Snowflake, Store } from 'lucide-react'
import { productsApi } from '@/api'
import { ProductCard, ProductCardSkeleton } from '@/components/product-card'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { CATEGORIES, faNum } from '@/lib/format'
import { ErrorState } from '@/components/states'

function Hero() {
  return (
    <section className="relative overflow-hidden bg-forest-800 text-ivory" aria-label="معرفی اچ‌تی‌لند">
      <img
        src="/images/brand/hero.svg"
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-60"
        aria-hidden
      />
      <div className="absolute inset-0 bg-gradient-to-l from-forest-950/80 via-forest-950/35 to-transparent" aria-hidden />
      <div className="container-page relative flex min-h-[440px] flex-col items-start justify-center gap-6 py-16 sm:min-h-[520px]">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 rounded-full border border-ivory/25 bg-ivory/10 px-4 py-1.5 text-xs font-medium backdrop-blur"
        >
          <Leaf className="size-3.5 text-saffron-400" aria-hidden />
          برداشت تازه از طبیعت شمال ایران
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.08 }}
          className="max-w-2xl text-balance text-3xl font-extrabold leading-[1.35] sm:text-5xl sm:leading-[1.3]"
        >
          طعم اصیل شمال ایران،
          <br />
          از مبدأ تا سفره شما
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.16 }}
          className="max-w-xl text-sm leading-8 text-ivory/85 sm:text-base"
        >
          برنج معطر شالیزارهای مازندران، خاویار اصیل خزر، ماهی صید روز، عسل کوهستان و سوغات‌های دست‌ساز گیلان — همه با
          ارسال سریع و بسته‌بندی استاندارد.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.24 }}
          className="flex flex-wrap items-center gap-3"
        >
          <Link to="/products">
            <Button size="lg" variant="accent" className="gap-2">
              <Store className="size-5" aria-hidden />
              شروع خرید
            </Button>
          </Link>
          <Link to="/products?category=rice">
            <Button
              size="lg"
              variant="outline"
              className="border-ivory/40 bg-transparent text-ivory hover:bg-ivory/10 hover:text-ivory"
            >
              برنج‌های معطر شمال
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  )
}

function TrustStrip() {
  const items = [
    { icon: Snowflake, title: 'زنجیره سرد کامل', desc: 'حفظ تازگی محصولات پروتئینی تا درب منزل' },
    { icon: ShieldCheck, title: 'پرداخت امن', desc: 'درگاه بانکی معتبر و کیف پول داخلی' },
    { icon: Leaf, title: 'اصالت کالا', desc: 'تأمین مستقیم از کشاورز و صیاد شمال' },
  ]
  return (
    <section className="border-b bg-card" aria-label="مزایای خرید">
      <div className="container-page grid gap-6 py-6 sm:grid-cols-3">
        {items.map((it) => (
          <div key={it.title} className="flex items-center gap-3.5">
            <div className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-forest-50 text-forest-700">
              <it.icon className="size-5" aria-hidden />
            </div>
            <div>
              <p className="text-sm font-bold">{it.title}</p>
              <p className="text-xs text-muted-foreground">{it.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function Categories({ stats }: { stats: Array<{ _id: string; count: number; categoryFa: string }> }) {
  const countFor = (key: string) => stats.find((s) => s._id === key)?.count
  return (
    <section className="container-page py-12" aria-labelledby="cats-title">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 id="cats-title" className="text-xl font-extrabold sm:text-2xl">
            خرید بر اساس دسته‌بندی
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">هر آنچه شمال ایران دارد، دسته‌بندی‌شده برای شما</p>
        </div>
        <Link to="/products" className="hidden items-center gap-1 text-sm font-semibold text-forest-600 hover:text-forest-800 sm:flex">
          مشاهده همه
          <ArrowLeft className="size-4" aria-hidden />
        </Link>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {Object.entries(CATEGORIES).map(([key, c], i) => (
          <motion.div
            key={key}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.35, delay: i * 0.05 }}
          >
            <Link
              to={`/products?category=${key}`}
              className="group flex flex-col items-center gap-2 rounded-xl border bg-card p-3 text-center shadow-soft transition-all hover:-translate-y-0.5 hover:shadow-lift"
            >
              <img src={c.icon} alt="" width={112} height={84} className="h-21 w-full rounded-lg object-cover" loading="lazy" />
              <span className="text-xs font-bold sm:text-sm">{c.fa}</span>
              <span className="text-[11px] text-muted-foreground">
                {countFor(key) !== undefined ? `${faNum(countFor(key)!)} محصول` : 'مشاهده محصولات'}
              </span>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

function Featured() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['featured', 8],
    queryFn: () => productsApi.featured(8),
  })

  return (
    <section className="bg-ivory-2/60 py-12" aria-labelledby="featured-title">
      <div className="container-page">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <h2 id="featured-title" className="text-xl font-extrabold sm:text-2xl">
              محصولات ویژه
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">منتخب اصیل‌ترین محصولات این فصل</p>
          </div>
          <Link to="/products?featured=true" className="flex items-center gap-1 text-sm font-semibold text-forest-600 hover:text-forest-800">
            همه ویژه‌ها
            <ArrowLeft className="size-4" aria-hidden />
          </Link>
        </div>
        {error ? (
          <ErrorState error={error} onRetry={refetch} title="خطا در دریافت محصولات ویژه" />
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {isLoading
              ? Array.from({ length: 8 }).map((_, i) => <ProductCardSkeleton key={i} />)
              : data?.map((p) => <ProductCard key={p._id} product={p} />)}
          </div>
        )}
      </div>
    </section>
  )
}

function OriginStory() {
  return (
    <section className="container-page py-14" aria-labelledby="story-title">
      <div className="grid items-center gap-8 lg:grid-cols-2">
        <div className="order-2 lg:order-1">
          <p className="mb-2 flex items-center gap-2 text-xs font-bold text-saffron-600">
            <Leaf className="size-4" aria-hidden />
            داستان مبدأ
          </p>
          <h2 id="story-title" className="text-balance text-2xl font-extrabold leading-relaxed sm:text-3xl">
            از شالیزار و تالاب، مستقیم به سفره ایرانی
          </h2>
          <p className="mt-4 text-sm leading-8 text-muted-foreground">
            اچ‌تی‌لند با همکاری مستقیم شالیکاران مازندران، صیادان خزر، زنبورداران جنگل‌های هیرکانی و تولیدکنندگان
            سوغات گیلان، محصولات را بدون واسطه به دست شما می‌رساند. هر محصول با ذکر استان مبدأ عرضه می‌شود و برای
            اقلام تازه، ارسال با بسته‌بندی سرد انجام می‌گیرد.
          </p>
          <ul className="mt-6 grid gap-3 text-sm sm:grid-cols-2">
            {[
              'برداشت فصل و شالیکوبی تازه برای برنج',
              'صید روز و ارسال سریع برای ماهی خزر',
              'برداشت بهاره و بدون حرارت برای عسل',
              'بسته‌بندی استاندارد برای خاویار و سوغات',
            ].map((t) => (
              <li key={t} className="flex items-start gap-2 rounded-lg border bg-card p-3 leading-6">
                <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-accent" aria-hidden />
                {t}
              </li>
            ))}
          </ul>
          <Link to="/products" className="mt-6 inline-block">
            <Button variant="outline" className="gap-2">
              مشاهده محصولات
              <ArrowLeft className="size-4" aria-hidden />
            </Button>
          </Link>
        </div>
        <div className="order-1 overflow-hidden rounded-2xl border shadow-lift lg:order-2">
          <img
            src="/images/brand/hero.svg"
            alt="چشم‌انداز شالیزارها و طبیعت شمال ایران"
            width={1200}
            height={900}
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  const navigate = useNavigate()
  const { data: stats } = useQuery({
    queryKey: ['category-stats'],
    queryFn: () => productsApi.categoryStats(),
    staleTime: 5 * 60_000,
  })

  return (
    <div>
      <Hero />
      <TrustStrip />
      <Categories stats={stats ?? []} />
      <Featured />
      <OriginStory />
      {/* CTA */}
      <section className="container-page pb-16">
        <div className="flex flex-col items-center gap-4 rounded-2xl bg-forest-800 px-6 py-12 text-center text-ivory">
          <h2 className="text-xl font-extrabold sm:text-2xl">امروز سفره‌تان را اصیل کنید</h2>
          <p className="max-w-lg text-sm leading-7 text-ivory/80">
            همین حالا از میان محصولات تازه شمال ایران انتخاب کنید؛ پرداخت امن، ارسال سریع و پشتیبانی از سفارش.
          </p>
          <Button size="lg" variant="accent" onClick={() => navigate('/products')} className="mt-2">
            ورود به فروشگاه
          </Button>
        </div>
      </section>
    </div>
  )
}
