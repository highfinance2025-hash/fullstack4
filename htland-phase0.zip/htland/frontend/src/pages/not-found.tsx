import { Link } from 'react-router-dom'
import { Compass } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function NotFound() {
  return (
    <div className="container-page flex min-h-[60dvh] items-center justify-center py-12">
      <div className="flex flex-col items-center gap-4 text-center">
        <div className="flex size-16 items-center justify-center rounded-full bg-forest-50 text-forest-600">
          <Compass className="size-8" aria-hidden />
        </div>
        <h1 className="text-2xl font-extrabold">صفحه‌ای که دنبالش بودید پیدا نشد</h1>
        <p className="max-w-sm text-sm leading-7 text-muted-foreground">
          ممکن است آدرس تغییر کرده باشد یا محصولی که دنبال آن بودید حذف شده باشد.
        </p>
        <div className="flex gap-2">
          <Link to="/">
            <Button>صفحه اصلی</Button>
          </Link>
          <Link to="/products">
            <Button variant="outline">فروشگاه</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
