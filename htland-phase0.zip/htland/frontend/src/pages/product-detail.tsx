/* Product detail — gallery, real pricing, stock, quantity, add to cart */
import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { ChevronLeft, MapPin, PackageCheck, PackageX, ShieldCheck, ShoppingBasket, Snowflake } from 'lucide-react'
import { productsApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { DiscountBadge, Price } from '@/components/price'
import { QuantityStepper } from '@/components/quantity-stepper'
import { ProductCard, ProductCardSkeleton } from '@/components/product-card'
import { ErrorState } from '@/components/states'
import { useAddToCart } from '@/hooks/useAddToCart'
import { faNum } from '@/lib/format'
import type { Product } from '@/lib/types'
import { cn } from '@/lib/format'

export default function ProductDetail() {
  const { idOrSlug } = useParams<{ idOrSlug: string }>()
  const [qty, setQty] = useState(1)
  const [activeImg, setActiveImg] = useState(0)
  const { addToCart, pendingId } = useAddToCart()

  const { data: product, isLoading, error, refetch } = useQuery({
    queryKey: ['product', idOrSlug],
    queryFn: ({ signal }) => productsApi.detail(idOrSlug!, signal),
    enabled: !!idOrSlug,
  })

  useEffect(() => {
    setQty(1)
    setActiveImg(0)
  }, [idOrSlug])

  const { data: related } = useQuery({
    queryKey: ['products', { category: product?.category, limit: 4 }],
    queryFn: () => productsApi.list({ category: product!.category, limit: 4 }),
    enabled: !!product,
  })

  if (isLoading) {
    return (
      <div className="container-page py-8">
        <Skeleton className="mb-6 h-4 w-48" />
        <div className="grid gap-8 lg:grid-cols-2">
          <Skeleton className="aspect-square rounded-2xl" />
          <div className="flex flex-col gap-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-9 w-3/4" />
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-12 w-64" />
          </div>
        </div>
      </div>
    )
  }

  if (error || !product) {
    return (
      <div className="container-page py-16">
        <ErrorState
          error={error}
          onRetry={refetch}
          title="محصول یافت نشد"
        />
        <div className="mt-4 text-center">
          <Link to="/products">
            <Button variant="outline">بازگشت به فروشگاه</Button>
          </Link>
        </div>
      </div>
    )
  }

  const gallery = [product.image, ...(product.gallery ?? [])].filter(Boolean) as string[]
  const outOfStock = !product.inStock || product.stock <= 0
  const maxQty = Math.min(99, Math.max(1, product.stock))

  return (
    <div className="container-page py-8">
      <nav aria-label="مسیر" className="mb-5 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-forest-700">خانه</Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <Link to="/products" className="hover:text-forest-700">فروشگاه</Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <Link to={`/products?category=${product.category}`} className="hover:text-forest-700">
          {product.categoryFa}
        </Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <span className="font-medium text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        {/* gallery */}
        <section aria-label="تصاویر محصول">
          <div className="overflow-hidden rounded-2xl border bg-ivory-2 shadow-soft">
            <img
              src={gallery[activeImg] ?? gallery[0]}
              alt={product.name}
              width={800}
              height={800}
              className="aspect-square w-full object-cover"
              onError={(e) => {
                ;(e.target as HTMLImageElement).src = '/images/brand/cat-rice.svg'
              }}
            />
          </div>
          {gallery.length > 1 && (
            <div className="mt-3 flex gap-2.5" role="tablist" aria-label="انتخاب تصویر">
              {gallery.map((g, i) => (
                <button
                  key={`${g}-${i}`}
                  role="tab"
                  aria-selected={i === activeImg}
                  aria-label={`تصویر ${faNum(i + 1)}`}
                  className={cn(
                    'size-18 overflow-hidden rounded-lg border-2 transition-all cursor-pointer',
                    i === activeImg ? 'border-forest-700 shadow-soft' : 'border-transparent opacity-70 hover:opacity-100'
                  )}
                  onClick={() => setActiveImg(i)}
                >
                  <img src={g} alt="" width={72} height={72} className="size-full object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          )}
        </section>

        {/* info */}
        <section className="flex flex-col gap-5" aria-label="اطلاعات محصول">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="sage">{product.categoryFa}</Badge>
            {product.metadata?.origin && (
              <Badge variant="outline" className="gap-1 text-muted-foreground">
                <MapPin className="size-3" aria-hidden />
                مبدأ: {product.metadata.origin}
              </Badge>
            )}
            {product.featured && <Badge variant="accent">ویژه</Badge>}
          </div>

          <h1 className="text-balance text-2xl font-extrabold leading-relaxed sm:text-3xl">{product.name}</h1>

          <div className="flex flex-wrap items-center gap-3">
            <Price price={product.price} discountPrice={product.discountPrice} size="xl" />
            <DiscountBadge price={product.price} discountPrice={product.discountPrice} />
          </div>

          {outOfStock ? (
            <p className="flex items-center gap-2 text-sm font-bold text-destructive" role="status">
              <PackageX className="size-5" aria-hidden />
              این محصول در حال حاضر موجود نیست
            </p>
          ) : product.stock <= 5 ? (
            <p className="flex items-center gap-2 text-sm font-bold text-saffron-600" role="status">
              <PackageCheck className="size-5" aria-hidden />
              تنها {faNum(product.stock)} {product.metadata?.unit ?? 'عدد'} در انبار باقی مانده
            </p>
          ) : (
            <p className="flex items-center gap-2 text-sm font-medium text-forest-600" role="status">
              <PackageCheck className="size-5" aria-hidden />
              موجود در انبار
              {product.metadata?.unit ? ` — بسته‌بندی ${product.metadata.unit}` : ''}
            </p>
          )}

          <div className="rounded-xl border bg-card p-5 leading-8 text-sm text-foreground/90" aria-label="توضیحات محصول">
            {product.description}
          </div>

          {product.tags?.length > 0 && (
            <div className="flex flex-wrap gap-2" aria-label="برچسب‌ها">
              {product.tags.map((t) => (
                <span key={t} className="rounded-full bg-forest-50 px-3 py-1 text-xs text-forest-700">
                  {t}
                </span>
              ))}
            </div>
          )}

          {/* purchase box */}
          <div className="rounded-xl border bg-card p-5 shadow-soft">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium">تعداد:</span>
                <QuantityStepper
                  value={qty}
                  onChange={setQty}
                  max={outOfStock ? 1 : maxQty}
                  disabled={outOfStock}
                />
              </div>
              <Button
                size="lg"
                variant="accent"
                className="min-w-44 gap-2"
                disabled={outOfStock}
                loading={pendingId === product._id}
                onClick={() => addToCart(product, qty, { silent: true })}
              >
                {!pendingId && <ShoppingBasket className="size-5" aria-hidden />}
                {outOfStock ? 'ناموجود' : 'افزودن به سبد خرید'}
              </Button>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 border-t pt-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="size-4 text-forest-600" aria-hidden />
                تضمین اصالت کالا
              </span>
              {(product.category === 'fish' || product.category === 'caviar' || product.category === 'chicken') && (
                <span className="flex items-center gap-1.5">
                  <Snowflake className="size-4 text-forest-600" aria-hidden />
                  ارسال با بسته‌بندی سرد
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <MapPin className="size-4 text-forest-600" aria-hidden />
                ارسال از {product.metadata?.origin ?? 'شمال ایران'}
              </span>
            </div>
          </div>
        </section>
      </div>

      {/* related */}
      {related && related.data.filter((p: Product) => p._id !== product._id).length > 0 && (
        <section className="mt-14" aria-labelledby="related-title">
          <h2 id="related-title" className="mb-5 text-lg font-extrabold sm:text-xl">
            محصولات مشابه {product.categoryFa}
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
            {isLoading &&
              Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)}
            {related.data
              .filter((p: Product) => p._id !== product._id)
              .slice(0, 4)
              .map((p: Product) => (
                <ProductCard key={p._id} product={p} />
              ))}
          </div>
        </section>
      )}

      <div className="mt-10">
        <Link to="/products" className="flex items-center gap-1 text-sm text-forest-600 hover:text-forest-800">
          <ChevronLeft className="size-4" aria-hidden />
          بازگشت به فروشگاه
        </Link>
      </div>
    </div>
  )
}
