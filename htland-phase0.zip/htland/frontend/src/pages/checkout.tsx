/* Checkout — address → payment method → review → real order submission */
import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  ArrowLeft,
  ArrowRight,
  Banknote,
  Check,
  CreditCard,
  Landmark,
  MapPin,
  Pencil,
  Plus,
  ShieldCheck,
  Wallet as WalletIcon,
} from 'lucide-react'
import { toast } from 'sonner'
import { addressesApi, cartApi, ordersApi, walletApi, type AddressInput } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { Button } from '@/components/ui/button'
import { Input, Select, Textarea } from '@/components/ui/input'
import { Label, FormError } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/states'
import { cn, faNum, toman } from '@/lib/format'
import { ADDRESS_LABELS, PROVINCES } from '@/lib/provinces'
import { z } from 'zod'

const STEPS = ['آدرس تحویل', 'روش پرداخت', 'بازبینی و ثبت'] as const

const addressSchema = z.object({
  fullName: z.string().min(3, 'نام و نام خانوادگی را کامل وارد کنید').regex(/^[\u0600-\u06FF\s]+$/, 'نام باید با حروف فارسی باشد'),
  phone: z.string().transform((s) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))).pipe(z.string().regex(/^09\d{9}$/, 'شماره موبایل معتبر نیست')),
  province: z.string().min(1, 'استان را انتخاب کنید'),
  city: z.string().min(2, 'نام شهر را وارد کنید'),
  address: z.string().min(10, 'نشانی کامل را وارد کنید (حداقل ۱۰ کاراکتر)'),
  postalCode: z.string().transform((s) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))).pipe(z.string().regex(/^\d{10}$/, 'کد پستی باید ۱۰ رقم باشد')),
  label: z.string().optional(),
  buildingNumber: z.string().optional(),
  unit: z.string().optional(),
  floor: z.string().optional(),
  description: z.string().max(200, 'توضیحات حداکثر ۲۰۰ کاراکتر').optional(),
})

type Step = 0 | 1 | 2

export default function Checkout() {
  const { user, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [step, setStep] = useState<Step>(0)
  const [addressId, setAddressId] = useState<string | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<'wallet' | 'zarinpal' | 'bank_transfer' | 'cash_on_delivery' | null>(null)
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!authLoading && !user) navigate('/login?redirect=/checkout', { replace: true })
  }, [authLoading, user, navigate])

  /* cart must be loaded and non-empty */
  const { data: cart, isLoading: cartLoading } = useQuery({
    queryKey: ['cart'],
    queryFn: () => cartApi.get(),
    enabled: !!user,
    retry: 1,
  })

  const { data: addresses, isLoading: addrLoading, refetch: refetchAddresses } = useQuery({
    queryKey: ['addresses'],
    queryFn: () => addressesApi.list(),
    enabled: !!user,
  })

  const { data: wallets } = useQuery({
    queryKey: ['wallets'],
    queryFn: () => walletApi.list(),
    enabled: !!user,
  })

  const myWallet = wallets?.[0]

  /* default-select default address */
  useEffect(() => {
    if (addresses && !addressId) {
      const def = addresses.find((a) => a.isDefault) ?? addresses[0]
      if (def) setAddressId(def._id)
    }
  }, [addresses, addressId])

  /* checkout prepare (validation + server totals) */
  const [prepare, setPrepare] = useState<{ checkoutId: string; cartSummary: any } | null>(null)
  const prepareCheckout = useMutation({
    mutationFn: () => cartApi.prepareCheckout(),
    onSuccess: (d) => setPrepare(d),
    onError: (e: Error) => toast.error(e.message),
  })

  useEffect(() => {
    if (step === 2 && !prepare) prepareCheckout.mutate()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step])

  const selectedAddress = useMemo(
    () => addresses?.find((a) => a._id === addressId) ?? null,
    [addresses, addressId]
  )

  /* ── order submission ── */
  const submitOrder = async () => {
    if (!addressId || !paymentMethod) return
    setSubmitting(true)
    try {
      const res = await ordersApi.create({
        shippingAddressId: addressId,
        paymentMethod,
        notes: notes.trim() || undefined,
      })
      const d = res.data
      qc.invalidateQueries({ queryKey: ['cart'] })
      if (d.redirectToGateway && d.paymentUrl) {
        // real gateway handoff returned by the backend
        toast.info('در حال انتقال به درگاه پرداخت…')
        window.location.href = d.paymentUrl
        return
      }
      navigate(`/orders/${d.orderId}/success?orderNumber=${encodeURIComponent(d.orderNumber)}`, { replace: true })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'ثبت سفارش ناموفق بود')
      qc.invalidateQueries({ queryKey: ['cart'] })
    } finally {
      setSubmitting(false)
    }
  }

  if (authLoading || (user && cartLoading)) {
    return (
      <div className="container-page py-10">
        <Skeleton className="mb-8 h-8 w-64" />
        <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
          <Skeleton className="h-80 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    )
  }

  if (!user) return null

  if (!cartLoading && (cart?.totalItems ?? 0) === 0) {
    return (
      <div className="container-page py-16">
        <EmptyState
          title="سبد خرید شما خالی است"
          description="برای ادامه فرآیند خرید، ابتدا محصولی به سبد اضافه کنید."
          action={
            <Link to="/products">
              <Button>رفتن به فروشگاه</Button>
            </Link>
          }
        />
      </div>
    )
  }

  const summary = prepare?.cartSummary ?? cart

  return (
    <div className="container-page py-8">
      <nav aria-label="مسیر" className="mb-5 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-forest-700">خانه</Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <Link to="/cart" className="hover:text-forest-700">سبد خرید</Link>
        <span className="mx-1.5" aria-hidden>/</span>
        <span className="font-medium text-foreground">تسویه حساب</span>
      </nav>

      <h1 className="mb-6 text-xl font-extrabold sm:text-2xl">تسویه حساب</h1>

      {/* stepper */}
      <ol className="mb-8 flex items-center gap-2" aria-label="مراحل خرید">
        {STEPS.map((s, i) => (
          <li key={s} className="flex flex-1 items-center gap-2">
            <span
              className={cn(
                'flex size-8 shrink-0 items-center justify-center rounded-full text-sm font-bold transition-colors',
                i < step ? 'bg-forest-600 text-ivory' : i === step ? 'bg-forest-800 text-ivory' : 'bg-forest-100 text-muted-foreground'
              )}
              aria-current={i === step ? 'step' : undefined}
            >
              {i < step ? <Check className="size-4" aria-hidden /> : faNum(i + 1)}
            </span>
            <span className={cn('hidden text-sm font-medium sm:block', i === step ? 'text-foreground' : 'text-muted-foreground')}>{s}</span>
            {i < STEPS.length - 1 && <span className="h-px flex-1 bg-border" aria-hidden />}
          </li>
        ))}
      </ol>

      <div className="grid items-start gap-6 lg:grid-cols-[1fr_340px]">
        <div className="rounded-xl border bg-card p-5 shadow-soft sm:p-6">
          {/* ── STEP 1: address ── */}
          {step === 0 && (
            <section aria-labelledby="step-addr">
              <h2 id="step-addr" className="mb-4 flex items-center gap-2 font-bold">
                <MapPin className="size-5 text-forest-700" aria-hidden />
                انتخاب آدرس تحویل
              </h2>
              {addrLoading ? (
                <div className="flex flex-col gap-3">
                  <Skeleton className="h-24 rounded-lg" />
                  <Skeleton className="h-24 rounded-lg" />
                </div>
              ) : (addresses?.length ?? 0) === 0 ? (
                <EmptyState
                  title="هنوز آدرسی ثبت نکرده‌اید"
                  description="برای ارسال سفارش، یک آدرس تحویل اضافه کنید."
                  className="py-8"
                />
              ) : (
                <div className="grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label="آدرس‌های ثبت‌شده">
                  {addresses!.map((a) => (
                    <label
                      key={a._id}
                      className={cn(
                        'relative flex cursor-pointer flex-col gap-1.5 rounded-xl border-2 p-4 text-sm transition-all',
                        addressId === a._id ? 'border-forest-700 bg-forest-50/60 shadow-soft' : 'border-input hover:border-forest-300'
                      )}
                    >
                      <input
                        type="radio"
                        name="address"
                        className="sr-only"
                        checked={addressId === a._id}
                        onChange={() => setAddressId(a._id)}
                      />
                      <span className="flex items-center justify-between">
                        <span className="font-bold">{a.fullName}</span>
                        {a.isDefault && <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px]">پیش‌فرض</span>}
                      </span>
                      <span className="text-xs text-muted-foreground">{faNum(a.phone)}</span>
                      <span className="leading-6 text-foreground/90">
                        {a.province}، {a.city}، {a.address}
                        {a.buildingNumber ? `، پلاک ${a.buildingNumber}` : ''}
                        {a.unit ? `، واحد ${a.unit}` : ''}
                      </span>
                      <span className="text-[11px] text-muted-foreground">کد پستی: {faNum(a.postalCode)}</span>
                    </label>
                  ))}
                </div>
              )}
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <AddressFormDialog onSaved={(id) => { refetchAddresses(); if (id) setAddressId(id) }} />
                {selectedAddress && <AddressFormDialog editAddress={selectedAddress} onSaved={() => refetchAddresses()} />}
              </div>
              <div className="mt-6 flex justify-between">
                <Link to="/cart">
                  <Button variant="ghost" className="gap-2">
                    <ArrowRight className="size-4" aria-hidden />
                    بازگشت به سبد
                  </Button>
                </Link>
                <Button disabled={!addressId} onClick={() => setStep(1)} className="gap-2">
                  مرحله بعد
                  <ArrowLeft className="size-4" aria-hidden />
                </Button>
              </div>
            </section>
          )}

          {/* ── STEP 2: payment ── */}
          {step === 1 && (
            <section aria-labelledby="step-pay">
              <h2 id="step-pay" className="mb-4 flex items-center gap-2 font-bold">
                <CreditCard className="size-5 text-forest-700" aria-hidden />
                انتخاب روش پرداخت
              </h2>
              <div className="grid gap-3" role="radiogroup" aria-label="روش‌های پرداخت">
                {(
                  [
                    { key: 'zarinpal' as const, icon: CreditCard, fa: 'پرداخت اینترنتی (زرین‌پال)', desc: 'انتقال به درگاه پرداخت و بازگشت خودکار به فروشگاه', disabled: false },
                    {
                      key: 'wallet',
                      icon: WalletIcon,
                      fa: `کیف پول اچ‌تی‌لند${myWallet ? ` — موجودی: ${toman(myWallet.balance)}` : ''}`,
                      desc: myWallet ? 'پرداخت آنی از موجودی کیف پول' : 'برای پرداخت با کیف پول، ابتدا کیف پول بسازید و شارژ کنید',
                      disabled: !myWallet,
                    } as const,
                    { key: 'bank_transfer' as const, icon: Landmark, fa: 'کارت به کارت / انتقال بانکی', desc: 'سفارش ثبت می‌شود و پس از تأیید واریز پردازش می‌گردد', disabled: false },
                    { key: 'cash_on_delivery' as const, icon: Banknote, fa: 'پرداخت در محل', desc: 'پرداخت هنگام دریافت سفارش', disabled: false },
                  ] as const
                ).map((m) => (
                  <label
                    key={m.key}
                    className={cn(
                      'flex cursor-pointer items-start gap-3 rounded-xl border-2 p-4 transition-all',
                      paymentMethod === m.key ? 'border-forest-700 bg-forest-50/60 shadow-soft' : 'border-input hover:border-forest-300',
                      m.disabled && 'cursor-not-allowed opacity-60'
                    )}
                  >
                    <input
                      type="radio"
                      name="payment"
                      className="sr-only"
                      checked={paymentMethod === m.key}
                      disabled={m.disabled}
                      onChange={() => setPaymentMethod(m.key)}
                    />
                    <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-lg', paymentMethod === m.key ? 'bg-forest-800 text-ivory' : 'bg-forest-50 text-forest-700')}>
                      <m.icon className="size-5" aria-hidden />
                    </span>
                    <span className="flex flex-col gap-1">
                      <span className="text-sm font-bold">{m.fa}</span>
                      <span className="text-xs leading-5 text-muted-foreground">{m.desc}</span>
                    </span>
                  </label>
                ))}
              </div>

              <div className="mt-4">
                <Label htmlFor="order-notes">یادداشت سفارش (اختیاری)</Label>
                <Textarea
                  id="order-notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  maxLength={500}
                  placeholder="مثلاً: تحویل به نگهبان ساختمان داده شود"
                  className="mt-2"
                />
              </div>

              <div className="mt-6 flex justify-between">
                <Button variant="ghost" className="gap-2" onClick={() => setStep(0)}>
                  <ArrowRight className="size-4" aria-hidden />
                  بازگشت
                </Button>
                <Button
                  disabled={!paymentMethod}
                  className="gap-2"
                  onClick={() => {
                    if (paymentMethod === 'wallet' && !myWallet) return
                    setStep(2)
                  }}
                >
                  مرحله بعد
                  <ArrowLeft className="size-4" aria-hidden />
                </Button>
              </div>
            </section>
          )}

          {/* ── STEP 3: review ── */}
          {step === 2 && (
            <section aria-labelledby="step-review">
              <h2 id="step-review" className="mb-4 flex items-center gap-2 font-bold">
                <ShieldCheck className="size-5 text-forest-700" aria-hidden />
                بازبینی نهایی سفارش
              </h2>
              {prepareCheckout.isPending ? (
                <div className="flex flex-col gap-3">
                  <Skeleton className="h-20 rounded-lg" />
                  <Skeleton className="h-20 rounded-lg" />
                </div>
              ) : (
                <div className="flex flex-col gap-4 text-sm">
                  <div className="rounded-lg border p-4">
                    <p className="mb-1 text-xs font-bold text-muted-foreground">آدرس تحویل</p>
                    {selectedAddress && (
                      <>
                        <p className="font-semibold">{selectedAddress.fullName} — {faNum(selectedAddress.phone)}</p>
                        <p className="mt-1 leading-6 text-foreground/85">
                          {selectedAddress.province}، {selectedAddress.city}، {selectedAddress.address}
                          {selectedAddress.buildingNumber ? `، پلاک ${selectedAddress.buildingNumber}` : ''}
                          {selectedAddress.unit ? `، واحد ${selectedAddress.unit}` : ''} — کد پستی {faNum(selectedAddress.postalCode)}
                        </p>
                      </>
                    )}
                  </div>
                  <div className="rounded-lg border p-4">
                    <p className="mb-1 text-xs font-bold text-muted-foreground">روش پرداخت</p>
                    <p className="font-semibold">
                      {paymentMethod === 'zarinpal' && 'پرداخت اینترنتی (زرین‌پال)'}
                      {paymentMethod === 'wallet' && 'کیف پول اچ‌تی‌لند'}
                      {paymentMethod === 'bank_transfer' && 'کارت به کارت / انتقال بانکی'}
                      {paymentMethod === 'cash_on_delivery' && 'پرداخت در محل'}
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <p className="mb-2 text-xs font-bold text-muted-foreground">اقلام سفارش</p>
                    <ul className="flex flex-col gap-2">
                      {(summary?.items ?? []).map((it: any, i: number) => (
                        <li key={i} className="flex items-center justify-between gap-3">
                          <span className="line-clamp-1">{it.productName}</span>
                          <span className="shrink-0 text-muted-foreground">
                            {faNum(it.quantity)} × {toman(it.price)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  {notes.trim() && (
                    <div className="rounded-lg border p-4">
                      <p className="mb-1 text-xs font-bold text-muted-foreground">یادداشت شما</p>
                      <p className="leading-6">{notes}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-6 flex justify-between">
                <Button variant="ghost" className="gap-2" onClick={() => setStep(1)} disabled={submitting}>
                  <ArrowRight className="size-4" aria-hidden />
                  بازگشت
                </Button>
                <Button
                  size="lg"
                  variant="accent"
                  loading={submitting}
                  disabled={prepareCheckout.isPending || !prepare}
                  onClick={submitOrder}
                >
                  {paymentMethod === 'zarinpal' ? 'پرداخت و ثبت سفارش' : 'ثبت نهایی سفارش'}
                </Button>
              </div>
            </section>
          )}
        </div>

        {/* summary sidebar */}
        <aside className="flex flex-col gap-3 rounded-xl border bg-card p-5 shadow-soft lg:sticky lg:top-32" aria-label="خلاصه پرداخت">
          <h2 className="font-bold">پرداخت شما</h2>
          <Separator />
          <dl className="flex flex-col gap-2.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">مبلغ کالاها</dt>
              <dd className="font-semibold">{toman(summary?.totalAmount ?? 0)}</dd>
            </div>
            {(summary?.totalDiscount ?? 0) > 0 && (
              <div className="flex justify-between">
                <dt className="text-muted-foreground">تخفیف محصولات</dt>
                <dd className="font-semibold text-forest-600">− {toman(summary!.totalDiscount)}</dd>
              </div>
            )}
            {(summary?.couponDiscount ?? 0) > 0 && (
              <div className="flex justify-between">
                <dt className="text-muted-foreground">کد تخفیف (٪{faNum(summary!.couponDiscount)})</dt>
                <dd className="font-semibold text-forest-600">− {toman(summary!.couponAmount ?? 0)}</dd>
              </div>
            )}
            {(summary?.taxAmount ?? 0) > 0 && (
              <div className="flex justify-between">
                <dt className="text-muted-foreground">مالیات بر ارزش افزوده</dt>
                <dd className="font-semibold">{toman(summary!.taxAmount!)}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-muted-foreground">هزینه ارسال</dt>
              <dd className="font-semibold">{(summary?.shippingFee ?? 0) > 0 ? toman(summary!.shippingFee) : 'بر اساس مبدأ'}</dd>
            </div>
          </dl>
          <Separator />
          <div className="flex items-center justify-between">
            <span className="font-bold">مبلغ قابل پرداخت</span>
            <span className="text-lg font-extrabold text-forest-800">{toman(summary?.finalAmount ?? 0)}</span>
          </div>
          <p className="rounded-lg bg-forest-50 p-3 text-[11px] leading-5 text-muted-foreground">
            با ثبت سفارش، موجودی کالاها رزرو و پرداخت شما طبق روش انتخابی انجام می‌شود. مبلغ نهایی بر اساس محاسبه سرور است.
          </p>
        </aside>
      </div>
    </div>
  )
}

/* ── address create/edit dialog ── */
function AddressFormDialog({ editAddress, onSaved }: { editAddress?: any; onSaved: (newId?: string) => void }) {
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({
    fullName: editAddress?.fullName ?? '',
    phone: editAddress?.phone ?? '',
    province: editAddress?.province ?? '',
    city: editAddress?.city ?? '',
    address: editAddress?.address ?? '',
    postalCode: editAddress?.postalCode ?? '',
    label: editAddress?.label ?? 'خانه',
    buildingNumber: editAddress?.buildingNumber ?? '',
    unit: editAddress?.unit ?? '',
    floor: editAddress?.floor ?? '',
    description: editAddress?.description ?? '',
    isDefault: editAddress?.isDefault ?? false,
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  const set = (k: string, v: string | boolean) => setForm((f) => ({ ...f, [k]: v }))

  const save = async () => {
    const parsed = addressSchema.safeParse(form)
    if (!parsed.success) {
      const errs: Record<string, string> = {}
      parsed.error.issues.forEach((i) => {
        const key = String(i.path[0] ?? 'form')
        if (!errs[key]) errs[key] = i.message
      })
      setErrors(errs)
      return
    }
    setErrors({})
    setSaving(true)
    try {
      const payload: AddressInput = {
        ...(parsed.data as unknown as AddressInput),
        ...(form.isDefault ? { isDefault: true } : {}),
      }
      if (editAddress) {
        await addressesApi.update(editAddress._id, payload)
        toast.success('آدرس به‌روزرسانی شد')
        onSaved()
      } else {
        const created = await addressesApi.create(payload)
        toast.success('آدرس جدید ثبت شد')
        onSaved(created?._id)
      }
      setOpen(false)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'ثبت آدرس ناموفق بود')
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      {editAddress ? (
        <Button variant="outline" size="sm" className="gap-2" onClick={() => setOpen(true)}>
          <Pencil className="size-4" aria-hidden />
          ویرایش آدرس انتخاب‌شده
        </Button>
      ) : (
        <Button variant="secondary" size="sm" className="gap-2" onClick={() => setOpen(true)}>
          <Plus className="size-4" aria-hidden />
          افزودن آدرس جدید
        </Button>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle>{editAddress ? 'ویرایش آدرس' : 'افزودن آدرس جدید'}</DialogTitle>
            <DialogDescription>اطلاعات تحویل سفارش را وارد کنید.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="af-name">نام و نام خانوادگی (فارسی)</Label>
              <Input id="af-name" value={form.fullName} onChange={(e) => set('fullName', e.target.value)} className="mt-1.5" />
              <FormError message={errors.fullName} />
            </div>
            <div>
              <Label htmlFor="af-phone">شماره موبایل گیرنده</Label>
              <Input id="af-phone" inputMode="numeric" dir="ltr" value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="09121112233" className="mt-1.5 text-left" />
              <FormError message={errors.phone} />
            </div>
            <div>
              <Label htmlFor="af-province">استان</Label>
              <Select id="af-province" value={form.province} onChange={(e) => set('province', e.target.value)} className="mt-1.5">
                <option value="">انتخاب استان…</option>
                {PROVINCES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </Select>
              <FormError message={errors.province} />
            </div>
            <div>
              <Label htmlFor="af-city">شهر</Label>
              <Input id="af-city" value={form.city} onChange={(e) => set('city', e.target.value)} className="mt-1.5" />
              <FormError message={errors.city} />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="af-address">نشانی کامل</Label>
              <Textarea id="af-address" value={form.address} onChange={(e) => set('address', e.target.value)} className="mt-1.5" placeholder="خیابان، کوچه، ساختمان…" />
              <FormError message={errors.address} />
            </div>
            <div>
              <Label htmlFor="af-postal">کد پستی ۱۰ رقمی</Label>
              <Input id="af-postal" inputMode="numeric" dir="ltr" value={form.postalCode} onChange={(e) => set('postalCode', e.target.value)} className="mt-1.5 text-left" />
              <FormError message={errors.postalCode} />
            </div>
            <div>
              <Label htmlFor="af-label">برچسب</Label>
              <Select id="af-label" value={form.label} onChange={(e) => set('label', e.target.value)} className="mt-1.5">
                {ADDRESS_LABELS.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="af-building">پلاک (اختیاری)</Label>
              <Input id="af-building" value={form.buildingNumber} onChange={(e) => set('buildingNumber', e.target.value)} className="mt-1.5" />
            </div>
            <div>
              <Label htmlFor="af-unit">واحد (اختیاری)</Label>
              <Input id="af-unit" value={form.unit} onChange={(e) => set('unit', e.target.value)} className="mt-1.5" />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="af-desc">توضیحات برای پیک (اختیاری)</Label>
              <Input id="af-desc" value={form.description} onChange={(e) => set('description', e.target.value)} className="mt-1.5" placeholder="مثلاً: زنگ واحد ۲ بزنید" />
              <FormError message={errors.description} />
            </div>
            <label className="flex cursor-pointer items-center gap-2.5 text-sm sm:col-span-2">
              <input type="checkbox" checked={form.isDefault} onChange={(e) => set('isDefault', e.target.checked)} className="size-4 accent-forest-800" />
              این آدرس به‌عنوان آدرس پیش‌فرض ثبت شود
            </label>
          </div>
          <div className="mt-2 flex gap-2">
            <Button onClick={save} loading={saving} className="flex-1">
              {editAddress ? 'ذخیره تغییرات' : 'ثبت آدرس'}
            </Button>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              انصراف
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
