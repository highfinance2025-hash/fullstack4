/* OTP login — real backend flow with countdown, resend, and error recovery */
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, KeyRound, ShieldCheck, Smartphone } from 'lucide-react'
import { toast } from 'sonner'
import { authApi, cartApi } from '@/api'
import { ApiError } from '@/lib/api'
import { useAuth } from '@/hooks/useAuth'
import { useGuestCart } from '@/hooks/useGuestCart'
import { useQueryClient } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label, FormError } from '@/components/ui/label'
import { cn, faNum, toLatinDigits } from '@/lib/format'
import { z } from 'zod'

const phoneSchema = z.string().transform(toLatinDigits).pipe(z.string().regex(/^09\d{9}$/, 'شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۱۱۲۲۳۳)'))

export default function Login() {
  const [params] = useSearchParams()
  const redirect = params.get('redirect') || '/account'
  const navigate = useNavigate()
  const { user, loading, login } = useAuth()
  const guest = useGuestCart()
  const qc = useQueryClient()

  const [step, setStep] = useState<'phone' | 'otp'>('phone')
  const [phone, setPhone] = useState('')
  const [phoneError, setPhoneError] = useState<string | null>(null)
  const [digits, setDigits] = useState<string[]>(Array(6).fill(''))
  const [otpError, setOtpError] = useState<string | null>(null)
  const [terms, setTerms] = useState(false)
  const [termsError, setTermsError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const [isNewUser, setIsNewUser] = useState<boolean | null>(null)
  const boxesRef = useRef<Array<HTMLInputElement | null>>(Array(6).fill(null))

  useEffect(() => {
    if (!loading && user) navigate(redirect, { replace: true })
  }, [loading, user, navigate, redirect])

  useEffect(() => {
    if (countdown <= 0) return
    const t = setInterval(() => setCountdown((c) => c - 1), 1000)
    return () => clearInterval(t)
  }, [countdown])

  const otpValue = useMemo(() => digits.join(''), [digits])

  const sendOtp = async () => {
    const parsed = phoneSchema.safeParse(phone)
    if (!parsed.success) {
      setPhoneError(parsed.error.issues[0]?.message ?? 'شماره موبایل معتبر نیست')
      return
    }
    setPhoneError(null)
    setSending(true)
    try {
      const res = await authApi.sendOtp(parsed.data)
      setPhone(parsed.data)
      setIsNewUser(res.isNewUser ?? null)
      setStep('otp')
      setCountdown(res.expiresIn ?? 120)
      setDigits(Array(6).fill(''))
      setOtpError(null)
      toast.success('کد تأیید ارسال شد', { description: `به شماره ${faNum(parsed.data)}` })
      // server (non-production) returns the code for testing — surface it transparently
      if (res.otpCode) {
        toast.info(`کد تأیید (حالت آزمایشی سرور): ${faNum(res.otpCode)}`, { duration: 10000 })
      }
      setTimeout(() => boxesRef.current[0]?.focus(), 80)
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'ارسال کد ناموفق بود'
      setPhoneError(msg)
    } finally {
      setSending(false)
    }
  }

  const verifyOtp = async (code?: string) => {
    const value = (code ?? otpValue).trim()
    if (value.length !== 6) {
      setOtpError('کد تأیید باید ۶ رقم باشد')
      return
    }
    if (!terms) {
      setTermsError('برای ادامه، پذیرش شرایط استفاده لازم است')
      return
    }
    setTermsError(null)
    setOtpError(null)
    setVerifying(true)
    try {
      const res = await authApi.verifyOtp(phone, value, { acceptedTerms: true, acceptedPrivacy: true })
      login(res.token, res.user)
      // migrate guest cart through the real API
      try {
        await guest.migrateToServer((pid, qty) => cartApi.addItem(pid, qty))
        qc.invalidateQueries({ queryKey: ['cart'] })
      } catch {
        /* non-fatal */
      }
      toast.success(`خوش آمدید${res.user.fullName ? `، ${res.user.fullName}` : ''}!`)
      navigate(redirect, { replace: true })
    } catch (e) {
      if (e instanceof ApiError) {
        setOtpError(e.message)
        // invalid code → clear boxes
        if (e.status === 400 || e.status === 404) {
          setDigits(Array(6).fill(''))
          boxesRef.current[0]?.focus()
        }
      } else {
        setOtpError('بررسی کد ناموفق بود؛ دوباره تلاش کنید')
      }
    } finally {
      setVerifying(false)
    }
  }

  const setDigit = (index: number, raw: string) => {
    const clean = toLatinDigits(raw).replace(/\D/g, '')
    setOtpError(null)
    if (clean.length > 1) {
      // paste or multi-char input
      const chars = clean.slice(0, 6).split('')
      const next = Array(6).fill('')
      chars.forEach((c, i) => (next[i] = c))
      setDigits(next)
      const fill = Math.min(chars.length, 5)
      boxesRef.current[fill]?.focus()
      if (chars.length === 6) verifyOtp(next.join(''))
      return
    }
    const next = [...digits]
    next[index] = clean
    setDigits(next)
    if (clean && index < 5) boxesRef.current[index + 1]?.focus()
    if (next.every((d) => d !== '')) verifyOtp(next.join(''))
  }

  const onKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      boxesRef.current[index - 1]?.focus()
    }
    if (e.key === 'ArrowRight' && index < 5) boxesRef.current[index + 1]?.focus()
    if (e.key === 'ArrowLeft' && index > 0) boxesRef.current[index - 1]?.focus()
  }

  return (
    <div className="container-page flex min-h-[70dvh] items-center justify-center py-10">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border bg-card p-6 shadow-soft sm:p-8">
          {step === 'phone' ? (
            <>
              <div className="mb-6 flex flex-col items-center gap-3 text-center">
                <div className="flex size-14 items-center justify-center rounded-2xl bg-forest-50 text-forest-700">
                  <Smartphone className="size-7" aria-hidden />
                </div>
                <h1 className="text-lg font-extrabold">ورود | ثبت‌نام</h1>
                <p className="text-sm leading-6 text-muted-foreground">
                  شماره موبایل خود را وارد کنید؛ کد تأیید برای شما پیامک می‌شود.
                </p>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  sendOtp()
                }}
                className="flex flex-col gap-4"
              >
                <div>
                  <Label htmlFor="phone">شماره موبایل</Label>
                  <Input
                    id="phone"
                    inputMode="numeric"
                    autoComplete="tel"
                    placeholder="۰۹۱۲۱۱۱۲۲۳۳"
                    value={faNum(phone) || phone}
                    onChange={(e) => {
                      setPhone(toLatinDigits(e.target.value).replace(/\D/g, '').slice(0, 11))
                      setPhoneError(null)
                    }}
                    className="mt-2 h-12 text-center text-lg tracking-widest"
                    dir="ltr"
                    aria-invalid={!!phoneError}
                  />
                  <FormError message={phoneError} />
                </div>
                <Button type="submit" size="lg" loading={sending} className="w-full gap-2">
                  {!sending && <ArrowLeft className="size-4" aria-hidden />}
                  دریافت کد تأیید
                </Button>
                <p className="flex items-start gap-2 rounded-lg bg-forest-50 p-3 text-[11px] leading-5 text-muted-foreground">
                  <ShieldCheck className="mt-0.5 size-4 shrink-0 text-forest-600" aria-hidden />
                  ورود شما به معنای پذیرش شرایط استفاده و سیاست حریم خصوصی اچ‌تی‌لند است.
                </p>
              </form>
            </>
          ) : (
            <>
              <button
                className="mb-4 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-forest-700 cursor-pointer"
                onClick={() => {
                  setStep('phone')
                  setOtpError(null)
                }}
              >
                <ArrowRight className="size-4" aria-hidden />
                تغییر شماره
              </button>
              <div className="mb-6 flex flex-col items-center gap-3 text-center">
                <div className="flex size-14 items-center justify-center rounded-2xl bg-forest-50 text-forest-700">
                  <KeyRound className="size-7" aria-hidden />
                </div>
                <h1 className="text-lg font-extrabold">کد تأیید را وارد کنید</h1>
                <p className="text-sm leading-6 text-muted-foreground">
                  کد ۶ رقمی به شماره <span className="font-bold text-foreground">{faNum(phone)}</span> ارسال شد
                  {isNewUser && <span className="block text-xs">— حساب جدیدی برای شما ساخته می‌شود</span>}
                </p>
              </div>

              <div className="flex justify-center gap-2" dir="ltr">
                {digits.map((d, i) => (
                  <input
                    key={i}
                    ref={(el) => {
                      boxesRef.current[i] = el
                    }}
                    type="text"
                    inputMode="numeric"
                    autoComplete={i === 0 ? 'one-time-code' : 'off'}
                    maxLength={6}
                    value={d ? faNum(d) : ''}
                    onChange={(e) => setDigit(i, e.target.value)}
                    onKeyDown={(e) => onKeyDown(i, e)}
                    aria-label={`رقم ${i + 1} کد تأیید`}
                    className={cn(
                      'size-12 rounded-lg border-2 bg-card text-center text-xl font-bold transition-colors sm:size-13',
                      otpError ? 'border-destructive/60' : d ? 'border-forest-600' : 'border-input',
                      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:border-ring'
                    )}
                  />
                ))}
              </div>
              <FormError message={otpError} className="mt-3 text-center" />

              <label className="mt-4 flex cursor-pointer items-start justify-center gap-2 text-xs leading-5">
                <input
                  type="checkbox"
                  checked={terms}
                  onChange={(e) => {
                    setTerms(e.target.checked)
                    if (e.target.checked) setTermsError(null)
                  }}
                  className="mt-0.5 size-4 accent-forest-800"
                />
                <span className="text-muted-foreground">شرایط استفاده و سیاست حریم خصوصی اچ‌تی‌لند را می‌پذیرم</span>
              </label>
              <FormError message={termsError} className="text-center" />

              <Button
                size="lg"
                className="mt-5 w-full"
                loading={verifying}
                onClick={() => verifyOtp()}
              >
                ورود به حساب
              </Button>

              <div className="mt-4 text-center text-sm">
                {countdown > 0 ? (
                  <p className="text-muted-foreground">
                    ارسال مجدد کد تا <span className="font-bold text-forest-700 tabular-nums">{faNum(countdown)}</span> ثانیه دیگر
                  </p>
                ) : (
                  <button
                    className="font-semibold text-forest-600 hover:text-forest-800 cursor-pointer disabled:opacity-50"
                    onClick={sendOtp}
                    disabled={sending}
                  >
                    {sending ? 'در حال ارسال…' : 'ارسال مجدد کد'}
                  </button>
                )}
              </div>
            </>
          )}
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          <Link to="/products" className="hover:text-forest-700">
            ادامه خرید بدون ورود
          </Link>
        </p>
      </div>
    </div>
  )
}
