/* Public order tracking — real /track endpoint */
import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { PackageSearch } from 'lucide-react'
import { ordersApi } from '@/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label, FormError } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ErrorState, EmptyState } from '@/components/states'
import { ORDER_STATUS_COLORS, faDateTime, faNum } from '@/lib/format'

export default function TrackOrder() {
  const [orderNumber, setOrderNumber] = useState('')
  const [phone, setPhone] = useState('')
  const [submitted, setSubmitted] = useState<{ orderNumber: string; phone: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  const { data, isFetching, error: queryError, refetch } = useQuery({
    queryKey: ['track', submitted?.orderNumber, submitted?.phone],
    queryFn: ({ signal }) => ordersApi.track(submitted!.orderNumber, submitted!.phone || undefined),
    enabled: !!submitted,
    retry: false,
  })

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const on = orderNumber.trim()
    if (!on) {
      setError('شماره سفارش را وارد کنید (مثلاً HT-14040701-12345)')
      return
    }
    if (!/^09[0-9]{9}$/.test(phone.trim())) {
      setError('شماره موبایل ثبت‌شده در سفارش را وارد کنید (۰۹...)')
      return
    }
    setError(null)
    setSubmitted({ orderNumber: on, phone: phone.trim() })
  }

  return (
    <div className="container-page py-10">
      <div className="mx-auto max-w-2xl">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex size-14 items-center justify-center rounded-2xl bg-forest-50 text-forest-700">
            <PackageSearch className="size-7" aria-hidden />
          </div>
          <h1 className="text-xl font-extrabold sm:text-2xl">پیگیری سفارش</h1>
          <p className="text-sm leading-6 text-muted-foreground">شماره سفارش و شماره موبایل ثبت‌شده در آن را وارد کنید تا وضعیت لحظه‌ای سفارش را ببینید.</p>
        </div>

        <form onSubmit={submit} className="mb-8 flex flex-col gap-3 rounded-xl border bg-card p-5 shadow-soft sm:flex-row sm:items-end">
          <div className="flex-1">
            <Label htmlFor="track-on">شماره سفارش</Label>
            <Input
              id="track-on"
              dir="ltr"
              value={orderNumber}
              onChange={(e) => {
                setOrderNumber(e.target.value)
                setError(null)
              }}
              placeholder="HT-14040701-12345"
              className="mt-1.5 text-left"
            />
          </div>
          <div className="flex-1">
            <Label htmlFor="track-phone">موبایل گیرنده</Label>
            <Input
              id="track-phone"
              dir="ltr"
              inputMode="numeric"
              maxLength={11}
              value={phone}
              onChange={(e) => {
                setPhone(e.target.value.replace(/[^0-9]/g, ''))
                setError(null)
              }}
              placeholder="09xxxxxxxxx"
              className="mt-1.5 text-left"
            />
            <FormError message={error} />
          </div>
          <Button type="submit" loading={isFetching}>
            پیگیری
          </Button>
        </form>

        {queryError && submitted ? (
          <ErrorState
            error={queryError}
            onRetry={() => refetch()}
            title={queryError instanceof Error && /یافت نشد/.test(queryError.message) ? 'سفارشی با این شماره یافت نشد' : 'خطا در پیگیری سفارش'}
          />
        ) : data ? (
          <div className="rounded-xl border bg-card p-5 shadow-soft sm:p-6" aria-live="polite">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs text-muted-foreground">شماره سفارش</p>
                <p className="text-lg font-extrabold tracking-wide" dir="ltr" style={{ textAlign: 'right' }}>{data.orderNumber}</p>
              </div>
              <span className={`rounded-full border px-3 py-1 text-xs font-bold ${ORDER_STATUS_COLORS[data.status] ?? 'bg-secondary'}`}>
                {data.statusFa ?? data.status}
              </span>
            </div>
            <Separator className="my-4" />
            {data.shippingInfo && (
              <div className="mb-4 grid gap-2 text-sm sm:grid-cols-2">
                <p>
                  <span className="text-muted-foreground">گیرنده: </span>
                  {data.shippingInfo.recipientName ?? '—'}
                </p>
                <p>
                  <span className="text-muted-foreground">مقصد: </span>
                  {data.shippingInfo.province}، {data.shippingInfo.city}
                </p>
              </div>
            )}
            {data.tracking?.code && (
              <p className="mb-4 rounded-lg bg-forest-50 p-3 text-sm">
                کد رهگیری پستی: <span className="font-bold" dir="ltr">{faNum(data.tracking.code)}</span>
              </p>
            )}
            <h2 className="mb-3 text-sm font-bold">روند سفارش</h2>
            <ol className="relative flex flex-col gap-4 ps-5">
              {data.timeline?.map((t, i) => (
                <li key={i} className="relative">
                  <span className="absolute -start-5 top-1 size-2.5 rounded-full bg-forest-600" aria-hidden />
                  {i < (data.timeline?.length ?? 0) - 1 && (
                    <span className="absolute -start-[17px] top-4 h-full w-px bg-border" aria-hidden />
                  )}
                  <p className="text-sm font-semibold">{t.status}</p>
                  <p className="text-xs text-muted-foreground">{faDateTime(t.date)}</p>
                  {t.description && <p className="mt-1 text-sm leading-6 text-foreground/85">{t.description}</p>}
                </li>
              ))}
            </ol>
          </div>
        ) : (
          <EmptyState title="هنوز سفارشی پیگیری نشده" description="فرم بالا را تکمیل کنید تا وضعیت سفارش نمایش داده شود." className="border-0 bg-transparent" />
        )}
      </div>
    </div>
  )
}
