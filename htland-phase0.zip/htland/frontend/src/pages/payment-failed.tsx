/* Payment failed page — backend redirect target for failed/cancelled payments */
import { Link, useSearchParams } from 'react-router-dom'
import { motion } from 'motion/react'
import { XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function PaymentFailed() {
  const [params] = useSearchParams()
  const reason = params.get('error')
  return (
    <div className="container-page flex min-h-[65dvh] items-center justify-center py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.35 }}
        className="w-full max-w-lg rounded-2xl border bg-card p-8 text-center shadow-soft"
      >
        <div className="mx-auto mb-5 flex size-16 items-center justify-center rounded-full bg-destructive/10 text-destructive">
          <XCircle className="size-9" aria-hidden />
        </div>
        <h1 className="text-xl font-extrabold">پرداخت ناموفق بود</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">
          پرداخت شما تکمیل نشد یا لغو شد. اگر مبلغ از حساب شما کسر شده باشد، طی ۷۲ ساعت کاری به حساب بازمی‌گردد.
        </p>
        {reason && (
          <p className="mt-4 rounded-lg bg-destructive/5 p-3 text-xs leading-6 text-destructive" dir="auto">
            {reason}
          </p>
        )}
        <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
          <Link to="/cart">
            <Button className="w-full sm:w-auto">بازگشت به سبد خرید</Button>
          </Link>
          <Link to="/track">
            <Button variant="outline" className="w-full sm:w-auto">
              پیگیری سفارش
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  )
}
