/* Catalog — URL-driven filters, debounced search, real pagination */
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { keepPreviousData, useQuery } from '@tanstack/react-query'
import { ChevronLeft, ChevronRight, Filter, SearchX, SlidersHorizontal, X } from 'lucide-react'
import { productsApi } from '@/api'
import { ProductCard, ProductCardSkeleton } from '@/components/product-card'
import { EmptyState, ErrorState } from '@/components/states'
import { Button } from '@/components/ui/button'
import { Input, Select } from '@/components/ui/input'
import { CATEGORIES, CATEGORY_ORDER, cn, faNum, toman } from '@/lib/format'

const SORTS = [
  { value: '-createdAt', label: 'جدیدترین' },
  { value: 'price', label: 'ارزان‌ترین' },
  { value: '-price', label: 'گران‌ترین' },
  { value: '-rating', label: 'بیشترین امتیاز' },
]

const PRICE_RANGES = [
  { label: 'تا ۲۰۰ هزار تومان', min: undefined, max: 200000 },
  { label: '۲۰۰ تا ۵۰۰ هزار تومان', min: 200000, max: 500000 },
  { label: '۵۰۰ هزار تا ۱ میلیون تومان', min: 500000, max: 1000000 },
  { label: 'بیش از ۱ میلیون تومان', min: 1000000, max: undefined },
]

export default function Products() {
  const [params, setParams] = useSearchParams()
  const [searchInput, setSearchInput] = useState(params.get('search') ?? '')
  const [showFilters, setShowFilters] = useState(false)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const page = Number(params.get('page') ?? '1') || 1
  const category = params.get('category') ?? undefined
  const search = params.get('search') ?? undefined
  const minPrice = params.get('minPrice') ? Number(params.get('minPrice')) : undefined
  const maxPrice = params.get('maxPrice') ? Number(params.get('maxPrice')) : undefined
  const inStock = params.get('inStock') === 'true' ? true : undefined
  const featured = params.get('featured') === 'true' ? true : undefined
  const sort = params.get('sort') ?? '-createdAt'

  const patchParams = (patch: Record<string, string | number | undefined | null>) => {
    setParams(
      (prev) => {
        const next = new URLSearchParams(prev)
        Object.entries(patch).forEach(([k, v]) => {
          if (v === undefined || v === null || v === '') next.delete(k)
          else next.set(k, String(v))
        })
        if (!('page' in patch)) next.delete('page')
        return next
      },
      { replace: true }
    )
  }

  /* debounced search syncs to URL */
  const onSearchChange = (v: string) => {
    setSearchInput(v)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      patchParams({ search: v.trim() || undefined })
    }, 450)
  }
  useEffect(() => () => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
  }, [])

  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ['products', { page, category, search, minPrice, maxPrice, inStock, featured, sort }],
    queryFn: ({ signal }) =>
      productsApi.list({ page, limit: 12, category, search, minPrice, maxPrice, inStock, featured, sort }, signal),
    placeholderData: keepPreviousData,
  })

  const { data: stats } = useQuery({ queryKey: ['category-stats'], queryFn: () => productsApi.categoryStats() })

  const activeFilters = useMemo(() => {
    const f: string[] = []
    if (category) f.push(CATEGORIES[category]?.fa ?? category)
    if (search) f.push(`«${search}»`)
    if (minPrice || maxPrice) f.push(`${minPrice ? toman(minPrice) : '۰'} تا ${maxPrice ? toman(maxPrice) : 'بی‌نهایت'}`)
    if (inStock) f.push('فقط موجود')
    if (featured) f.push('ویژه')
    return f
  }, [category, search, minPrice, maxPrice, inStock, featured])

  const products = data?.data ?? []
  const pagination = data?.pagination

  const FilterPanel = (
    <div className="flex flex-col gap-6">
      {/* categories */}
      <div>
        <h3 className="mb-3 text-sm font-bold">دسته‌بندی</h3>
        <div className="flex flex-col gap-1">
          <button
            className={cn(
              'flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors cursor-pointer',
              !category ? 'bg-forest-800 text-ivory' : 'hover:bg-forest-50'
            )}
            onClick={() => patchParams({ category: undefined })}
          >
            همه محصولات
          </button>
          {CATEGORY_ORDER.map((key) => {
            const stat = stats?.find((s) => s._id === key)
            return (
              <button
                key={key}
                className={cn(
                  'flex items-center justify-between rounded-lg px-3 py-2 text-sm transition-colors cursor-pointer',
                  category === key ? 'bg-forest-800 text-ivory' : 'hover:bg-forest-50'
                )}
                onClick={() => patchParams({ category: key })}
              >
                <span>{CATEGORIES[key].fa}</span>
                {stat && <span className={cn('text-[11px]', category === key ? 'text-ivory/70' : 'text-muted-foreground')}>{faNum(stat.count)}</span>}
              </button>
            )
          })}
        </div>
      </div>

      {/* price ranges */}
      <div>
        <h3 className="mb-3 text-sm font-bold">محدوده قیمت</h3>
        <div className="flex flex-wrap gap-2">
          {PRICE_RANGES.map((r) => {
            const active = minPrice === r.min && maxPrice === r.max
            return (
              <button
                key={r.label}
                className={cn(
                  'rounded-full border px-3 py-1.5 text-xs transition-colors cursor-pointer',
                  active ? 'border-forest-800 bg-forest-800 text-ivory' : 'border-input bg-card hover:bg-forest-50'
                )}
                onClick={() => patchParams({ minPrice: active ? undefined : r.min, maxPrice: active ? undefined : r.max })}
              >
                {r.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* stock & featured */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-bold">وضعیت</h3>
        <label className="flex cursor-pointer items-center gap-2.5 text-sm">
          <input
            type="checkbox"
            checked={!!inStock}
            onChange={(e) => patchParams({ inStock: e.target.checked ? 'true' : undefined })}
            className="size-4 accent-forest-800"
          />
          فقط کالاهای موجود
        </label>
        <label className="flex cursor-pointer items-center gap-2.5 text-sm">
          <input
            type="checkbox"
            checked={!!featured}
            onChange={(e) => patchParams({ featured: e.target.checked ? 'true' : undefined })}
            className="size-4 accent-forest-800"
          />
          محصولات ویژه
        </label>
      </div>

      {activeFilters.length > 0 && (
        <Button
          variant="ghost"
          size="sm"
          className="w-fit text-destructive hover:text-destructive"
          onClick={() => setParams({}, { replace: true })}
        >
          <X className="size-4" />
          حذف همه فیلترها
        </Button>
      )}
    </div>
  )

  return (
    <div className="container-page py-8">
      {/* breadcrumb */}
      <nav aria-label="مسیر" className="mb-5 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-forest-700">
          خانه
        </Link>
        <span className="mx-1.5" aria-hidden>
          /
        </span>
        <span className="font-medium text-foreground">فروشگاه</span>
        {category && (
          <>
            <span className="mx-1.5" aria-hidden>
              /
            </span>
            <span className="font-medium text-foreground">{CATEGORIES[category]?.fa}</span>
          </>
        )}
      </nav>

      <div className="mb-6 flex flex-col gap-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-xl font-extrabold sm:text-2xl">
            {category ? CATEGORIES[category]?.fa : 'همه محصولات'}
          </h1>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setShowFilters(true)}>
              <SlidersHorizontal className="size-4" />
              فیلترها
              {activeFilters.length > 0 && (
                <span className="flex size-5 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-accent-foreground">
                  {faNum(activeFilters.length)}
                </span>
              )}
            </Button>
            <Select
              value={sort}
              onChange={(e) => patchParams({ sort: e.target.value })}
              className="w-44"
              aria-label="مرتب‌سازی"
            >
              {SORTS.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </Select>
          </div>
        </div>

        <div className="relative">
          <input
            type="search"
            value={searchInput}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="جستجو در محصولات… (مثلاً عسل، قزل‌آلا، هاشمی)"
            aria-label="جستجوی محصولات"
            className="h-11 w-full rounded-xl border border-input bg-card ps-10 pe-4 text-sm shadow-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
          <Filter className="pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted-foreground" aria-live="polite">
            {pagination ? `${faNum(pagination.total)} محصول یافت شد` : isFetching ? 'در حال دریافت…' : ''}
          </span>
          {activeFilters.map((f) => (
            <span key={f} className="rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-secondary-foreground">
              {f}
            </span>
          ))}
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="hidden lg:block" aria-label="فیلترها">
          <div className="sticky top-32 rounded-xl border bg-card p-5">{FilterPanel}</div>
        </aside>

        <section aria-label="نتایج محصولات">
          {error ? (
            <ErrorState error={error} onRetry={refetch} />
          ) : isLoading ? (
            <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          ) : products.length === 0 ? (
            <EmptyState
              icon={<SearchX className="size-7" aria-hidden />}
              title="محصولی یافت نشد"
              description="با این فیلترها محصولی نداریم. فیلترها را تغییر دهید یا عبارت دیگری جستجو کنید."
              action={
                <Button variant="outline" onClick={() => setParams({}, { replace: true })}>
                  حذف فیلترها
                </Button>
              }
            />
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-3">
                {products.map((p) => (
                  <ProductCard key={p._id} product={p} />
                ))}
              </div>

              {pagination && pagination.pages > 1 && (
                <nav className="mt-10 flex items-center justify-center gap-2" aria-label="صفحه‌بندی">
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={!pagination.hasPrev || isFetching}
                    onClick={() => patchParams({ page: page - 1 })}
                    aria-label="صفحه قبل"
                  >
                    <ChevronRight className="size-4" aria-hidden />
                  </Button>
                  {Array.from({ length: pagination.pages }, (_, i) => i + 1)
                    .filter((p) => p === 1 || p === pagination.pages || Math.abs(p - page) <= 1)
                    .map((p, idx, arr) => (
                      <span key={p} className="flex items-center gap-2">
                        {idx > 0 && arr[idx - 1] !== p - 1 && <span className="text-muted-foreground">…</span>}
                        <Button
                          variant={p === page ? 'default' : 'outline'}
                          size="icon"
                          onClick={() => patchParams({ page: p })}
                          aria-current={p === page ? 'page' : undefined}
                          aria-label={`صفحه ${faNum(p)}`}
                        >
                          {faNum(p)}
                        </Button>
                      </span>
                    ))}
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={!pagination.hasNext || isFetching}
                    onClick={() => patchParams({ page: page + 1 })}
                    aria-label="صفحه بعد"
                  >
                    <ChevronLeft className="size-4" aria-hidden />
                  </Button>
                </nav>
              )}
            </>
          )}
        </section>
      </div>

      {/* mobile filters drawer */}
      {showFilters && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="فیلترها">
          <div className="absolute inset-0 bg-forest-950/45" onClick={() => setShowFilters(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[82dvh] overflow-y-auto rounded-t-2xl bg-card p-5 pb-8 shadow-lift">
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-forest-100" aria-hidden />
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-bold">فیلترها</h2>
              <button onClick={() => setShowFilters(false)} aria-label="بستن فیلترها" className="rounded-md p-1 hover:bg-forest-50 cursor-pointer">
                <X className="size-5" />
              </button>
            </div>
            {FilterPanel}
            <Button className="mt-6 w-full" onClick={() => setShowFilters(false)}>
              مشاهده نتایج
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
