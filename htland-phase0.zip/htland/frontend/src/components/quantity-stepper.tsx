import { Minus, Plus } from 'lucide-react'
import { cn } from '@/lib/format'
import { Button } from '@/components/ui/button'

export function QuantityStepper({
  value,
  onChange,
  min = 1,
  max = 99,
  disabled = false,
  size = 'md',
  ariaLabel = 'تغییر تعداد',
}: {
  value: number
  onChange: (v: number) => void
  min?: number
  max?: number
  disabled?: boolean
  size?: 'sm' | 'md'
  ariaLabel?: string
}) {
  const btn = size === 'sm' ? 'h-8 w-8' : 'h-9 w-9'
  return (
    <div
      className={cn('inline-flex items-center rounded-lg border border-input bg-card', disabled && 'opacity-60')}
      role="group"
      aria-label={ariaLabel}
    >
      <Button
        type="button"
        variant="ghost"
        size="icon-sm"
        className={cn(btn, 'rounded-none rounded-s-lg')}
        onClick={() => onChange(Math.max(min, value - 1))}
        disabled={disabled || value <= min}
        aria-label="کاهش تعداد"
      >
        <Minus />
      </Button>
      <span
        className={cn('min-w-9 text-center font-bold tabular-nums select-none', size === 'sm' ? 'text-sm py-1' : 'py-1.5')}
        aria-live="polite"
        aria-label={`تعداد: ${value}`}
      >
        {new Intl.NumberFormat('fa-IR').format(value)}
      </span>
      <Button
        type="button"
        variant="ghost"
        size="icon-sm"
        className={cn(btn, 'rounded-none rounded-e-lg')}
        onClick={() => onChange(Math.min(max, value + 1))}
        disabled={disabled || value >= max}
        aria-label="افزایش تعداد"
      >
        <Plus />
      </Button>
    </div>
  )
}
