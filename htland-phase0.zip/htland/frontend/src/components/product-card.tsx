/* Art-directed product card — only truthful backend data */
import { Link } from 'react-router-dom'
import { ShoppingBasket, MapPin } from 'lucide-react'
import type { Product } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DiscountBadge, Price } from '@/components/price'
import { useAddToCart } from '@/hooks/useAddToCart'
import { faNum } from '@/lib/format'
import { cn } from '@/lib/format'

export function ProductCard({ product, className }: { product: Product; className?: string }) {
  const { addToCart, pendingId } = useAddToCart()
  const pending = pendingId === product._id
  const outOfStock = !product.inStock || product.stock <= 0

  return (
    <article
      className={cn(
        'group relative flex flex-col overflow-hidden rounded-xl border bg-card shadow-soft transition-all duration-300',
        'hover:-translate-y-1 hover:shadow-lift focus-within:ring-2 focus-within:ring-ring',
        className
      )}
    >
      <Link
        to={`/products/${product.slug}`}
        className="relative block aspect-square overflow-hidden bg-ivory-2"
        aria-label={`مشاهده ${product.name}`}
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={800}
          height={800}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
          onError={(e) => {
            ;(e.target as HTMLImageElement).src = '/images/brand/cat-rice.svg'
          }}
        />
        <div className="absolute inset-x-0 top-0 flex flex-wrap items-start justify-between gap-1 p-2.5">
          {outOfStock ? (
            <Badge variant="danger">ناموجود</Badge>
          ) : product.stock <= 5 ? (
            <Badge variant="warning" className="bg-saffron-50/95">
              {faNum(product.stock)} عدد باقی مانده
            </Badge>
          ) : (
            <span />
          )}
          <DiscountBadge price={product.price} discountPrice={product.discountPrice} />
        </div>
      </Link>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-medium text-forest-600">{product.categoryFa}</span>
          {product.metadata?.origin && (
            <span className="flex items-center gap-0.5 text-[11px] text-muted-foreground">
              <MapPin className="size-3" aria-hidden />
              {product.metadata.origin}
            </span>
          )}
        </div>
        <h3 className="font-semibold leading-6">
          <Link to={`/products/${product.slug}`} className="transition-colors hover:text-forest-600 line-clamp-1">
            {product.name}
          </Link>
        </h3>
        <div className="mt-auto flex items-end justify-between gap-2 pt-1">
          <Price price={product.price} discountPrice={product.discountPrice} size="md" />
          <Button
            size="icon"
            aria-label={`افزودن ${product.name} به سبد خرید`}
            disabled={outOfStock || pending}
            loading={pending}
            onClick={() => addToCart(product)}
            className="shrink-0 rounded-lg"
          >
            {!pending && <ShoppingBasket aria-hidden />}
          </Button>
        </div>
      </div>
    </article>
  )
}

export function ProductCardSkeleton() {
  return (
    <div className="flex flex-col overflow-hidden rounded-xl border bg-card shadow-soft">
      <div className="skeleton aspect-square rounded-none" />
      <div className="flex flex-col gap-2.5 p-4">
        <div className="skeleton h-3 w-16" />
        <div className="skeleton h-5 w-3/4" />
        <div className="flex items-center justify-between pt-1">
          <div className="skeleton h-6 w-24" />
          <div className="skeleton size-10 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
