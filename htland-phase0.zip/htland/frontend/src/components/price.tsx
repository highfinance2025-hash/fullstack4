/* Price display with optional discount presentation (all real backend data) */
import { cn, discountPercent, faNum, toman } from '@/lib/format'

export function Price({
  price,
  discountPrice,
  size = 'md',
  className,
}: {
  price: number
  discountPrice?: number | null
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  const hasDiscount = !!discountPrice && discountPrice < price
  const sizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
    xl: 'text-2xl',
  } as const
  return (
    <div className={cn('flex flex-wrap items-baseline gap-x-2 gap-y-0.5', className)}>
      <span className={cn('font-bold text-forest-800', sizes[size])} aria-label={`قیمت: ${toman(hasDiscount ? discountPrice! : price)}`}>
        {faNum(hasDiscount ? discountPrice! : price)}
        <span className="text-[0.68em] font-medium text-muted-foreground ms-1">تومان</span>
      </span>
      {hasDiscount && (
        <span className={cn('text-muted-foreground/80 line-through decoration-destructive/50', size === 'xl' ? 'text-sm' : 'text-xs')}>
          {faNum(price)}
        </span>
      )}
    </div>
  )
}

export function DiscountBadge({ price, discountPrice }: { price: number; discountPrice?: number | null }) {
  const pct = discountPercent(price, discountPrice)
  if (!pct) return null
  return (
    <span className="rounded-full bg-destructive px-2 py-0.5 text-[11px] font-bold text-destructive-foreground">
      ٪{faNum(pct)} تخفیف
    </span>
  )
}
