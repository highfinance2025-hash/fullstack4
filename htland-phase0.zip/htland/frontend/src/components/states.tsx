import type { ReactNode } from 'react'
import { AlertTriangle, PackageOpen, WifiOff } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ApiError } from '@/lib/api'

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode
  title: string
  description?: string
  action?: ReactNode
  className?: string
}) {
  return (
    <div className={`flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed bg-card/60 px-6 py-14 text-center ${className ?? ''}`}>
      <div className="flex size-14 items-center justify-center rounded-full bg-forest-50 text-forest-600">
        {icon ?? <PackageOpen className="size-7" aria-hidden />}
      </div>
      <h3 className="text-base font-bold">{title}</h3>
      {description && <p className="max-w-sm text-sm leading-6 text-muted-foreground">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  )
}

export function ErrorState({
  error,
  onRetry,
  title = 'خطا در دریافت اطلاعات',
  className,
}: {
  error: unknown
  onRetry?: () => void
  title?: string
  className?: string
}) {
  const offline = error instanceof ApiError && error.status === 0
  return (
    <div
      role="alert"
      className={`flex flex-col items-center justify-center gap-3 rounded-xl border bg-card px-6 py-14 text-center ${className ?? ''}`}
    >
      <div className="flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
        {offline ? <WifiOff className="size-7" aria-hidden /> : <AlertTriangle className="size-7" aria-hidden />}
      </div>
      <h3 className="text-base font-bold">{offline ? 'اتصال برقرار نشد' : title}</h3>
      <p className="max-w-sm text-sm leading-6 text-muted-foreground">
        {error instanceof Error ? error.message : 'مشکلی پیش آمده است؛ دوباره تلاش کنید.'}
      </p>
      {onRetry && (
        <Button variant="outline" onClick={onRetry} className="mt-1">
          تلاش مجدد
        </Button>
      )}
    </div>
  )
}
