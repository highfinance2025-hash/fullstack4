import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, useNavigate, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { AnimatePresence, motion } from 'motion/react'
import {
  ChevronDown,
  LayoutGrid,
  LogOut,
  MapPinned,
  Menu,
  Package,
  Search,
  ShoppingBasket,
  UserRound,
  Wallet,
  X,
} from 'lucide-react'
import { cartApi } from '@/api'
import { useAuth } from '@/hooks/useAuth'
import { useGuestCart } from '@/hooks/useGuestCart'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, SheetContent, DialogTitle } from '@/components/ui/dialog'
import { CATEGORIES, cn, faNum } from '@/lib/format'

function SearchForm({ onDone, autoFocus = false }: { onDone?: () => void; autoFocus?: boolean }) {
  const [params] = useSearchParams()
  const [q, setQ] = useState(params.get('search') ?? '')
  const navigate = useNavigate()
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const query = q.trim()
    navigate(query ? `/products?search=${encodeURIComponent(query)}` : '/products')
    onDone?.()
  }
  return (
    <form role="search" onSubmit={submit} className="flex w-full items-center gap-2">
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="جستجوی محصولات… مثلاً برنج هاشمی"
          aria-label="جستجوی محصولات"
          autoFocus={autoFocus}
          className="h-10 w-full rounded-lg border border-input bg-card ps-9 pe-3 text-sm shadow-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
      </div>
      <Button type="submit" size="sm" className="h-10 px-4">
        جستجو
      </Button>
    </form>
  )
}

export function Header() {
  const { user, logout } = useAuth()
  const guest = useGuestCart()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  const { data: serverCart } = useQuery({
    queryKey: ['cart'],
    queryFn: () => cartApi.get(),
    enabled: !!user,
    staleTime: 30_000,
    retry: 1,
  })

  const count = user ? serverCart?.totalItems ?? 0 : guest.count

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  const navLink = ({ isActive }: { isActive: boolean }) =>
    cn(
      'rounded-lg px-3 py-2 text-sm font-medium transition-colors',
      isActive ? 'bg-forest-50 text-forest-800' : 'text-foreground/80 hover:text-forest-700 hover:bg-forest-50/60'
    )

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-[60] focus:bg-primary focus:text-primary-foreground focus:px-4 focus:py-2 focus:rounded-lg focus:top-2 focus:start-2"
      >
        پرش به محتوای اصلی
      </a>
      <header className="sticky top-0 z-40 border-b border-border/80 bg-ivory/90 backdrop-blur supports-[backdrop-filter]:bg-ivory/75">
        {/* announcement — real business info only */}
        <div className="bg-forest-800 text-ivory">
          <div className="container-page flex h-9 items-center justify-center gap-2 text-[12px] sm:text-xs">
            <MapPinned className="size-3.5 shrink-0 text-saffron-400" aria-hidden />
            <span className="truncate">ارسال مستقیم از شمال ایران — تازه از مبدأ تا سفره شما</span>
          </div>
        </div>

        <div className="container-page flex h-16 items-center gap-3">
          {/* mobile menu */}
          <button
            className="inline-flex size-10 items-center justify-center rounded-lg hover:bg-forest-50 lg:hidden cursor-pointer"
            onClick={() => setMobileOpen(true)}
            aria-label="باز کردن منو"
          >
            <Menu className="size-5" />
          </button>

          <Link to="/" className="flex items-center gap-2.5" aria-label="اچ‌تی‌لند — صفحه اصلی">
            <img src="/images/brand/logo.svg" alt="" width={38} height={38} className="rounded-full" />
            <span className="flex flex-col leading-tight">
              <span className="text-lg font-extrabold text-forest-800">اچ‌تی‌لند</span>
              <span className="hidden text-[10px] text-muted-foreground sm:block">طعم اصیل شمال ایران</span>
            </span>
          </Link>

          <nav className="mx-4 hidden items-center gap-1 lg:flex" aria-label="ناوبری اصلی">
            <NavLink to="/" end className={navLink}>
              خانه
            </NavLink>
            <NavLink to="/products" end className={navLink}>
              فروشگاه
            </NavLink>
            <div className="relative" ref={menuRef}>
              <button
                className="flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-forest-50/60 hover:text-forest-700 cursor-pointer"
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-haspopup="true"
              >
                دسته‌بندی‌ها
                <ChevronDown className={cn('size-4 transition-transform', menuOpen && 'rotate-180')} aria-hidden />
              </button>
              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 6 }}
                    transition={{ duration: 0.15 }}
                    className="absolute start-0 top-full z-50 mt-1 w-56 rounded-xl border bg-card p-1.5 shadow-lift"
                    role="menu"
                  >
                    {Object.entries(CATEGORIES).map(([key, c]) => (
                      <Link
                        key={key}
                        to={`/products?category=${key}`}
                        role="menuitem"
                        className="flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm hover:bg-forest-50"
                        onClick={() => setMenuOpen(false)}
                      >
                        <img src={c.icon} alt="" className="size-9 rounded-md object-cover" />
                        {c.fa}
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <NavLink to="/track" className={navLink}>
              پیگیری سفارش
            </NavLink>
          </nav>

          <div className="ms-auto flex items-center gap-1.5">
            <button
              className="inline-flex size-10 items-center justify-center rounded-lg hover:bg-forest-50 cursor-pointer"
              onClick={() => setSearchOpen(true)}
              aria-label="جستجو"
            >
              <Search className="size-5" />
            </button>

            <Link
              to="/cart"
              className="relative inline-flex size-10 items-center justify-center rounded-lg hover:bg-forest-50"
              aria-label={`سبد خرید${count ? ` — ${faNum(count)} کالا` : ''}`}
            >
              <ShoppingBasket className="size-5" />
              {count > 0 && (
                <span className="absolute -top-0.5 -end-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
                  {faNum(count)}
                </span>
              )}
            </Link>

            {user ? (
              <div className="relative hidden sm:block" ref={undefined}>
                <Link to="/account">
                  <Button variant="outline" size="sm" className="gap-2">
                    <UserRound className="size-4" aria-hidden />
                    <span className="max-w-24 truncate">{user.fullName || 'حساب من'}</span>
                  </Button>
                </Link>
              </div>
            ) : (
              <Link to="/login" className="hidden sm:block">
                <Button size="sm">ورود | ثبت‌نام</Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* search overlay */}
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent hideClose className="top-24 translate-y-0 max-w-xl gap-2" aria-describedby={undefined}>
          <DialogTitle className="sr-only">جستجوی محصولات</DialogTitle>
          <SearchForm autoFocus onDone={() => setSearchOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* mobile drawer */}
      <Dialog open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent aria-describedby={undefined} className="p-0">
          <DialogTitle className="sr-only">منوی ناوبری</DialogTitle>
          <div className="flex flex-col">
            <div className="border-b p-4">
              <SearchForm onDone={() => setMobileOpen(false)} />
            </div>
            <nav className="flex flex-col p-3" aria-label="ناوبری موبایل">
              <Link to="/" className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-forest-50" onClick={() => setMobileOpen(false)}>
                خانه
              </Link>
              <Link to="/products" className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-forest-50" onClick={() => setMobileOpen(false)}>
                فروشگاه
              </Link>
              <Link to="/track" className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-forest-50" onClick={() => setMobileOpen(false)}>
                پیگیری سفارش
              </Link>
            </nav>
            <div className="px-4 pb-2">
              <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                <LayoutGrid className="size-3.5" aria-hidden /> دسته‌بندی‌ها
              </p>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(CATEGORIES).map(([key, c]) => (
                  <Link
                    key={key}
                    to={`/products?category=${key}`}
                    className="flex items-center gap-2 rounded-lg border p-2 text-xs font-medium hover:bg-forest-50"
                    onClick={() => setMobileOpen(false)}
                  >
                    <img src={c.icon} alt="" className="size-8 rounded-md object-cover" />
                    {c.fa}
                  </Link>
                ))}
              </div>
            </div>
            <div className="mt-auto border-t p-4">
              {user ? (
                <div className="flex flex-col gap-2">
                  <Link to="/account" onClick={() => setMobileOpen(false)}>
                    <Button className="w-full" variant="outline">
                      <UserRound className="size-4" /> حساب من
                    </Button>
                  </Link>
                  <Link to="/account/wallet" onClick={() => setMobileOpen(false)}>
                    <Button className="w-full" variant="outline">
                      <Wallet className="size-4" /> کیف پول
                    </Button>
                  </Link>
                  <Link to="/account/orders" onClick={() => setMobileOpen(false)}>
                    <Button className="w-full" variant="outline">
                      <Package className="size-4" /> سفارش‌های من
                    </Button>
                  </Link>
                  <Button
                    className="w-full"
                    variant="ghost"
                    onClick={async () => {
                      setMobileOpen(false)
                      await logout()
                      navigate('/')
                    }}
                  >
                    <LogOut className="size-4" /> خروج از حساب
                  </Button>
                </div>
              ) : (
                <Link to="/login" onClick={() => setMobileOpen(false)} className="block">
                  <Button className="w-full">ورود | ثبت‌نام</Button>
                </Link>
              )}
            </div>
          </div>
        </SheetContent>
      </Dialog>
    </>
  )
}
