import { Link } from 'react-router-dom'
import { MapPinned, ShieldCheck, Sprout } from 'lucide-react'
import { CATEGORIES } from '@/lib/format'

export function Footer() {
  return (
    <footer className="mt-auto border-t bg-forest-900 text-ivory/90">
      <div className="container-page grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div className="flex flex-col gap-4">
          <Link to="/" className="flex items-center gap-2.5">
            <img src="/images/brand/logo.svg" alt="" width={40} height={40} className="rounded-full" />
            <span className="text-lg font-extrabold text-ivory">اچ‌تی‌لند</span>
          </Link>
          <p className="text-sm leading-7 text-ivory/70">
            فروشگاه آنلاین محصولات اصیل شمال ایران؛ از شالیزارهای مازندران و تالاب‌های گیلان تا کندوهای کوهستان — تازه از مبدأ تا سفره شما.
          </p>
          <div className="flex flex-col gap-2 text-sm text-ivory/80">
            <span className="flex items-center gap-2">
              <MapPinned className="size-4 text-saffron-400" aria-hidden /> ارسال سراسری با بسته‌بندی سرد
            </span>
            <span className="flex items-center gap-2">
              <ShieldCheck className="size-4 text-saffron-400" aria-hidden /> پرداخت امن و تضمین اصالت کالا
            </span>
            <span className="flex items-center gap-2">
              <Sprout className="size-4 text-saffron-400" aria-hidden /> همکاری مستقیم با کشاورزان شمال
            </span>
          </div>
        </div>

        <nav aria-label="دسته‌بندی‌ها">
          <h3 className="mb-4 text-sm font-bold text-saffron-400">دسته‌بندی محصولات</h3>
          <ul className="flex flex-col gap-2.5 text-sm">
            {Object.entries(CATEGORIES).map(([key, c]) => (
              <li key={key}>
                <Link to={`/products?category=${key}`} className="text-ivory/80 transition-colors hover:text-ivory">
                  {c.fa}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="دسترسی سریع">
          <h3 className="mb-4 text-sm font-bold text-saffron-400">دسترسی سریع</h3>
          <ul className="flex flex-col gap-2.5 text-sm">
            <li>
              <Link to="/products" className="text-ivory/80 transition-colors hover:text-ivory">
                فروشگاه
              </Link>
            </li>
            <li>
              <Link to="/track" className="text-ivory/80 transition-colors hover:text-ivory">
                پیگیری سفارش
              </Link>
            </li>
            <li>
              <Link to="/account/orders" className="text-ivory/80 transition-colors hover:text-ivory">
                سفارش‌های من
              </Link>
            </li>
            <li>
              <Link to="/account/wallet" className="text-ivory/80 transition-colors hover:text-ivory">
                کیف پول
              </Link>
            </li>
          </ul>
        </nav>

        <div>
          <h3 className="mb-4 text-sm font-bold text-saffron-400">خرید مطمئن</h3>
          <ul className="flex flex-col gap-3 text-sm text-ivory/75 leading-6">
            <li>زنجیره سرد برای محصولات پروتئینی و خاویار</li>
            <li>بسته‌بندی بهداشتی و استاندارد برای ارسال</li>
            <li>پرداخت امن از طریق درگاه بانکی یا کیف پول</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <div className="container-page flex flex-col items-center justify-between gap-2 py-4 text-xs text-ivory/60 sm:flex-row">
          <span>© اچ‌تی‌لند — فروشگاه محصولات شمال ایران</span>
          <span>کلیه قیمت‌ها به تومان و بر اساس موجودی انبار به‌روزرسانی می‌شود</span>
        </div>
      </div>
    </footer>
  )
}
