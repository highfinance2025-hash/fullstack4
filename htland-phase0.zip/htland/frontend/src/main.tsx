import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'sonner'
import App from './App'
import { AuthProvider } from '@/hooks/useAuth'
import { GuestCartProvider } from '@/hooks/useGuestCart'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: (failureCount, error: any) => {
        // don't retry 4xx client errors
        if (error?.status && error.status >= 400 && error.status < 500) return false
        return failureCount < 2
      },
      staleTime: 30_000,
    },
  },
})

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider>
          <GuestCartProvider>
            <App />
            <Toaster
              position="top-center"
              dir="rtl"
              toastOptions={{
                style: { fontFamily: 'Vazirmatn, sans-serif', direction: 'rtl' },
              }}
            />
          </GuestCartProvider>
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </StrictMode>
)

/* PWA — register the minimal SPA-safe service worker in production builds only */
if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch(() => {
      /* PWA is best-effort; app works without it */
    })
  })
}
