/* Centralized API client — normalizes envelopes, errors, auth headers.
   Same-origin requests only (backend serves this app). */

export class ApiError extends Error {
  code: string
  status: number
  details?: unknown

  constructor(message: string, status: number, code = 'ERROR', details?: unknown) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.details = details
  }
}

const TOKEN_KEY = 'htland.token'

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY)
  } catch {
    return null
  }
}

export function setToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token)
    else localStorage.removeItem(TOKEN_KEY)
  } catch {
    /* ignore */
  }
}

/* Extract a human-readable Persian message from the backend's varying error shapes:
   { error: { message } } | { message } | { errors: [{field, message}] } | { error: string } */
function extractMessage(payload: any, fallback: string): { message: string; details?: unknown } {
  if (!payload) return { message: fallback }
  if (payload.error && typeof payload.error === 'object' && payload.error.message)
    return { message: payload.error.message, details: payload.error.details }
  if (typeof payload.error === 'string') return { message: payload.error }
  if (Array.isArray(payload.errors) && payload.errors.length > 0) {
    const first = payload.errors[0]
    const msg = typeof first === 'string' ? first : first?.message
    if (msg) return { message: String(msg), details: payload.errors }
  }
  if (payload.message) return { message: payload.message }
  return { message: fallback }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  body?: unknown
  auth?: boolean // attach token if present
  signal?: AbortSignal
}

export async function api<T = any>(path: string, opts: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, auth = true, signal } = opts

  const headers: Record<string, string> = {
    Accept: 'application/json',
  }
  if (body !== undefined) headers['Content-Type'] = 'application/json'

  if (auth) {
    const token = getToken()
    if (token) headers['Authorization'] = `Bearer ${token}`
  }

  let res: Response
  try {
    res = await fetch(path, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
      credentials: 'same-origin',
    })
  } catch (e: any) {
    if (e?.name === 'AbortError') throw e
    throw new ApiError('خطا در برقراری ارتباط با سرور؛ اتصال اینترنت خود را بررسی کنید.', 0, 'NETWORK_ERROR')
  }

  // 204 / empty body
  if (res.status === 204) return undefined as T

  let payload: any = null
  try {
    payload = await res.json()
  } catch {
    /* non-JSON response */
  }

  if (!res.ok) {
    const { message, details } = extractMessage(payload, 'خطایی رخ داده است؛ دوباره تلاش کنید.')
    // normalize auth errors
    if (res.status === 401) {
      const code = payload?.error?.code ?? 'UNAUTHORIZED'
      throw new ApiError(message || 'لطفاً برای ادامه وارد حساب خود شوید.', 401, code, details)
    }
    throw new ApiError(message, res.status, payload?.error?.code ?? `HTTP_${res.status}`, details)
  }

  return payload as T
}

/* Unwrap { success, data, ... } envelopes */
export async function apiData<T = any>(path: string, opts: RequestOptions = {}): Promise<T> {
  const res = await api<{ data: T }>(path, opts)
  return (res as any)?.data !== undefined ? (res.data as T) : (res as unknown as T)
}
