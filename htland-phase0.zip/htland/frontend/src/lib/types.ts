/* Typed models matching HTLand backend responses */

export interface Pagination {
  total: number
  limit: number
  page: number
  pages: number
  hasNext: boolean
  hasPrev: boolean
}

export interface Product {
  _id: string
  name: string
  slug: string
  description: string
  price: number
  discountPrice?: number | null
  category: 'rice' | 'caviar' | 'fish' | 'honey' | 'chicken' | 'souvenir'
  categoryFa: string
  image: string
  gallery?: string[]
  stock: number
  inStock: boolean
  featured: boolean
  active: boolean
  tags: string[]
  rating: number
  reviewsCount: number
  views?: number
  metadata?: { weight?: number; unit?: string; origin?: string }
  createdAt?: string
  updatedAt?: string
}

export interface ProductListResponse {
  success: boolean
  message: string
  data: Product[]
  pagination: Pagination
}

export interface CategoryStat {
  _id: string
  count: number
  categoryFa: string
}

export interface User {
  _id: string
  phone: string
  fullName?: string
  email?: string | null
  profileImage?: string
  role: 'user' | 'admin' | 'seller'
  phoneVerified: boolean
  isActive: boolean
  walletBalance?: number
  createdAt?: string
  acceptedTerms?: boolean
}

export interface CartItem {
  productId: string | {
    _id: string
    name: string
    price: number
    discountPrice?: number | null
    image?: string
    category?: string
    categoryFa?: string
    inStock?: boolean
    stock?: number
  }
  productName: string
  quantity: number
  price: number
  total: number
  available: boolean
  active: boolean
  image?: string
}

export interface CartSummary {
  totalItems: number
  totalAmount: number
  totalDiscount: number
  shippingFee: number
  couponDiscount: number
  couponCode?: string | null
  couponAmount?: number
  taxAmount?: number
  taxRate?: number
  finalAmount: number
  items: CartItem[]
}

export interface CartData extends CartSummary {
  cartId: string
  updatedAt?: string
}

export interface OrderAddressInfo {
  recipientName?: string
  city?: string
  province?: string
  estimatedDelivery?: string
}

export interface OrderTimelineEntry {
  status: string
  date: string
  description: string
}

export interface OrderListItem {
  id: string
  orderNumber: string
  status: OrderStatus
  statusFa: string
  totalAmount: number
  itemCount: number
  orderedAt: string
  displayDate: string
  shippingInfo?: { city?: string; province?: string; recipientName?: string }
  firstItem?: { productName: string; image?: string; quantity: number } | null
}

export type OrderStatus =
  | 'pending'
  | 'paid'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded'

export type PaymentMethod = 'wallet' | 'zarinpal' | 'bank_transfer' | 'cash_on_delivery'

export interface OrderDetail {
  _id: string
  orderNumber: string
  user?: string | { _id: string; name?: string; email?: string; phone?: string }
  items: Array<{
    product?: string | { _id: string; name?: string; image?: string; price?: number; discountPrice?: number | null; categoryFa?: string }
    productName: string
    productImage?: string
    categoryFa?: string
    quantity: number
    unitPrice: number
    finalUnitPrice: number
    totalPrice: number
  }>
  shippingAddress: {
    recipientName: string
    recipientPhone: string
    province: string
    city: string
    address: string
    postalCode: string
    deliveryNotes?: string
  }
  payment: {
    method: PaymentMethod
    amount: number
    status: 'pending' | 'completed' | 'failed' | 'refunded'
    transactionId?: string
    paidAt?: string
  }
  subtotal: number
  discount: number
  shippingCost: number
  tax?: number
  totalAmount: number
  status: OrderStatus
  statusFa?: string
  notes?: { customer?: string; admin?: string }
  createdAt: string
  displayDate?: string
  itemCount?: number
  timeline?: OrderTimelineEntry[]
  summary?: {
    orderNumber: string
    status: OrderStatus
    statusFa: string
    totalAmount: number
    itemCount: number
    orderedAt: string
    estimatedDelivery?: string
    estimatedTimeRemaining?: string | null
    shippingAddress: { recipientName: string; city: string; province: string }
    payment: { method: PaymentMethod; status: string; amount: number }
  }
}

export interface Address {
  _id: string
  fullName: string
  phone: string
  province: string
  city: string
  address: string
  postalCode: string
  label?: 'خانه' | 'کار' | 'فامیل' | 'دیگر'
  buildingNumber?: string
  unit?: string
  floor?: string
  description?: string
  isDefault: boolean
  isActive: boolean
  formattedAddress?: string
  createdAt?: string
}

export interface Wallet {
  _id: string
  user: string
  balance: number
  lockedBalance: number
  totalDeposits: number
  totalWithdrawals: number
  isActive: boolean
  availableBalance?: number
  createdAt?: string
}

export interface TrackOrderResult {
  orderNumber: string
  status: OrderStatus
  statusFa: string
  timeline?: OrderTimelineEntry[]
  shippingInfo?: OrderAddressInfo
  tracking?: { code: string; provider: string; url?: string } | null
  itemCount?: number
  totalAmount?: number
}
