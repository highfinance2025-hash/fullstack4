/* Formatting helpers — Persian numerals, تومان currency, dates */

const nf = new Intl.NumberFormat('fa-IR')
const nf0 = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 0 })

export function faNum(n: number | string | undefined | null): string {
  if (n === undefined || n === null || n === '') return ''
  const num = typeof n === 'string' ? Number(n.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))) : n
  if (Number.isNaN(num)) return String(n)
  return nf.format(num)
}

export function toman(n: number | undefined | null): string {
  if (n === undefined || n === null) return ''
  return `${nf0.format(n)} تومان`
}

export function discountPercent(price: number, discountPrice?: number | null): number {
  if (!discountPrice || discountPrice >= price || price <= 0) return 0
  return Math.round(((price - discountPrice) / price) * 100)
}

export function finalPrice(p: { price: number; discountPrice?: number | null }): number {
  return p.discountPrice && p.discountPrice < p.price ? p.discountPrice : p.price
}

const dateFmt = new Intl.DateTimeFormat('fa-IR', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
})
const dateTimeFmt = new Intl.DateTimeFormat('fa-IR', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
})

export function faDate(d: string | Date | undefined | null): string {
  if (!d) return ''
  try {
    return dateFmt.format(new Date(d))
  } catch {
    return ''
  }
}

export function faDateTime(d: string | Date | undefined | null): string {
  if (!d) return ''
  try {
    return dateTimeFmt.format(new Date(d))
  } catch {
    return ''
  }
}

/* Convert Persian/Arabic digits in user input to Latin digits */
export function toLatinDigits(s: string): string {
  return s
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(' ')
}

export const CATEGORY_ORDER = ['rice', 'caviar', 'fish', 'honey', 'chicken', 'souvenir'] as const

export const CATEGORIES: Record<string, { fa: string; icon: string }> = {
  rice: { fa: 'برنج شمال', icon: '/images/brand/cat-rice.svg' },
  caviar: { fa: 'خاویار ایرانی', icon: '/images/brand/cat-caviar.svg' },
  fish: { fa: 'ماهی تازه', icon: '/images/brand/cat-fish.svg' },
  honey: { fa: 'عسل طبیعی', icon: '/images/brand/cat-honey.svg' },
  chicken: { fa: 'مرغ محلی', icon: '/images/brand/cat-chicken.svg' },
  souvenir: { fa: 'سوغات شمال', icon: '/images/brand/cat-souvenir.svg' },
}

export const PAYMENT_METHODS: Record<PaymentMethodKey, { fa: string; desc: string; icon: string }> = {
  zarinpal: {
    fa: 'پرداخت اینترنتی (زرین‌پال)',
    desc: 'انتقال به درگاه پرداخت اینترنتی و بازگشت خودکار به فروشگاه',
    icon: 'credit-card',
  },
  wallet: {
    fa: 'کیف پول اچ‌تی‌لند',
    desc: 'پرداخت آنی از موجودی کیف پول حساب شما',
    icon: 'wallet',
  },
  bank_transfer: {
    fa: 'کارت به کارت / انتقال بانکی',
    desc: 'سفارش ثبت می‌شود و پس از تأیید واریز، پردازش می‌گردد',
    icon: 'landmark',
  },
  cash_on_delivery: {
    fa: 'پرداخت در محل',
    desc: 'پرداخت نقدی هنگام تحویل سفارش (برای شهرهای منتخب)',
    icon: 'banknote',
  },
}

type PaymentMethodKey = 'wallet' | 'zarinpal' | 'bank_transfer' | 'cash_on_delivery'

export const ORDER_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-saffron-50 text-saffron-600 border-saffron-100',
  paid: 'bg-forest-50 text-forest-700 border-forest-100',
  processing: 'bg-forest-50 text-forest-600 border-forest-100',
  shipped: 'bg-forest-100/70 text-forest-800 border-forest-200',
  delivered: 'bg-forest-800 text-ivory border-forest-800',
  cancelled: 'bg-destructive/10 text-destructive border-destructive/20',
  refunded: 'bg-clay/10 text-clay border-clay/20',
}
