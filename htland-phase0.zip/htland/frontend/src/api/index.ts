/* Domain API adapters — one place per backend area */
import { api, apiData } from '@/lib/api'
import type {
  Address,
  CartData,
  CategoryStat,
  OrderDetail,
  OrderListItem,
  Product,
  ProductListResponse,
  TrackOrderResult,
  User,
  Wallet,
} from '@/lib/types'

/* ── Products ── */
export interface ProductQuery {
  page?: number
  limit?: number
  category?: string
  search?: string
  minPrice?: number
  maxPrice?: number
  inStock?: boolean
  featured?: boolean
  sort?: string
  tags?: string
}

const clean = (q: Record<string, unknown>) =>
  Object.fromEntries(
    Object.entries(q)
      .filter(([, v]) => v !== undefined && v !== null && v !== '')
      .map(([k, v]) => [k, String(v)])
  ) as Record<string, string>

export const productsApi = {
  async list(q: ProductQuery = {}, signal?: AbortSignal) {
    const res = await api<ProductListResponse>(`/api/v1/products?${new URLSearchParams(clean(q as any))}`, { signal, auth: false })
    return res
  },
  async featured(limit = 8): Promise<Product[]> {
    const res = await api<{ data: Product[] }>(`/api/v1/products/featured?limit=${limit}`, { auth: false })
    return res.data ?? []
  },
  async detail(idOrSlug: string, signal?: AbortSignal): Promise<Product> {
    const res = await api<{ data: Product }>(`/api/v1/products/${encodeURIComponent(idOrSlug)}`, { signal, auth: false })
    return res.data
  },
  async categoryStats(): Promise<CategoryStat[]> {
    const res = await api<{ data: CategoryStat[] }>('/api/v1/products/categories/stats', { auth: false })
    return res.data ?? []
  },
  async search(q: string, extra: ProductQuery = {}): Promise<ProductListResponse> {
    return api<ProductListResponse>(
      `/api/v1/products/search?${new URLSearchParams(clean({ q, ...extra } as any))}`,
      { auth: false }
    )
  },
}

/* ── Auth ── */
export const authApi = {
  async sendOtp(phone: string): Promise<{ phone: string; isNewUser: boolean; expiresIn: number; otpCode?: string }> {
    const res = await api<{ data: any }>('/api/v1/auth/send-otp', { method: 'POST', body: { phone }, auth: false })
    return res.data
  },
  async verifyOtp(phone: string, otpCode: string, accepted?: { acceptedTerms?: boolean; acceptedPrivacy?: boolean }): Promise<{ user: User; token: string }> {
    const res = await api<{ data: { user: User; token: string } }>('/api/v1/auth/verify-otp', {
      method: 'POST',
      body: { phone, otpCode, ...accepted },
      auth: false,
    })
    return res.data
  },
  async profile(): Promise<User> {
    const res = await api<{ data: { user: User } }>('/api/v1/auth/profile')
    return res.data.user
  },
  async updateProfile(updates: Partial<User>): Promise<User> {
    const res = await api<{ data: { user: User } }>('/api/v1/auth/profile', { method: 'PUT', body: updates })
    return res.data.user
  },
  async logout(): Promise<void> {
    await api('/api/v1/auth/logout', { method: 'POST' }).catch(() => undefined)
  },
}

/* ── Cart ── */
export const cartApi = {
  get: () => apiData<CartData>('/api/v1/cart'),
  addItem: (productId: string, quantity = 1) =>
    apiData<{ cartSummary: CartData }>('/api/v1/cart/items', { method: 'POST', body: { productId, quantity } }),
  updateItem: (productId: string, quantity: number) =>
    apiData<{ cartSummary: CartData; removed?: boolean; updated?: boolean }>(`/api/v1/cart/items/${productId}`, {
      method: 'PUT',
      body: { quantity },
    }),
  removeItem: (productId: string) =>
    apiData<{ cartSummary: CartData }>(`/api/v1/cart/items/${productId}`, { method: 'DELETE' }),
  clear: () => apiData<{ removedItemsCount: number }>('/api/v1/cart', { method: 'DELETE' }),
  applyCoupon: (couponCode: string) =>
    apiData<{ couponCode: string; discountPercentage: number; discountAmount: number; cartSummary: CartData }>(
      '/api/v1/cart/coupon',
      { method: 'POST', body: { couponCode } }
    ),
  removeCoupon: () => apiData<{ cartSummary: CartData }>('/api/v1/cart/coupon', { method: 'DELETE' }),
  updateShipping: (shippingFee: number) =>
    apiData<{ newShippingFee: number; cartSummary: CartData }>('/api/v1/cart/shipping', {
      method: 'PUT',
      body: { shippingFee },
    }),
  prepareCheckout: () =>
    apiData<{ checkoutId: string; cartSummary: CartData; canCheckout: boolean; expiresIn: number }>(
      '/api/v1/cart/checkout/prepare',
      { method: 'POST' }
    ),
  sync: () => apiData<{ updatedItems: unknown[]; removedItems: Array<{ productId: string; productName: string; reason: string }> }>('/api/v1/cart/sync', { method: 'POST' }),
}

/* ── Orders ── */
export const ordersApi = {
  async listWithPage(params: { page?: number; limit?: number; status?: string } = {}) {
    const search = new URLSearchParams(clean(params as any))
    return api<{ data: OrderListItem[]; pagination: any }>(`/api/v1/orders?${search}`)
  },
  get: (id: string) => apiData<{ order: OrderDetail }>(`/api/v1/orders/${id}`),
  stats: () => apiData<{ totalOrders: number; totalAmount: number; pendingOrders: number; deliveredOrders: number; cancelledOrders: number }>('/api/v1/orders/stats'),
  recent: (limit = 5) => apiData<any[]>(`/api/v1/orders/recent?limit=${limit}`),
  create: (body: { shippingAddressId: string; paymentMethod: string; notes?: string; useWalletBalance?: boolean }) =>
    api<{
      data: {
        orderId: string
        orderNumber: string
        status: string
        statusFa?: string
        totalAmount: number
        payment?: { method: string; status: string; nextStep?: string }
        paymentUrl?: string
        redirectToGateway?: boolean
        items?: Array<{ productName: string; quantity: number; price: number; total: number }>
      }
    }>('/api/v1/orders', { method: 'POST', body }),
  cancel: (id: string, reason?: string) =>
    apiData<{ orderNumber: string; status: string }>(`/api/v1/orders/${id}/cancel`, { method: 'POST', body: { reason } }),
  track: (orderNumber: string, phone?: string) => {
    const search = new URLSearchParams({ orderNumber, ...(phone ? { phone } : {}) })
    return apiData<TrackOrderResult>(`/api/v1/orders/track/${encodeURIComponent(orderNumber)}?${search}`)
  },
}

/* ── Addresses ── */
export interface AddressInput {
  fullName: string
  phone: string
  province: string
  city: string
  address: string
  postalCode: string
  label?: string
  buildingNumber?: string
  unit?: string
  floor?: string
  description?: string
  isDefault?: boolean
}

export const addressesApi = {
  list: async (): Promise<Address[]> => {
    const res = await api<{ data: Address[]; count: number }>('/api/v1/addresses')
    return res.data ?? []
  },
  create: (body: AddressInput) => apiData<Address>('/api/v1/addresses', { method: 'POST', body }),
  update: (id: string, body: Partial<AddressInput>) => apiData<Address>(`/api/v1/addresses/${id}`, { method: 'PUT', body }),
  remove: (id: string) => api(`/api/v1/addresses/${id}`, { method: 'DELETE' }),
  setDefault: (id: string) => api(`/api/v1/addresses/${id}/set-default`, { method: 'POST' }),
  defaultAddress: () => apiData<Address>('/api/v1/addresses/default'),
}

/* ── Wallet ── */
export const walletApi = {
  list: async (): Promise<Wallet[]> => {
    const res = await api<{ data: { wallets: Wallet[]; totalBalance?: number } }>('/api/v1/wallet')
    return res.data?.wallets ?? []
  },
  create: () => apiData<Wallet>('/api/v1/wallet/create', { method: 'POST' }),
  // شارژ/برداشت عمداً از فرانت و API عمومی حذف شده‌اند (فقط از طریق درگاه + سرور).
}

/* ── Profile ── */
export const profileApi = {
  get: () => apiData<User>('/api/v1/profile'),
  update: (updates: Record<string, unknown>) => apiData<User>('/api/v1/profile', { method: 'PUT', body: updates }),
}
