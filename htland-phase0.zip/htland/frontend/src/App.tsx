import { lazy, Suspense } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import Home from '@/pages/home'
import { Skeleton } from '@/components/ui/skeleton'

const Products = lazy(() => import('@/pages/products'))
const ProductDetail = lazy(() => import('@/pages/product-detail'))
const Cart = lazy(() => import('@/pages/cart'))
const Login = lazy(() => import('@/pages/login'))
const Checkout = lazy(() => import('@/pages/checkout'))
const TrackOrder = lazy(() => import('@/pages/track-order'))
const OrderSuccess = lazy(() => import('@/pages/order-success'))
const PaymentFailed = lazy(() => import('@/pages/payment-failed'))
const AccountLayout = lazy(() => import('@/account/layout'))
const AccountProfile = lazy(() => import('@/account/profile'))
const AccountOrders = lazy(() => import('@/account/orders'))
const AccountOrderDetail = lazy(() => import('@/account/order-detail'))
const AccountAddresses = lazy(() => import('@/account/addresses'))
const AccountWallet = lazy(() => import('@/account/wallet'))
const NotFound = lazy(() => import('@/pages/not-found'))

function PageFallback() {
  return (
    <div className="container-page py-10">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-72 rounded-xl" />
        ))}
      </div>
    </div>
  )
}

export default function App() {
  const location = useLocation()
  return (
    <div className="flex min-h-dvh flex-col">
      <Header />
      <main id="main" className="flex-1" key={location.pathname}>
        <Suspense fallback={<PageFallback />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/products/:idOrSlug" element={<ProductDetail />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/login" element={<Login />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/track" element={<TrackOrder />} />
            <Route path="/orders/:id/success" element={<OrderSuccess />} />
            <Route path="/orders/payment/failed" element={<PaymentFailed />} />
            <Route path="/account" element={<AccountLayout />}>
              <Route index element={<AccountProfile />} />
              <Route path="orders" element={<AccountOrders />} />
              <Route path="orders/:id" element={<AccountOrderDetail />} />
              <Route path="addresses" element={<AccountAddresses />} />
              <Route path="wallet" element={<AccountWallet />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
