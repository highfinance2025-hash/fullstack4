#!/usr/bin/env node
/* End-to-end backend integration smoke test via real HTTP (no payment fabrication) */
const BASE = 'http://127.0.0.1:3000';
let token = '';
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${extra}`); }
};

async function req(method, path, body, auth = true) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(auth && token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

(async () => {
  console.log('— Public endpoints');
  const health = await req('GET', '/health', null, false);
  ok('GET /health', health.status === 200);
  const list = await req('GET', '/api/v1/products?limit=5&sort=price', null, false);
  ok('GET /products (list + pagination)', list.status === 200 && list.json.data.length === 5 && list.json.pagination.total > 0);
  const feat = await req('GET', '/api/v1/products/featured?limit=4', null, false);
  ok('GET /products/featured', feat.status === 200 && feat.json.data.length > 0);
  const stats = await req('GET', '/api/v1/products/categories/stats', null, false);
  ok('GET /categories/stats', stats.status === 200 && stats.json.data.length === 6);

  const catFilter = await req('GET', '/api/v1/products?category=caviar', null, false);
  ok('category filter', catFilter.status === 200 && catFilter.json.data.every(p => p.category === 'caviar'));
  const priceFilter = await req('GET', '/api/v1/products?minPrice=100000&maxPrice=300000', null, false);
  ok('price filter', priceFilter.status === 200 && priceFilter.json.data.every(p => p.price >= 100000 && p.price <= 300000));
  const inStock = await req('GET', '/api/v1/products?inStock=true', null, false);
  ok('inStock filter', inStock.status === 200 && inStock.json.data.every(p => p.inStock === true));
  const search = await req('GET', '/api/v1/products/search?q=عسل', null, false);
  ok('search', search.status === 200 && search.json.data.length > 0);

  const slug = list.json.data[0].slug;
  const bySlug = await req('GET', `/api/v1/products/${slug}`, null, false);
  ok('GET /products/:slug', bySlug.status === 200 && bySlug.json.data.slug === slug);

  console.log('— Auth (OTP)');
  const PHONE = '09121112233';
  const send = await req('POST', '/api/v1/auth/send-otp', { phone: PHONE }, false);
  ok('POST /auth/send-otp', send.status === 200 && send.json.success === true);
  const otpCode = send.json?.data?.otpCode;
  ok('dev otpCode returned', !!otpCode);
  const verify = await req('POST', '/api/v1/auth/verify-otp', { phone: PHONE, otpCode, acceptedTerms: true, acceptedPrivacy: true }, false);
  ok('POST /auth/verify-otp', verify.status === 200 && !!verify.json.data?.token);
  token = verify.json.data.token;
  const badOtp = await req('POST', '/api/v1/auth/verify-otp', { phone: PHONE, otpCode: '000000' }, false);
  ok('wrong OTP rejected', badOtp.status === 400);

  console.log('— Profile & addresses');
  const profile = await req('GET', '/api/v1/auth/profile');
  ok('GET /auth/profile', profile.status === 200 && profile.json.data?.user?.phone === PHONE);
  const prof = await req('GET', '/api/v1/profile');
  ok('GET /profile (fixed)', prof.status === 200, JSON.stringify(prof.json).slice(0, 100));
  const addrs = await req('GET', '/api/v1/addresses');
  ok('GET /addresses', addrs.status === 200 && addrs.json.data.length > 0);
  const usedAddress = addrs.json.data.find(a => a.city === 'بابل') ?? addrs.json.data[0];
  const addressId = usedAddress._id;
  const newAddr = await req('POST', '/api/v1/addresses', {
    fullName: 'کاربر آزمون', phone: '09121112233', province: 'مازندران', city: 'بابل',
    address: `خیابان آزمایشی ${Date.now()}، کوچه تست، پلاک ۱`, postalCode: `48${String(Date.now()).slice(-8)}`, label: 'کار',
  });
  // 201 = created; 409 = max-3-addresses guard (correct enforcement after prior runs)
  ok('POST /addresses (create or max-guard)', newAddr.status === 201 || (newAddr.status === 409 && /حداکثر/.test(newAddr.json?.error?.message || newAddr.json?.error || '')), JSON.stringify(newAddr.json).slice(0, 140));

  console.log('— Cart');
  const cart0 = await req('GET', '/api/v1/cart');
  ok('GET /cart', cart0.status === 200 && cart0.json.data?.cartId);
  // clear any leftovers
  await req('DELETE', '/api/v1/cart');
  const featProd = feat.json.data[0];
  const add1 = await req('POST', '/api/v1/cart/items', { productId: featProd._id, quantity: 2 });
  ok('POST /cart/items', add1.status === 200 && add1.json.data?.cartSummary?.totalItems === 2);
  const productId = featProd._id;
  const upd = await req('PUT', `/api/v1/cart/items/${productId}`, { quantity: 3 });
  ok('PUT /cart/items/:id', upd.status === 200 && upd.json.data?.cartSummary?.totalItems === 3);
  const coupon = await req('POST', '/api/v1/cart/coupon', { couponCode: 'HTLAND10' });
  ok('POST /cart/coupon', coupon.status === 200 && coupon.json.data?.discountPercentage === 10);
  const prep = await req('POST', '/api/v1/cart/checkout/prepare');
  ok('POST /cart/checkout/prepare', prep.status === 200 && prep.json.data?.canCheckout === true);

  console.log('— Orders');
  const order = await req('POST', '/api/v1/orders', {
    shippingAddressId: addressId,
    paymentMethod: 'cash_on_delivery',
    notes: 'تست یکپارچگی',
  });
  ok('POST /orders (cod)', order.status === 201 && order.json.data?.orderNumber, JSON.stringify(order.json).slice(0, 200));
  const orderNumber = order.json?.data?.orderNumber;
  const myOrders = await req('GET', '/api/v1/orders');
  ok('GET /orders', myOrders.status === 200 && myOrders.json.data.length > 0);
  const orderId = order.json.data.orderId;
  const detail = await req('GET', `/api/v1/orders/${orderId}`);
  ok('GET /orders/:id', detail.status === 200);
  const shipAddr = detail.json?.data?.order?.shippingAddress;
  ok('real address used (matches selected)', shipAddr?.city === usedAddress.city, `got: ${shipAddr?.city} want: ${usedAddress.city}`);
  const track = await req('GET', `/api/v1/orders/track/${orderNumber}`, null, false);
  ok('track without phone rejected (ownership guard)', track.status === 400, `status=${track.status}`);
  const trackNoMatch = await req('GET', `/api/v1/orders/track/${orderNumber}?phone=09120009999`, null, false);
  ok('track with wrong phone rejected (403)', trackNoMatch.status === 403, `status=${trackNoMatch.status}`);
  const track2 = await req('GET', `/api/v1/orders/track/${orderNumber}?phone=09121112233`, null, false);
  ok('GET /orders/track/:orderNumber (public + matching phone)', track2.status === 200 && track2.json.data?.orderNumber === orderNumber, `status=${track2.status}`);
  const stats2 = await req('GET', '/api/v1/orders/stats');
  ok('GET /orders/stats', stats2.status === 200 && stats2.json.data?.totalOrders > 0);
  const cancel = await req('POST', `/api/v1/orders/${orderId}/cancel`, { reason: 'تست' });
  ok('POST /orders/:id/cancel', cancel.status === 200, JSON.stringify(cancel.json).slice(0, 120));

  console.log('— Wallet (real endpoints)');
  const w1 = await req('GET', '/api/v1/wallet');
  ok('GET /wallet', w1.status === 200 && w1.json.data?.wallets?.length > 0);
  const wid = w1.json.data.wallets[0]._id;
  // امنیت: شارژ/برداشت مستقیم نباید از API عمومی در دسترس باشد
  for (const p of ['deposit', 'withdraw', 'lock', 'unlock']) {
    const r = await req('POST', `/api/v1/wallet/${p}`, { walletId: wid, amount: 2000000 });
    ok(`POST /wallet/${p} is NOT exposed (404)`, r.status === 404, `status=${r.status}`);
  }

  // شارژ کیف پول دیگر از API عمومی ممکن نیست؛ این بخش فقط وقتی اجرا می‌شود که کیف پول (مثلاً با seed) موجودی داشته باشد.
  const walletFunded = (w1.json.data.wallets[0].balance ?? 0) >= 500000;
  if (walletFunded) {
    console.log('— Wallet-paid order (REAL debit)');
    await req('DELETE', '/api/v1/cart');
    const wProd = await req('GET', '/api/v1/products?category=honey&limit=1', null, false);
    await req('POST', '/api/v1/cart/items', { productId: wProd.json.data[0]._id, quantity: 1 });
    const balBefore = await req('GET', `/api/v1/wallet/${wid}`);
    const balanceBefore = balBefore.json.data?.balance ?? balBefore.json.data?.wallet?.balance;
    const word = await req('POST', '/api/v1/orders', { shippingAddressId: addressId, paymentMethod: 'wallet' });
    ok('POST /orders (wallet) → paid', word.status === 201 && word.json.data?.status === 'paid', JSON.stringify(word.json).slice(0, 200));
    const walletOrderTotal = word.json.data?.totalAmount ?? 0;
    const balAfter = await req('GET', `/api/v1/wallet/${wid}`);
    const balanceAfter = balAfter.json.data?.balance ?? balAfter.json.data?.wallet?.balance;
    ok('wallet balance decreased by exact order total',
      balanceBefore !== undefined && balanceAfter === balanceBefore - walletOrderTotal,
      `before=${balanceBefore} after=${balanceAfter} orderTotal=${walletOrderTotal}`);
    const walletOrderId = word.json.data?.orderId;
    const cancelW = await req('POST', `/api/v1/orders/${walletOrderId}/cancel`, { reason: 'تست بازگشت وجه' });
    ok('cancel wallet order', cancelW.status === 200, JSON.stringify(cancelW.json).slice(0, 120));
    const balRefund = await req('GET', `/api/v1/wallet/${wid}`);
    const balanceRefund = balRefund.json.data?.balance ?? balRefund.json.data?.wallet?.balance;
    ok('wallet refund credited on cancel', balanceRefund === balanceAfter + walletOrderTotal,
      `afterCancel=${balanceRefund} expected=${balanceAfter + walletOrderTotal}`);
  } else {
    console.log('  SKIP wallet-paid order checks (wallet has no balance; cannot be funded via public API — seed it in DB to run)');
  }
  // insufficient balance guard — deterministic: fresh user with a 0-balance wallet
  await req('DELETE', '/api/v1/cart');
  const cav = await req('GET', '/api/v1/products?category=caviar&sort=price&limit=1', null, false);
  const poorPhone = '0912' + String(Math.floor(1000000 + Math.random() * 8999999)); // ۱۱ رقمی معتبر
  const pSend = await req('POST', '/api/v1/auth/send-otp', { phone: poorPhone }, false);
  const pVerify = await req('POST', '/api/v1/auth/verify-otp', { phone: poorPhone, otpCode: pSend.json?.data?.otpCode, acceptedTerms: true }, false);
  const savedToken = token;
  token = pVerify.json?.data?.token;
  await req('POST', '/api/v1/wallet/create');
  const pAddr = await req('POST', '/api/v1/addresses', {
    fullName: 'کاربر بی‌موجودی', phone: poorPhone, province: 'مازندران', city: 'ساری',
    address: `خیابان تست ${Date.now()}، پلاک ۲`, postalCode: `48${String(Date.now()).slice(-8)}`, label: 'خانه',
  });
  const poorAddr = pAddr.json?.data?._id || pAddr.json?.data?.address?._id || pAddr.json?.data?.addressId;
  await req('POST', '/api/v1/cart/items', { productId: cav.json.data[0]._id, quantity: 1 });
  const poor = await req('POST', '/api/v1/orders', { shippingAddressId: poorAddr, paymentMethod: 'wallet' });
  ok('wallet order beyond balance rejected (400)', poor.status === 400, JSON.stringify(poor.json).slice(0, 140));
  token = savedToken;
  await req('DELETE', '/api/v1/cart');

  console.log('— Zarinpal sandbox flow');
  const zprod = await req('GET', '/api/v1/cart', null);
  await req('DELETE', '/api/v1/cart');
  const fish = await req('GET', '/api/v1/products?category=fish&limit=1', null, false);
  await req('POST', '/api/v1/cart/items', { productId: fish.json.data[0]._id, quantity: 1 });
  const zorder = await req('POST', '/api/v1/orders', { shippingAddressId: addressId, paymentMethod: 'zarinpal' });
  ok('POST /orders (zarinpal) returns paymentUrl', zorder.status === 200 && !!zorder.json.data?.paymentUrl, JSON.stringify(zorder.json).slice(0, 160));
  if (zorder.json.data?.paymentUrl) {
    const res = await fetch(zorder.json.data.paymentUrl, { redirect: 'manual' });
    ok('sandbox gateway redirects (302 to success)', res.status === 302 && (res.headers.get('location') || '').includes('/orders/'), `status=${res.status}`);
  }

  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('TEST CRASH:', e); process.exit(1); });
