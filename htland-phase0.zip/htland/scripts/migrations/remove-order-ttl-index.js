/**
 * Migration: حذف ایندکس TTL از کالکشن سفارشات (orders)
 * ================================================================
 * زمینه: مدل Order قبلاً فیلد expiresAt را با default «now + 30 روز» و
 * ایندکس TTL (expireAfterSeconds: 0) تعریف می‌کرد. مونگو به‌طور خودکار
 * تمام سفارش‌ها را ۳۰ روز پس از ایجاد حذف می‌کرد — حتی سفارش‌های
 * پرداخت‌شده و تحویل‌شده. این رفتار به تأیید کسب‌وکار نرسیده است.
 *
 * این اسکریپت فقط ایندکس TTL را از دیتابیسِ فعال حذف می‌کند (idempotent)
 * و هیچ سندی را حذف نمی‌کند. داده‌های مشتری دست‌نخورده می‌مانند.
 *
 * پس از اجرای این مهاجرت، کد جدید مدل (بدون ایندکس TTL) از ابتدا
 * جلوی بازگشت مشکل را می‌گیرد؛ اما روی هر محیطی که با کد قدیم بالا
 * آمده باشد باید یک‌بار اجرا شود، چون ایندکسِ موجود در دیتابیس بدون
 * این مهاجرت باقی می‌ماند و به حذف خودکار ادامه می‌دهد.
 *
 * استفاده:
 *   node scripts/migrations/remove-order-ttl-index.js
 *   DRY_RUN=true node scripts/migrations/remove-order-ttl-index.js   # فقط گزارش
 *
 * متغیر محیطی MONGODB_URI خوانده می‌شود (پیش‌فرض همان .env پروژه).
 */
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });
const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/htland?replicaSet=rs0';
const DRY_RUN = process.env.DRY_RUN === 'true';

async function main() {
  console.log(`Connecting to ${MONGO_URI.replace(/\/\/.*@/, '//<credentials>@')} ...`);
  await mongoose.connect(MONGO_URI);

  const coll = mongoose.connection.collection('orders');
  const indexes = await coll.indexes();
  const ttlIndexes = indexes.filter(
    (idx) => idx.name === 'expiresAt_1' && idx.expireAfterSeconds !== undefined
  );

  if (ttlIndexes.length === 0) {
    // ممکن است ایندکس با نام دیگری وجود داشته باشد — هر ایندکس TTL روی expiresAt را پیدا کن
    const anyTtl = indexes.filter(
      (idx) => idx.expireAfterSeconds !== undefined && idx.key && idx.key.expiresAt !== undefined
    );
    if (anyTtl.length === 0) {
      console.log('✅ هیچ ایندکس TTL روی orders.expiresAt یافت نشد. نیازی به مهاجرت نیست.');
      await mongoose.disconnect();
      return;
    }
    ttlIndexes.push(...anyTtl);
  }

  for (const idx of ttlIndexes) {
    console.log(`Found TTL index: ${idx.name} (expireAfterSeconds=${idx.expireAfterSeconds})`);
    if (DRY_RUN) {
      console.log(`DRY RUN — would drop index "${idx.name}".`);
      continue;
    }
    await coll.dropIndex(idx.name);
    console.log(`✅ Dropped TTL index "${idx.name}" — سفارش‌ها دیگر خودکار حذف نمی‌شوند.`);
  }

  // گزارش وضعیت داده‌ها (بدون هیچ تغییری در اسناد)
  const total = await coll.countDocuments({});
  const paid = await coll.countDocuments({ 'payment.status': 'completed' });
  console.log(`orders: ${total} document(s) intact, ${paid} paid — no documents were modified or deleted.`);

  await mongoose.disconnect();
  console.log('Migration done.');
}

main().catch((e) => {
  console.error('Migration FAILED:', e);
  process.exit(1);
});
