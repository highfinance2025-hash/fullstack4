/**
 * HTLand Seed Script — idempotent
 * Seeds: admin user, demo customer (wallet + address), 22 products in the 6 real backend categories.
 * Prices are in تومان. Ratings stay 0 (no fabricated reviews).
 *
 * SECURITY: در production پیش‌فرض مسدود است — حساب‌های seed باید فقط در
 * توسعه/تست ساخته شوند. برای اجبار صریح: SEED_ALLOW_PRODUCTION=true
 *
 * Usage: node scripts/seed.js
 */
const path = require('path');
// .env را قبل از هر بررسی/اتصال لود کن تا NODE_ENV/MONGODB_URI در دسترس باشند
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const mongoose = require('mongoose');

// SECURITY GUARD: جلوگیری از ساخت حساب ادمین/نمونه با اعتبار پیش‌فرض در production
if (process.env.NODE_ENV === 'production' && process.env.SEED_ALLOW_PRODUCTION !== 'true') {
  console.error(
    '❌ Refusing to seed in production.\n' +
    '   حساب‌های seed (ادمین/مشتری نمونه) فقط برای توسعه و تست هستند.\n' +
    '   اگر واقعاً مطمئن هستید، با SEED_ALLOW_PRODUCTION=true صریحاً تأیید کنید\n' +
    '   و بلافاصله پس از ورود، شماره‌ها را به شماره‌های واقعی سازمان تغییر دهید.'
  );
  process.exit(1);
}

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/htland?replicaSet=rs0';

const User = require('../src/models/User.model');
const Wallet = require('../src/models/Wallet.model');
const Address = require('../src/models/Address.model');
const Product = require('../src/models/Product.model');

const ADMIN_PHONE = '09120000000';
const DEMO_PHONE = '09121112233';

const products = [
  // ── برنج شمال ──
  { name: 'برنج هاشمی ممتاز شمال', slug: 'hashemi-rice-5kg', price: 985000, discountPrice: 879000, category: 'rice', categoryFa: 'برنج شمال', image: '/images/brand/rice-1.svg', gallery: ['/images/brand/rice-1b.svg'], stock: 40, featured: true, tags: ['برنج', 'هاشمی', 'معطر', 'شمال'], description: 'برنج هاشمی ممتاز از شالیزارهای مرکز استان مازندران؛ دانه‌های بلند و خوش‌عطر با پخت یکنواخت و عطر بی‌نظیر. برداشت سال جاری، شالیکوبی تازه و بسته‌بندی بهداشتی ۵ کیلوگرمی.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'برنج طارم اعلا', slug: 'tarem-rice-5kg', price: 895000, category: 'rice', categoryFa: 'برنج شمال', image: '/images/brand/rice-2.svg', gallery: ['/images/brand/rice-2b.svg'], stock: 35, featured: true, tags: ['برنج', 'طارم', 'معطر'], description: 'برنج طارم اعلا با دانه کشیده و عطر ماندگار، از مزارع طارم‌سادات. مناسب برای پخت روزانه و مهمانی؛ گلپوش سفید و بافت نرم پس از پخت. بسته‌بندی ۵ کیلوگرمی.', unit: 'کیلوگرم', origin: 'زنجان و مازندران' },
  { name: 'برنج علی‌کاظمی معطر', slug: 'alikazemi-rice-5kg', price: 1150000, discountPrice: 1050000, category: 'rice', categoryFa: 'برنج شمال', image: '/images/brand/rice-3.svg', stock: 18, featured: true, tags: ['برنج', 'علی‌کاظمی', 'لاهیجان'], description: 'برنج علی‌کاظمی لاهیجان، مرغوب‌ترین برنج منطقه گیلان با عطر فوق‌العاده و دانه‌های ظریف. کشت سنتی، آبیاری با آب کوهستانی و برداشت دستی. محدود و فصلی.', unit: 'کیلوگرم', origin: 'گیلان' },
  { name: 'برنج دم‌سیاه ارگانیک', slug: 'domsiah-rice-2kg', price: 640000, category: 'rice', categoryFa: 'برنج شمال', image: '/images/brand/rice-4.svg', stock: 12, tags: ['برنج', 'دم‌سیاه', 'ارگانیک'], description: 'برنج دم‌سیاه بومی شمال ایران با خاصیت آنتی‌اکسیدان بالا و طعم اصیل. کشت کاملاً ارگانیک بدون کود شیمیایی؛ انتخابی سالم برای سفره روزانه. بسته ۲ کیلوگرمی.', unit: 'کیلوگرم', origin: 'مازندران' },

  // ── خاویار ایرانی ──
  { name: 'خاویار اوزون‌روان درجه یک', slug: 'ossetra-caviar-100g', price: 4850000, discountPrice: 4590000, category: 'caviar', categoryFa: 'خاویار ایرانی', image: '/images/brand/caviar-1.svg', gallery: ['/images/brand/caviar-1b.svg'], stock: 6, featured: true, tags: ['خاویار', 'اوزون‌روان', 'لوکس'], description: 'خاویار اوزون‌روان درجه یک با دانه‌های درشت و رنگ کهربایی، از پرورشگاه‌های استاندارد سواحل خزر. عطر کره‌ای و بافت لطیف؛ همراه بسته‌بندی یخ و گواهی اصالت. قوطی ۱۰۰ گرمی.', unit: 'گرم', origin: 'مازندران' },
  { name: 'خاویار سپید ایرانی', slug: 'beluga-caviar-50g', price: 3950000, category: 'caviar', categoryFa: 'خاویار ایرانی', image: '/images/brand/caviar-2.svg', stock: 4, tags: ['خاویار', 'سپید', 'بلوگا'], description: 'خاویار سپید (بلوگا) با دانه‌های بزرگ خاکستری و طعمی بی‌همتا؛ نادرترین خاویار ایران. حمل زنجیره سرد و ارسال سریع ویژه. قوطی ۵۰ گرمی.', unit: 'گرم', origin: 'مازندران' },
  { name: 'خاویار گلد ممتاز', slug: 'golden-caviar-30g', price: 2150000, category: 'caviar', categoryFa: 'خاویار ایرانی', image: '/images/brand/caviar-3.svg', stock: 8, tags: ['خاویار', 'گلد'], description: 'خاویار گلد ممتاز با دانه‌های طلایی روشن و عطر ملایم؛ انتخابی شیک برای هدیه و مجالس رسمی. همراه قاشق مرواریدی و بسته‌بندی هدیه. قوطی ۳۰ گرمی.', unit: 'گرم', origin: 'گیلان' },

  // ── ماهی تازه ──
  { name: 'قزل‌آلای تازه صید روز', slug: 'fresh-trout-1kg', price: 245000, category: 'fish', categoryFa: 'ماهی تازه', image: '/images/brand/fish-1.svg', gallery: ['/images/brand/fish-1b.svg'], stock: 25, featured: true, tags: ['ماهی', 'قزل‌آلا', 'تازه'], description: 'قزل‌آلای رنگین کمانی تازه از مزارع پرورشی آب سرد کوهستان؛ صید روز و ارسال با یخ خشک. گوشتی صاف و بدون بوی تندی، مناسب گریل و تنوری. حدود ۱ کیلوگرم.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'ماهی سفید خزر', slug: 'caspiian-whitefish-1kg', price: 320000, discountPrice: 285000, category: 'fish', categoryFa: 'ماهی تازه', image: '/images/brand/fish-2.svg', stock: 15, tags: ['ماهی', 'سفید', 'خزر'], description: 'ماهی سفید (سیس‌پوست) خزر، از محبوب‌ترین ماهیان شمال با گوشت لطیف و استخوان‌های کم؛ صید فصل از ساحل تولیات و بندر ترکمن. تمیزشده و آماده پخت.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'فیله کپور تازه', slug: 'carp-fillet-800g', price: 198000, category: 'fish', categoryFa: 'ماهی تازه', image: '/images/brand/fish-3.svg', stock: 20, tags: ['ماهی', 'کپور', 'فیله'], description: 'فیله کپور آشیانه‌ای بدون تیغ، آماده سرخ‌کردن؛ مناسب سوپ‌خوراک و قلیه ماهی. بسته‌بندی بهداشتی حدود ۸۰۰ گرم با زنجیره سرد کامل.', unit: 'گرم', origin: 'گیلان' },
  { name: 'ماهی کفال تازه', slug: 'mullet-fish-1kg', price: 175000, category: 'fish', categoryFa: 'ماهی تازه', image: '/images/brand/fish-4.svg', stock: 18, tags: ['ماهی', 'کفال'], description: 'ماهی کفال تازه خزر با گوشت خوش‌طعم و روغن مفید امگا۳؛ صید روز، شسته و آماده طبخ. مناسب کباب ترش و ماهی‌پلو.', unit: 'کیلوگرم', origin: 'گلستان' },

  // ── عسل طبیعی ──
  { name: 'عسل کنار طبیعی', slug: 'konar-honey-1kg', price: 480000, category: 'honey', categoryFa: 'عسل طبیعی', image: '/images/brand/honey-1.svg', gallery: ['/images/brand/honey-1b.svg'], stock: 30, featured: true, tags: ['عسل', 'کنار', 'طبیعی'], description: 'عسل کنار تک‌گل با رنگ کهربایی و عطر ملایم؛ از کندوهای سنتی دشت‌های جنوبی استان سمنان و برداشت بهاره. بدون شکر و حرارت؛ آزمایشگاه‌تأیید. شیشه ۱ کیلوگرمی.', unit: 'کیلوگرم', origin: 'سمنان' },
  { name: 'عسل آویشن کوهستان', slug: 'thyme-honey-1kg', price: 620000, discountPrice: 565000, category: 'honey', categoryFa: 'عسل طبیعی', image: '/images/brand/honey-2.svg', stock: 22, tags: ['عسل', 'آویشن', 'کوهستان'], description: 'عسل آویشن کوهستان از ارتفاعات جنگلی هیرکانی؛ خاصیت آرام‌بخش گلودرد و طعم قوی گیاهی. برداشت محدود تابستان، ساکزون طبیعی. شیشه ۱ کیلوگرمی.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'عسل گون طبیعی', slug: 'gon-honey-900g', price: 540000, category: 'honey', categoryFa: 'عسل طبیعی', image: '/images/brand/honey-3.svg', stock: 16, tags: ['عسل', 'گون'], description: 'عسل گون با بافت سفت و رنگ روشن، از علفزارهای ییلاقی البرز شرقی؛ سرشار از انرژی طبیعی و مناسب مصرف صبحگاهی. شیشه ۹۰۰ گرمی.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'عسل چندگیاه بهاره', slug: 'spring-honey-1kg', price: 395000, category: 'honey', categoryFa: 'عسل طبیعی', image: '/images/brand/honey-4.svg', stock: 28, tags: ['عسل', 'چندگیاه', 'بهاره'], description: 'عسل چندگیاه بهاره از شهد گل‌های وحشی جنگل‌های هیرکانی؛ طعمی متعادل و عطر بهاری. مناسب مصرف خانواده؛ شیشه ۱ کیلوگرمی.', unit: 'کیلوگرم', origin: 'گیلان' },

  // ── مرغ محلی ──
  { name: 'مرغ محلی گیلان', slug: 'gilan-free-range-chicken', price: 128000, category: 'chicken', categoryFa: 'مرغ محلی', image: '/images/brand/chicken-1.svg', stock: 45, featured: true, tags: ['مرغ', 'محلی', 'گیلان'], description: 'مرغ محلی گیلان، پرورش آزاد در حیاط و تغذیه طبیعی؛ گوشت سفت و خوش‌عطر با طعم اصیل. ذبح بهداشتی و بسته‌بندی روز. حدود ۱ کیلوگرم.', unit: 'کیلوگرم', origin: 'گیلان' },
  { name: 'خروس محلی زرد', slug: 'yellow-rooster-1_5kg', price: 285000, category: 'chicken', categoryFa: 'مرغ محلی', image: '/images/brand/chicken-2.svg', stock: 14, tags: ['خروس', 'محلی'], description: 'خروس محلی زرد با گوشت پرچرب و طعم عمیق؛ ایده‌آل برای آبگوشت و خورش سنتی. پرورش سنتی روستایی، ذبح روز. حدود ۱.۵ کیلوگرم.', unit: 'کیلوگرم', origin: 'مازندران' },
  { name: 'اردک محلی تازه', slug: 'local-duck-1_5kg', price: 315000, discountPrice: 289000, category: 'chicken', categoryFa: 'مرغ محلی', image: '/images/brand/chicken-3.svg', stock: 10, tags: ['اردک', 'محلی'], description: 'اردک محلی تازه از تالاب‌های شمال؛ چرب و لذیذ، مناسب کباب اردک و غذاهای اصیل گیلانی. تمیزشده و آماده پخت. حدود ۱.۵ کیلوگرم.', unit: 'کیلوگرم', origin: 'گیلان' },

  // ── سوغات شمال ──
  { name: 'چای بهاره لاهیجان', slug: 'lahijan-spring-tea-500g', price: 385000, category: 'souvenir', categoryFa: 'سوغات شمال', image: '/images/brand/souvenir-1.svg', gallery: ['/images/brand/souvenir-1b.svg'], stock: 33, featured: true, tags: ['چای', 'لاهیجان', 'بهاره'], description: 'چای بهاره لاهیجان از باغ‌های چای تپه‌های سبز گیلان؛ عطر و رنگ طبیعی بدون رنگ‌افزوده. خشک‌شده در سایه و بسته‌بندی محافظ عطر. قوطی ۵۰۰ گرمی.', unit: 'گرم', origin: 'گیلان' },
  { name: 'نان برنجی فومن', slug: 'fuman-rice-cookie-1kg', price: 220000, category: 'souvenir', categoryFa: 'سوغات شمال', image: '/images/brand/souvenir-2.svg', stock: 26, tags: ['نان برنجی', 'فومن', 'شیرینی'], description: 'نان برنجی اصیل فومن با مغز گردوی تازه و عطر گلاب؛ پخت روز در تنورهای سنتی شهر فومن. جعبه ۱ کیلوگرمی مقاوم برای ارسال مطمئن.', unit: 'بسته', origin: 'گیلان' },
  { name: 'حلوا کنجدی املش', slug: 'amlesh-sesame-halva-500g', price: 185000, discountPrice: 165000, category: 'souvenir', categoryFa: 'سوغات شمال', image: '/images/brand/souvenir-3.svg', stock: 24, tags: ['حلوا', 'کنجد', 'املش'], description: 'حلوا کنجدی املش با کنجد بوداده و شیره انگور طبیعی؛ انرژی‌بخش و بدون قند سفید. بسته ۵۰۰ گرمی با بسته‌بندی مخصوص ارسال.', unit: 'بسته', origin: 'گیلان' },
  { name: 'مربای بالنگ خانگی', slug: 'bahleng-marmalade-750g', price: 165000, category: 'souvenir', categoryFa: 'سوغات شمال', image: '/images/brand/souvenir-4.svg', stock: 19, tags: ['مربا', 'بالنگ', 'خانگی'], description: 'مربای بالنگ خانگی با برش‌های درشت و شربت غلیظ؛ طعم سنتی شمالی برای صبحانه. تهیه از بالنگ‌های باغ‌های خانگی تنکابن. شیشه ۷۵۰ گرمی.', unit: 'بسته', origin: 'مازندران' },
];

async function main() {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to', MONGO_URI);

  // Users
  let admin = await User.findOne({ phone: ADMIN_PHONE });
  if (!admin) {
    admin = await User.create({ phone: ADMIN_PHONE, fullName: 'مدیریت اچ‌تی‌لند', role: 'admin', phoneVerified: true, isActive: true });
    console.log('Admin created:', admin.phone);
  }
  let demo = await User.findOne({ phone: DEMO_PHONE });
  if (!demo) {
    demo = await User.create({ phone: DEMO_PHONE, fullName: 'مشتری نمونه', role: 'user', phoneVerified: true, isActive: true });
    console.log('Demo customer created:', demo.phone);
  }

  // Wallet for demo (real Wallet model)
  let wallet = await Wallet.findOne({ user: demo._id });
  if (!wallet) {
    wallet = await Wallet.create({ user: demo._id, balance: 800000 });
    console.log('Demo wallet created, balance:', wallet.balance);
  }

  // Address for demo
  const addrCount = await Address.countDocuments({ user: demo._id });
  if (addrCount === 0) {
    await Address.create({
      user: demo._id,
      fullName: 'مشتری نمونه',
      phone: DEMO_PHONE,
      province: 'مازندران',
      city: 'ساری',
      address: 'بلوار فرحزادی، خیابان صدف، ساختمان خزر، پلاک ۱۲',
      postalCode: '4816753568',
      label: 'خانه',
      isDefault: true,
      isActive: true
    });
    console.log('Demo address created');
  }

  // Products (document-based upsert so cross-field validators run with full context)
  let created = 0, updated = 0;
  for (const p of products) {
    const doc = {
      name: p.name,
      slug: p.slug,
      description: p.description,
      price: p.price,
      ...(p.discountPrice ? { discountPrice: p.discountPrice } : {}),
      category: p.category,
      categoryFa: p.categoryFa,
      image: p.image,
      ...(p.gallery ? { gallery: p.gallery } : {}),
      stock: p.stock,
      featured: !!p.featured,
      active: true,
      tags: p.tags,
      metadata: { unit: p.unit, origin: p.origin },
      rating: 0,
      reviewsCount: 0
    };
    let product = await Product.findOne({ slug: p.slug });
    if (product) {
      Object.assign(product, doc, { createdBy: product.createdBy || admin._id });
      await product.save();
      updated++;
    } else {
      await Product.create({ ...doc, createdBy: admin._id });
      created++;
    }
  }
  console.log(`Products: ${created} created, ${updated} updated`);

  const counts = {
    products: await Product.countDocuments(),
    users: await User.countDocuments(),
    wallets: await Wallet.countDocuments(),
    addresses: await Address.countDocuments()
  };
  console.log('DB counts:', JSON.stringify(counts));
  await mongoose.disconnect();
  console.log('Seed done.');
}

main().catch(e => { console.error('Seed FAILED:', e); process.exit(1); });
